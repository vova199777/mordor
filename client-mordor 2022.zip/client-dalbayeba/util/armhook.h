#pragma once

void UnFuck(uint32_t ptr);
void NOP(uintptr_t addr, unsigned int count);
void WriteMemory(uintptr_t dest, uintptr_t src, size_t size);
void WriteMemoryOrig(uintptr_t dest, uintptr_t src, size_t size);
void ReadMemory(uintptr_t dest, uintptr_t src, size_t size);

void Hook(uintptr_t addr, uintptr_t func, uintptr_t *orig);
void InstallPLTHook(uintptr_t addr, uintptr_t func, uintptr_t *orig);
void InstallMethodHook(uintptr_t addr, uintptr_t func);
void CodeInject(uintptr_t addr, uintptr_t func, int register);

void SCAndInitHook(uintptr_t lib, uintptr_t dest, uintptr_t size);
void HookSCAnd(uintptr_t addr, uintptr_t func);

#define Hook(a, b, c) Hook(s2h(BOEV(a)),b,c)
#define WriteMemory(a, b, c) WriteMemory(s2h(BOEV(a)),b,c)

#define SCAndInitHook(a, b, c) SCAndInitHook(a,s2h(BOEV(b)),s2h(BOEV(c)))
#define HookSCAnd(a, b) HookSCAnd(s2h(BOEV(a)),b)
#define CodeInject(a, b, c) CodeInject(s2h(BOEV(a)),b,c)
#define InstallPLTHook(a, b, c) InstallPLTHook(s2h(BOEV(a)),b,c)
#define InstallMethodHook(a, b) InstallMethodHook(s2h(BOEV(a)),b)

#define UnFuck(a) UnFuck(s2h(BOEV(a)))
#define UnFuckSC(a) UnFuckSC(s2h(BOEV(a)))
#define NOP(a, b) NOP(s2h(BOEV(a)),b)