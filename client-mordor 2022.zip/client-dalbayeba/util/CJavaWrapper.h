#pragma once

#include <jni.h>

#include <string>

#define EXCEPTION_CHECK(env) \
	if ((env)->ExceptionCheck()) \ 
	{ \
		(env)->ExceptionDescribe(); \
		(env)->ExceptionClear(); \
		return; \
	}

class CJavaWrapper
{
	jobject activity;

	jmethodID s_GetClipboardText;
	jmethodID s_CallLauncherActivity;

	jmethodID s_ShowInputLayout;
	jmethodID s_HideInputLayout;
	
	jmethodID s_ShowGUI;
	jmethodID s_HideGUI;
	
	jmethodID s_ShowDialog;
	
	jmethodID s_SetInvInterface;
	jmethodID s_SetInvInterfaceSlot;
	jmethodID s_SetInvInterfaceName;
	jmethodID s_SetInvInterfaceBank;
	jmethodID s_SetInvInterfaceBitcoin;
	jmethodID s_SetInvInterfaceMoney;
	jmethodID s_SetInvStateChangeGunAndAccess;
	
	jmethodID s_SetInvBackground;
	jmethodID s_SetInvInterfaceKG;
	jmethodID s_SetInvInterfaceSizeCM;
	jmethodID s_SetInvInterfaceInfoItem;
	jmethodID s_SetInvInterfaceSlotIllumination;
	jmethodID s_SetInvInterfaceUseKeyText;
	
	jmethodID s_SetInvOtherInterface;
	jmethodID s_SetInvOtherInterfaceSlot;
	jmethodID s_SetInvOtherInterfaceSlotIllumination;
	jmethodID s_SetInvOtherInterfaceMoney;
	jmethodID s_SetInvOtherInterfaceName;
	jmethodID s_SetInvOtherInterfaceKG;
	jmethodID s_SetInvOtherInterfaceSizeCM;
	
	jmethodID s_SetInvOtherBackground;
	
	jmethodID s_SetInvInterfaceSkin;
	
	jmethodID s_closeAllGUI;
	
	jmethodID s_IsKeyboardOpen;
	
	jmethodID s_SetInvOtherInterfaceAddMoney;
	
	jmethodID s_UpdateSpeedometerInfo;
	jmethodID s_UpdateSpeed;
	jmethodID s_ShowSpeedometer;
	jmethodID s_HideSpeedometer;
	
	jmethodID s_SetDailyBonus;
	jmethodID s_SetDailyBonusPayDayInfo;
	jmethodID s_SetDailyBonusMordorCoinsInfo;
	jmethodID s_SetDailyBonusDayInfo;
	jmethodID s_SetDailyBonusDayButton;
	jmethodID s_SetDailyBonusDayMedal;
	jmethodID s_SetDailyBonusDaySubstructure;
	jmethodID s_SetDailyBonusDayButtonText;
	jmethodID s_SetGameCase;
	jmethodID s_SetGameCasePayDayInfo;
	jmethodID s_SetGameCaseMordorCoinsInfo;
	jmethodID s_SetGameCaseDayInfo;
	jmethodID s_SetGameCaseDaySubstructure;
	
	jmethodID s_pushChatMessage;
	jmethodID s_showChat;
	
	jmethodID s_h_int;
	jmethodID s_h_float;
	jmethodID s_h_string;
	jmethodID s_h_bool;
	
	jmethodID s_SetInterfaceHud;
	jmethodID s_SetInterfaceOnlineDate;
	jmethodID s_SetInterfaceHudHealth;
	jmethodID s_SetInterfaceHudArmour;
	jmethodID s_SetInterfaceHudHunger;
	jmethodID s_SetInterfaceHudMoney;
	jmethodID s_SetInterfaceHudWanted;
	jmethodID s_SetInterfaceHudNotifications;
	jmethodID s_SetInterfaceHudZone;
	jmethodID s_SetInterfaceHudPromo;
	jmethodID s_SetInterfaceHudPromo1;
	
	jmethodID s_PlayerIsAfk;
	
	jmethodID s_SendSwitchWeapon;
	
	jmethodID s_SetInterafceVisibleUseBtn;
	
	jmethodID s_SetInterfaceNotification;
	
	//captures
	jmethodID s_SetInterfaceHudCapt;
	jmethodID s_SetInterfaceHudCaptClock;
	jmethodID s_SetInterfaceHudCaptScore;
	
	jmethodID s_SetInterfaceHudAmmo;
	
public:
	JNIEnv* GetEnv();
	
	bool StateBonus;
	bool StateLogoID;
	bool StateLogoOnline;	

	std::string GetClipboardString();
	void CallLauncherActivity(int type);

	void ShowInputLayout();
	void HideInputLayout();
	
	void ShowGUI(const char* type);
	void HideGUI(const char* type);
	
	void ShowDialog(int style, int dialog_id, const char* header, const char* data, const char* left_btn, const char* right_btn);
	
	void showMrpLogo(int type);
	void hideMrpLogo();
	void setMrpLogoData(const char* data);
	void showMrpBonus(bool show);
	void showMrpDate(bool show);
	void showMrpTime(bool show);
	void setMrpDateTime(const char* date, const char* time);
	void showMrpDateBackground(bool show);
	void showMrpTimeBackground(bool show);
	
	void SetInvInterface(bool show);
	void SetInvInterfaceSlot(bool status, int slotid, int itemid, int num);
	void SetInvInterfaceName(const char* name);
	void SetInvInterfaceBank(const char* name);
	void SetInvInterfaceBitcoin(const char* name);
	void SetInvInterfaceMoney(const char* name);
	void SetInvStateChangeGunAndAccess(bool state);
	
	void SetInvBackground(int state);
	void SetInvInterfaceKG(const char* text_kg);
	void SetInvInterfaceSizeCM(const char* text_size_cm);
	void SetInvInterfaceInfoItem(const char* text);
	void SetInvInterfaceSlotIllumination(int slotid, bool state);
	void SetInvInterfaceUseKeyText(const char* text);
	
	void SetInvOtherInterface(bool status, int type);
	void SetInvOtherInterfaceSlot(bool status, int slotid, int itemid, int num);
	void SetInvOtherInterfaceSlotIllumination(int slotid, bool state);
	void SetInvOtherInterfaceMoney(const char* text_money);
	void SetInvOtherInterfaceName(int side, const char* data);
	void SetInvOtherInterfaceKG(int side, const char* text_kg);
	void SetInvOtherInterfaceSizeCM(int side, const char* text_size_cm);
	
	void SetInvOtherBackground(int state);
	
	void SetInvInterfaceSkin(int skinid);
	
	void closeAllGUI();
	
	bool IsKeyboardOpen();
	
	void SetInvOtherInterfaceAddMoney(int side, const char* money);
	
	void ShowSpeedometer();
	void HideSpeedometer();
	void UpdateSpeedometerInfo(int fuel, int health, int lock, int lights, int engine, int mileage);
	void UpdateSpeed(int speed);
	
	void SetDailyBonus(bool status);
	void SetDailyBonusPayDayInfo(const char* text);
	void SetDailyBonusMordorCoinsInfo(const char* text);
	void SetDailyBonusDayInfo(int day, const char* text);
	void SetDailyBonusDayButton(int day, int type);
	void SetDailyBonusDayMedal(int day, int type);
	void SetDailyBonusDaySubstructure(int day, bool status);
	void SetDailyBonusDayButtonText(int day, const char* text);
	void SetGameCase(bool status);
	void SetGameCasePayDayInfo(const char* text);
	void SetGameCaseMordorCoinsInfo(const char* text);
	void SetGameCaseDayInfo(int day, const char* text);
	void SetGameCaseDaySubstructure(int day, bool status);
	
	void pushChatMessage(const char* text);
	void ShowChat(bool status);
	
	void h_int(int packetid, int value);
	void h_float(int packetid, float value);
	void h_string(int packetid, const char* value);
	void h_bool(int packetid, bool value);
	
	void SetInterfaceHud(bool status);
	void SetInterfaceOnlineDate(int date, int id, bool data);
	void SetInterfaceHudHealth(int health);
	void SetInterfaceHudArmour(int armour);
	void SetInterfaceHudHunger(int hunger);
	void SetInterfaceHudMoney(int money);
	void SetInterfaceHudWanted(int wanted);
	void SetInterfaceHudNotifications(int type, int time, const char* data);
	void SetInterfaceHudZone(int type);
	void SetInterfaceHudPromo(int time, const char* info);	
	void SetInterfaceHudPromo1(int time, const char* info);
	
	void PlayerIsAfk(bool status);
	
	void SendSwitchWeapon(int weaponid);
	
	void SetInterafceVisibleUseBtn(bool show);
	
	void SetInterfaceNotification(bool status);
	
	//captures
	void SetInterfaceHudCapt(bool status);
	void SetInterfaceHudCaptClock(const char* text);
	void SetInterfaceHudCaptScore(int i, const char* text);
	
	void SetInterfaceHudAmmo(int now, int max);
	

	CJavaWrapper(JNIEnv* env, jobject activity);
	~CJavaWrapper();
};

extern CJavaWrapper* g_pJavaWrapper;