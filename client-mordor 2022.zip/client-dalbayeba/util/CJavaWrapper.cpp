#include "CJavaWrapper.h"
#include "../main.h"

extern "C" JavaVM* javaVM;

#include "..//keyboard.h"
#include "..//chatwindow.h"
#include "..//settings.h"
extern CKeyBoard* pKeyBoard;
extern CChatWindow* pChatWindow;
extern CSettings* pSettings;

JNIEnv* CJavaWrapper::GetEnv()
{
	JNIEnv* env = nullptr;
	int getEnvStat = javaVM->GetEnv((void**)& env, JNI_VERSION_1_4);
	
	//StateBonus = false;
	//StateLogoID = false;
	//StateLogoOnline = false;

	if (getEnvStat == JNI_EDETACHED)
	{
		Log("GetEnv: not attached");
		if (javaVM->AttachCurrentThread(&env, NULL) != 0)
		{
			Log("Failed to attach");
			return nullptr;
		}
	}
	if (getEnvStat == JNI_EVERSION)
	{
		Log("GetEnv: version not supported");
		return nullptr;
	}

	if (getEnvStat == JNI_ERR)
	{
		Log("GetEnv: JNI_ERR");
		return nullptr;
	}

	return env;
}

std::string CJavaWrapper::GetClipboardString()
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return std::string("");
	}

	jbyteArray retn = (jbyteArray)env->CallObjectMethod(activity, s_GetClipboardText);

	if ((env)->ExceptionCheck())
	{
		(env)->ExceptionDescribe();
		(env)->ExceptionClear();
		return std::string("");
	}

	if (!retn)
	{
		return std::string("");
	}

	jboolean isCopy = true;

	jbyte* pText = env->GetByteArrayElements(retn, &isCopy);
	jsize length = env->GetArrayLength(retn);

	std::string str((char*)pText, length);

	env->ReleaseByteArrayElements(retn, pText, JNI_ABORT);
	
	return str;
}

void CJavaWrapper::CallLauncherActivity(int type)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}

	env->CallVoidMethod(activity, s_CallLauncherActivity, type);

	EXCEPTION_CHECK(env);
}

void CJavaWrapper::ShowInputLayout()
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}

	env->CallVoidMethod(activity, s_ShowInputLayout);

	EXCEPTION_CHECK(env);
}

void CJavaWrapper::HideInputLayout()
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}

	env->CallVoidMethod(activity, s_HideInputLayout);

	EXCEPTION_CHECK(env);
}

void CJavaWrapper::ShowGUI(const char* type)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}

	jstring jstr = env->NewStringUTF(type);

	env->CallVoidMethod(activity, s_ShowGUI, jstr);

	EXCEPTION_CHECK(env);
}

void CJavaWrapper::HideGUI(const char* type)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}

	jstring jstr = env->NewStringUTF(type);

	env->CallVoidMethod(activity, s_HideGUI, jstr);

	EXCEPTION_CHECK(env);
}

void CJavaWrapper::ShowDialog(int style, int dialog_id, const char* header, const char* data, const char* left_btn, const char* right_btn)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}

	jstring jheader = env->NewStringUTF(header);
	jstring jdata = env->NewStringUTF(data);
	jstring jleft_btn = env->NewStringUTF(left_btn);
	jstring jright_btn = env->NewStringUTF(right_btn);

	env->CallVoidMethod(activity, s_ShowDialog, style, dialog_id, jheader, jdata, jleft_btn, jright_btn);

	EXCEPTION_CHECK(env);
}

void CJavaWrapper::SetInvInterface(bool show)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	env->CallVoidMethod(activity, s_SetInvInterface, show);	
	
	EXCEPTION_CHECK(env);	
}

void CJavaWrapper::SetInvInterfaceSlot(bool status, int slotid, int itemid, int num)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	env->CallVoidMethod(activity, s_SetInvInterfaceSlot, status, slotid, itemid, num);	
	
	EXCEPTION_CHECK(env);	
}

void CJavaWrapper::SetInvInterfaceName(const char* name)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	jstring jdata = env->NewStringUTF(name);

	env->CallVoidMethod(activity, s_SetInvInterfaceName, jdata);	
	
	EXCEPTION_CHECK(env);
}

void CJavaWrapper::SetInvInterfaceBank(const char* name)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	jstring jdata = env->NewStringUTF(name);

	env->CallVoidMethod(activity, s_SetInvInterfaceBank, jdata);	
	
	EXCEPTION_CHECK(env);
}

void CJavaWrapper::SetInvInterfaceBitcoin(const char* name)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	jstring jdata = env->NewStringUTF(name);

	env->CallVoidMethod(activity, s_SetInvInterfaceBitcoin, jdata);	
	
	EXCEPTION_CHECK(env);
}

void CJavaWrapper::SetInvInterfaceMoney(const char* name)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	jstring jdata = env->NewStringUTF(name);

	env->CallVoidMethod(activity, s_SetInvInterfaceMoney, jdata);	
	
	EXCEPTION_CHECK(env);
}

void CJavaWrapper::SetInvStateChangeGunAndAccess(bool state)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	env->CallVoidMethod(activity, s_SetInvStateChangeGunAndAccess, state);	
	
	EXCEPTION_CHECK(env);	
}

void CJavaWrapper::SetInvBackground(int state)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	env->CallVoidMethod(activity, s_SetInvBackground, state);	
	
	EXCEPTION_CHECK(env);	
}

void CJavaWrapper::SetInvInterfaceKG(const char* text_kg)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	jstring jdata = env->NewStringUTF(text_kg);

	env->CallVoidMethod(activity, s_SetInvInterfaceKG, jdata);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetInvInterfaceSizeCM(const char* text_size_cm)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	jstring jdata = env->NewStringUTF(text_size_cm);

	env->CallVoidMethod(activity, s_SetInvInterfaceSizeCM, jdata);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetInvInterfaceInfoItem(const char* text)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	jstring jdata = env->NewStringUTF(text);

	env->CallVoidMethod(activity, s_SetInvInterfaceInfoItem, jdata);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetInvInterfaceSlotIllumination(int slotid, bool state)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	

	env->CallVoidMethod(activity, s_SetInvInterfaceSlotIllumination, slotid, state);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetInvInterfaceUseKeyText(const char* text)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	jstring jdata = env->NewStringUTF(text);

	env->CallVoidMethod(activity, s_SetInvInterfaceUseKeyText, jdata);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetInvOtherInterface(bool status, int type)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	

	env->CallVoidMethod(activity, s_SetInvOtherInterface, status, type);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetInvOtherInterfaceSlot(bool status, int slotid, int itemid, int num)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	

	env->CallVoidMethod(activity, s_SetInvOtherInterfaceSlot, status, slotid, itemid, num);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetInvOtherInterfaceSlotIllumination(int slotid, bool state)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	

	env->CallVoidMethod(activity, s_SetInvOtherInterfaceSlotIllumination, slotid, state);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetInvOtherInterfaceMoney(const char* text_money)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	jstring jdata = env->NewStringUTF(text_money);

	env->CallVoidMethod(activity, s_SetInvOtherInterfaceMoney, jdata);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetInvOtherInterfaceName(int side, const char* data)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	jstring jdata = env->NewStringUTF(data);

	env->CallVoidMethod(activity, s_SetInvOtherInterfaceName, side, jdata);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetInvOtherInterfaceKG(int side, const char* text_kg)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	jstring jdata = env->NewStringUTF(text_kg);

	env->CallVoidMethod(activity, s_SetInvOtherInterfaceKG, side, jdata);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetInvOtherInterfaceSizeCM(int side, const char* text_size_cm)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	jstring jdata = env->NewStringUTF(text_size_cm);

	env->CallVoidMethod(activity, s_SetInvOtherInterfaceSizeCM, side, jdata);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetInvInterfaceSkin(int skinid)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	

	//Log("skin id to java %d", skinid);
	env->CallVoidMethod(activity, s_SetInvInterfaceSkin, skinid);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetInvOtherBackground(int state)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	

	env->CallVoidMethod(activity, s_SetInvOtherBackground, state);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::closeAllGUI()
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	

	env->CallVoidMethod(activity, s_closeAllGUI);	
	
	EXCEPTION_CHECK(env);		
}

bool CJavaWrapper::IsKeyboardOpen()
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return false;
	}	

	jboolean test = env->CallBooleanMethod(activity, s_IsKeyboardOpen);	
	
	//EXCEPTION_CHECK(env);	

	return test;
}

void CJavaWrapper::SetInvOtherInterfaceAddMoney(int side, const char* money)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	jstring jdata = env->NewStringUTF(money);

	env->CallVoidMethod(activity, s_SetInvOtherInterfaceAddMoney, side, jdata);	
	
	EXCEPTION_CHECK(env);			
}

void CJavaWrapper::UpdateSpeedometerInfo(int fuel, int health, int lock, int lights, int engine, int mileage)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}		
	
	env->CallVoidMethod(activity, s_UpdateSpeedometerInfo, fuel, health, lock, lights, engine, mileage);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::UpdateSpeed(int speed)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}		
	
	env->CallVoidMethod(activity, s_UpdateSpeed, speed);	
	
	EXCEPTION_CHECK(env);	
}

void CJavaWrapper::ShowSpeedometer()
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	

	env->CallVoidMethod(activity, s_ShowSpeedometer);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::HideSpeedometer()
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	

	env->CallVoidMethod(activity, s_HideSpeedometer);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetDailyBonus(bool status)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	

	env->CallVoidMethod(activity, s_SetDailyBonus, status);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetDailyBonusPayDayInfo(const char* text)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	jstring jdata = env->NewStringUTF(text);
	env->CallVoidMethod(activity, s_SetDailyBonusPayDayInfo, jdata);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetDailyBonusMordorCoinsInfo(const char* text)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	jstring jdata = env->NewStringUTF(text);
	env->CallVoidMethod(activity, s_SetDailyBonusMordorCoinsInfo, jdata);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetDailyBonusDayInfo(int day, const char* text)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	jstring jdata = env->NewStringUTF(text);
	env->CallVoidMethod(activity, s_SetDailyBonusDayInfo, day, jdata);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetDailyBonusDayButton(int day, int type)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	env->CallVoidMethod(activity, s_SetDailyBonusDayButton, day, type);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetDailyBonusDayMedal(int day, int type)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	env->CallVoidMethod(activity, s_SetDailyBonusDayMedal, day, type);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetDailyBonusDaySubstructure(int day, bool status)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	env->CallVoidMethod(activity, s_SetDailyBonusDaySubstructure, day, status);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetDailyBonusDayButtonText(int day, const char* text)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	jstring jdata = env->NewStringUTF(text);
	env->CallVoidMethod(activity, s_SetDailyBonusDayButtonText, day, jdata);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetGameCase(bool status)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	env->CallVoidMethod(activity, s_SetGameCase, status);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetGameCasePayDayInfo(const char* text)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	jstring jdata = env->NewStringUTF(text);
	env->CallVoidMethod(activity, s_SetGameCasePayDayInfo, jdata);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetGameCaseMordorCoinsInfo(const char* text)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	jstring jdata = env->NewStringUTF(text);
	env->CallVoidMethod(activity, s_SetGameCaseMordorCoinsInfo, jdata);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetGameCaseDayInfo(int day, const char* text)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	jstring jdata = env->NewStringUTF(text);
	env->CallVoidMethod(activity, s_SetGameCaseDayInfo, day, jdata);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetGameCaseDaySubstructure(int day, bool status)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	env->CallVoidMethod(activity, s_SetGameCaseDaySubstructure, day, status);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::pushChatMessage(const char* text)
{
	
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	jstring jdata = env->NewStringUTF(text);
	//env->CallVoidMethod(activity, s_pushChatMessage, jdata);	
	
	EXCEPTION_CHECK(env);
	
}

void CJavaWrapper::h_int(int packetid, int value)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	env->CallVoidMethod(activity, s_h_int, packetid, value);	
	//if(pChatWindow) pChatWindow->AddDebugMessage("test %d %d", packetid, value);
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::h_float(int packetid, float value)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	env->CallVoidMethod(activity, s_h_float, packetid, value);	
	
	EXCEPTION_CHECK(env);	
}

void CJavaWrapper::h_string(int packetid, const char* value)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	jstring jdata = env->NewStringUTF(value);
	env->CallVoidMethod(activity, s_h_string, packetid, jdata);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::h_bool(int packetid, bool value)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	env->CallVoidMethod(activity, s_h_bool, packetid, value);	
	
	EXCEPTION_CHECK(env);	
}

// HUD
void CJavaWrapper::SetInterfaceHud(bool status)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	env->CallVoidMethod(activity, s_SetInterfaceHud, status);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetInterfaceOnlineDate(int date, int id, bool data)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	env->CallVoidMethod(activity, s_SetInterfaceOnlineDate, date, id, data);	
	
	EXCEPTION_CHECK(env);	
}

void CJavaWrapper::SetInterfaceHudHealth(int health)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	env->CallVoidMethod(activity, s_SetInterfaceHudHealth, health);	
	
	EXCEPTION_CHECK(env);	
}

void CJavaWrapper::SetInterfaceHudArmour(int armour)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	env->CallVoidMethod(activity, s_SetInterfaceHudArmour, armour);	
	
	EXCEPTION_CHECK(env);
}

void CJavaWrapper::SetInterfaceHudHunger(int hunger)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	env->CallVoidMethod(activity, s_SetInterfaceHudHunger, hunger);	
	
	EXCEPTION_CHECK(env);	
}

void CJavaWrapper::SetInterfaceHudMoney(int money)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	env->CallVoidMethod(activity, s_SetInterfaceHudMoney, money);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetInterfaceHudWanted(int wanted)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	env->CallVoidMethod(activity, s_SetInterfaceHudWanted, wanted);	
	
	EXCEPTION_CHECK(env);	
}

void CJavaWrapper::SetInterfaceHudNotifications(int type, int time, const char* data)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	jstring jdata = env->NewStringUTF(data);
	env->CallVoidMethod(activity, s_SetInterfaceHudNotifications, type, time, jdata);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetInterfaceHudZone(int type)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	env->CallVoidMethod(activity, s_SetInterfaceHudZone, type);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetInterfaceHudPromo(int time, const char* info)
{
	/*JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	jstring jdata = env->NewStringUTF(info);
	
	env->CallVoidMethod(activity, s_SetInterfaceHudPromo, time, jdata);	
	
	EXCEPTION_CHECK(env);		
	*/
}

void CJavaWrapper::SetInterfaceHudPromo1(int time, const char* info)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	jstring jdata = env->NewStringUTF(info);
	
	env->CallVoidMethod(activity, s_SetInterfaceHudPromo1, time, jdata);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::ShowChat(bool status)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	env->CallVoidMethod(activity, s_showChat, status);	
	
	EXCEPTION_CHECK(env);
}

void CJavaWrapper::PlayerIsAfk(bool status)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	env->CallVoidMethod(activity, s_PlayerIsAfk, status);	
	
	EXCEPTION_CHECK(env);	
	
}

void CJavaWrapper::SendSwitchWeapon(int weaponid)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	env->CallVoidMethod(activity, s_SendSwitchWeapon, weaponid);	
	
	EXCEPTION_CHECK(env);	
}

void CJavaWrapper::SetInterafceVisibleUseBtn(bool show)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	env->CallVoidMethod(activity, s_SetInterafceVisibleUseBtn, show);	
	
	EXCEPTION_CHECK(env);	
}

void CJavaWrapper::SetInterfaceNotification(bool status)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	env->CallVoidMethod(activity, s_SetInterfaceNotification, status);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetInterfaceHudCapt(bool status)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	env->CallVoidMethod(activity, s_SetInterfaceHudCapt, status);	
	
	EXCEPTION_CHECK(env);	
}

void CJavaWrapper::SetInterfaceHudCaptClock(const char* text)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	jstring jdata = env->NewStringUTF(text);
	env->CallVoidMethod(activity, s_SetInterfaceHudCaptClock, jdata);	
	
	EXCEPTION_CHECK(env);		
}

void CJavaWrapper::SetInterfaceHudCaptScore(int i, const char* text)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	jstring jdata = env->NewStringUTF(text);
	env->CallVoidMethod(activity, s_SetInterfaceHudCaptScore, i, jdata);	
	
	EXCEPTION_CHECK(env);			
}

void CJavaWrapper::SetInterfaceHudAmmo(int now, int max)
{
	JNIEnv* env = GetEnv();

	if (!env)
	{
		Log("No env");
		return;
	}	
	
	env->CallVoidMethod(activity, s_SetInterfaceHudAmmo, now, max);	
	
	EXCEPTION_CHECK(env);	
}

extern "C"
{
	JNIEXPORT void JNICALL Java_com_nvidia_dev_1one_NvEventQueueActivity_onInputEnd(JNIEnv* pEnv, jobject thiz, jbyteArray str)
	{
		if (pKeyBoard)
		{
			pKeyBoard->OnNewKeyboardInput(pEnv, thiz, str);
		}
	}
	JNIEXPORT void JNICALL Java_com_nvidia_dev_1one_NvEventQueueActivity_onEventBackPressed(JNIEnv* pEnv, jobject thiz)
	{
		if (pKeyBoard)
		{
			if (pKeyBoard->IsOpen())
			{
				Log("Closing keyboard");
				pKeyBoard->Close();
			}
		}
	}
	JNIEXPORT void JNICALL Java_com_nvidia_dev_1one_NvEventQueueActivity_onNativeHeightChanged(JNIEnv* pEnv, jobject thiz, jint orientation, jint height)
	{
		if (pChatWindow)
		{
			//pChatWindow->SetLowerBound(height);
		}
	}

	JNIEXPORT void JNICALL Java_com_nvidia_dev_1one_NvEventQueueActivity_setNativeCutoutSettings(JNIEnv* pEnv, jobject thiz, jboolean b)
	{
		if (pSettings)
		{
			pSettings->Get().iCutout = b;
		}
	}

	JNIEXPORT void JNICALL Java_com_nvidia_dev_1one_NvEventQueueActivity_setNativeKeyboardSettings(JNIEnv* pEnv, jobject thiz, jboolean b)
	{
		if (pSettings)
		{
			pSettings->Get().iAndroidKeyboard = b;
		}

		if (pKeyBoard && b)
		{
			pKeyBoard->EnableNewKeyboard();
		}
		else if(pKeyBoard)
		{
			pKeyBoard->EnableOldKeyboard();
		}
	}
	JNIEXPORT void JNICALL Java_com_nvidia_dev_1one_NvEventQueueActivity_setNativeDialogSettings(JNIEnv* pEnv, jobject thiz, jboolean b)
	{
		if(pSettings)
		{
			pSettings->Get().iAndroidDialog = b;
		}
	}
}

CJavaWrapper::CJavaWrapper(JNIEnv* env, jobject activity)
{
	this->activity = env->NewGlobalRef(activity);

	jclass nvEventClass = env->GetObjectClass(activity);
	if (!nvEventClass)
	{
		Log("nvEventClass null");
		return;
	}

	s_CallLauncherActivity = env->GetMethodID(nvEventClass, "callLauncherActivity", "(I)V");
	s_GetClipboardText = env->GetMethodID(nvEventClass, "getClipboardText", "()[B");

	s_ShowInputLayout = env->GetMethodID(nvEventClass, "showInputLayout", "()V");
	s_HideInputLayout = env->GetMethodID(nvEventClass, "hideInputLayout", "()V");
	
	s_ShowGUI = env->GetMethodID(nvEventClass, "ShowGUI", "(Ljava/lang/String;)V");
	s_HideGUI = env->GetMethodID(nvEventClass, "HideGUI", "(Ljava/lang/String;)V");
	
	s_ShowDialog = env->GetMethodID(nvEventClass, "ShowDialog", "(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V");
	
	s_SetInvInterface = env->GetMethodID(nvEventClass, "SetInvInterface", "(Z)V");
	s_SetInvInterfaceSlot = env->GetMethodID(nvEventClass, "SetInvInterfaceSlot", "(ZIII)V");
	s_SetInvInterfaceName = env->GetMethodID(nvEventClass, "SetInvInterfaceName", "(Ljava/lang/String;)V");
	s_SetInvInterfaceBank = env->GetMethodID(nvEventClass, "SetInvInterfaceBank", "(Ljava/lang/String;)V");
	s_SetInvInterfaceBitcoin = env->GetMethodID(nvEventClass, "SetInvInterfaceBitcoin", "(Ljava/lang/String;)V");
	s_SetInvInterfaceMoney = env->GetMethodID(nvEventClass, "SetInvInterfaceMoney", "(Ljava/lang/String;)V");
	s_SetInvStateChangeGunAndAccess = env->GetMethodID(nvEventClass, "SetInvStateChangeGunAndAccess", "(Z)V");
	
	s_SetInvBackground = env->GetMethodID(nvEventClass, "SetInvBackground", "(I)V");
	s_SetInvInterfaceKG = env->GetMethodID(nvEventClass, "SetInvInterfaceKG", "(Ljava/lang/String;)V");
	s_SetInvInterfaceSizeCM = env->GetMethodID(nvEventClass, "SetInvInterfaceSizeCM", "(Ljava/lang/String;)V");
	s_SetInvInterfaceInfoItem = env->GetMethodID(nvEventClass, "SetInvInterfaceInfoItem", "(Ljava/lang/String;)V");
	s_SetInvInterfaceSlotIllumination = env->GetMethodID(nvEventClass, "SetInvInterfaceSlotIllumination", "(IZ)V");
	s_SetInvInterfaceUseKeyText = env->GetMethodID(nvEventClass, "SetInvInterfaceUseKeyText", "(Ljava/lang/String;)V");
	
	s_SetInvOtherInterface = env->GetMethodID(nvEventClass, "SetInvOtherInterface", "(ZI)V");
	s_SetInvOtherInterfaceSlot = env->GetMethodID(nvEventClass, "SetInvOtherInterfaceSlot", "(ZIII)V");
	s_SetInvOtherInterfaceSlotIllumination = env->GetMethodID(nvEventClass, "SetInvOtherInterfaceSlotIllumination", "(IZ)V");
	s_SetInvOtherInterfaceMoney = env->GetMethodID(nvEventClass, "SetInvOtherInterfaceMoney", "(Ljava/lang/String;)V");
	s_SetInvOtherInterfaceName = env->GetMethodID(nvEventClass, "SetInvOtherInterfaceName", "(ILjava/lang/String;)V");
	s_SetInvOtherInterfaceKG = env->GetMethodID(nvEventClass, "SetInvOtherInterfaceKG", "(ILjava/lang/String;)V");
	s_SetInvOtherInterfaceSizeCM = env->GetMethodID(nvEventClass, "SetInvOtherInterfaceSizeCM", "(ILjava/lang/String;)V");
	
	s_SetInvOtherBackground = env->GetMethodID(nvEventClass, "SetInvOtherBackground", "(I)V");
	
	s_SetInvInterfaceSkin = env->GetMethodID(nvEventClass, "SetInvInterfaceSkin", "(I)V");
	
	s_closeAllGUI = env->GetMethodID(nvEventClass, "closeAllGUI", "()V");
	
	s_IsKeyboardOpen = env->GetMethodID(nvEventClass, "IsKeyboardOpen", "()Z");
	
	s_SetInvOtherInterfaceAddMoney = env->GetMethodID(nvEventClass, "SetInvOtherInterfaceAddMoney", "(ILjava/lang/String;)V");
	
	s_UpdateSpeedometerInfo = env->GetMethodID(nvEventClass, "UpdateSpeedometerInfo", "(IIIIII)V");
	s_UpdateSpeed = env->GetMethodID(nvEventClass, "UpdateSpeed", "(I)V");
	s_ShowSpeedometer = env->GetMethodID(nvEventClass, "ShowSpeedometer", "()V");
	s_HideSpeedometer = env->GetMethodID(nvEventClass, "HideSpeedometer", "()V");
	
	s_SetDailyBonus = env->GetMethodID(nvEventClass, "SetDailyBonus", "(Z)V");
	s_SetDailyBonusPayDayInfo = env->GetMethodID(nvEventClass, "SetDailyBonusPayDayInfo", "(Ljava/lang/String;)V");
	s_SetDailyBonusMordorCoinsInfo = env->GetMethodID(nvEventClass, "SetDailyBonusMordorCoinsInfo", "(Ljava/lang/String;)V");
	s_SetDailyBonusDayInfo = env->GetMethodID(nvEventClass, "SetDailyBonusDayInfo", "(ILjava/lang/String;)V");
	s_SetDailyBonusDayButton = env->GetMethodID(nvEventClass, "SetDailyBonusDayButton", "(II)V");
	s_SetDailyBonusDayMedal = env->GetMethodID(nvEventClass, "SetDailyBonusDayMedal", "(II)V");
	s_SetDailyBonusDaySubstructure = env->GetMethodID(nvEventClass, "SetDailyBonusDaySubstructure", "(IZ)V");
	s_SetDailyBonusDayButtonText = env->GetMethodID(nvEventClass, "SetDailyBonusDayButtonText", "(ILjava/lang/String;)V");
	s_SetGameCase = env->GetMethodID(nvEventClass, "SetGameCase", "(Z)V");
	s_SetGameCasePayDayInfo = env->GetMethodID(nvEventClass, "SetGameCasePayDayInfo", "(Ljava/lang/String;)V");
	s_SetGameCaseMordorCoinsInfo = env->GetMethodID(nvEventClass, "SetGameCaseMordorCoinsInfo", "(Ljava/lang/String;)V");
	s_SetGameCaseDayInfo = env->GetMethodID(nvEventClass, "SetGameCaseDayInfo", "(ILjava/lang/String;)V");
	s_SetGameCaseDaySubstructure = env->GetMethodID(nvEventClass, "SetGameCaseDaySubstructure", "(IZ)V");
	
	s_pushChatMessage = env->GetMethodID(nvEventClass, "pushChatMessage", "(Ljava/lang/String;)V");
	s_showChat = env->GetMethodID(nvEventClass, "showChat", "(Z)V");
	
	s_h_int = env->GetMethodID(nvEventClass, "h_int", "(II)V");
	s_h_float = env->GetMethodID(nvEventClass, "h_float", "(IF)V");
	s_h_string =  env->GetMethodID(nvEventClass, "h_string", "(ILjava/lang/String;)V");
	s_h_bool = env->GetMethodID(nvEventClass, "h_bool", "(IZ)V");
	
	//HUD
	s_SetInterfaceHud = env->GetMethodID(nvEventClass, "SetInterfaceHud", "(Z)V");
	s_SetInterfaceOnlineDate = env->GetMethodID(nvEventClass, "SetInterfaceOnlineDate", "(IIZ)V");
	s_SetInterfaceHudHealth = env->GetMethodID(nvEventClass, "SetInterfaceHudHealth", "(I)V");
	s_SetInterfaceHudArmour = env->GetMethodID(nvEventClass, "SetInterfaceHudArmour", "(I)V");
	s_SetInterfaceHudHunger = env->GetMethodID(nvEventClass, "SetInterfaceHudHunger", "(I)V");
	s_SetInterfaceHudMoney = env->GetMethodID(nvEventClass, "SetInterfaceHudMoney", "(I)V");
	s_SetInterfaceHudWanted = env->GetMethodID(nvEventClass, "SetInterfaceHudWanted", "(I)V");
	s_SetInterfaceHudNotifications = env->GetMethodID(nvEventClass, "SetInterfaceHudNotifications", "(IILjava/lang/String;)V");
	s_SetInterfaceHudZone = env->GetMethodID(nvEventClass, "SetInterfaceHudZone", "(I)V");
	//s_SetInterfaceHudPromo = env->GetMethodID(nvEventClass, "SetInterfaceHudPromo", "(ILjava/lang/String;)V");
	
	s_SetInterfaceHudPromo1 = env->GetMethodID(nvEventClass, "SetInterfaceHudPromos", "(ILjava/lang/String;)V");
	
	s_PlayerIsAfk = env->GetMethodID(nvEventClass, "PlayerIsAfk", "(Z)V");
	
	s_SendSwitchWeapon = env->GetMethodID(nvEventClass, "SendSwitchWeapon", "(I)V");
	
	s_SetInterafceVisibleUseBtn = env->GetMethodID(nvEventClass, "SetInterafceVisibleUseBtn", "(Z)V");
	
	s_SetInterfaceNotification = env->GetMethodID(nvEventClass, "SetInterfaceNotification", "(Z)V");
	
	s_SetInterfaceHudAmmo = env->GetMethodID(nvEventClass, "SetInterfaceHudAmmo", "(II)V");

	env->DeleteLocalRef(nvEventClass);
}

CJavaWrapper::~CJavaWrapper()
{
	JNIEnv* pEnv = GetEnv();
	if (pEnv)
	{
		pEnv->DeleteGlobalRef(this->activity);
	}
}

CJavaWrapper* g_pJavaWrapper = nullptr;