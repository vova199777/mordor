#pragma once

PED_TYPE* GamePool_FindPlayerPed();
PED_TYPE* GamePool_Ped_GetAt(int iID);
int GamePool_Ped_GetIndex(PED_TYPE *pActor);

VEHICLE_TYPE *GamePool_Vehicle_GetAt(int iID);
int GamePool_Vehicle_GetIndex(VEHICLE_TYPE *pVehicle);

ENTITY_TYPE *GamePool_Object_GetAt(int iID);

int LineOfSight(VECTOR* start, VECTOR* end, void* colpoint, uintptr_t ent,
	char buildings, char vehicles, char peds, char objects, char dummies, bool seeThrough, bool camera, bool unk);

bool IsPedModel(unsigned int uiModel);
bool IsValidModel(unsigned int uiModelID);
uint16_t GetModelReferenceCount(int nModelIndex);

void InitPlayerPedPtrRecords();
void SetPlayerPedPtrRecord(uint8_t bytePlayer, uintptr_t dwPedPtr);
uint8_t FindPlayerNumFromPedPtr(uintptr_t dwPedPtr);

uintptr_t GetTexture(const char* texture);
uintptr_t LoadTextureFromDB(const char* dbname, const char* texture);
void DefinedState2d();
void SetScissorRect(void* pRect);
float DegToRad(float fDegrees);
// 0.3.7
float FloatOffset(float f1, float f2);

void RwMatrixRotate(MATRIX4X4 *mat, int axis, float angle);
void WorldAddEntity(uintptr_t pEnt);
void WorldRemoveEntity(uintptr_t pEnt);

uintptr_t GetModelInfoByID(int iModelID);
uintptr_t ModelInfoCreateInstance(int iModel);
void RenderClumpOrAtomic(uintptr_t rwObject);
float GetModelColSphereRadius(int iModel);
void GetModelColSphereVecCenter(int iModel, VECTOR* vec);
void DestroyAtomicOrClump(uintptr_t rwObject);

int GetFreeTextDrawTextureSlot();
void DestroyTextDrawTexture(int index);
uintptr_t LoadTexture(const char* texname);
void DrawTextureUV(uintptr_t texture, RECT* rect, uint32_t dwColor, float *uv);

bool IsPointInRect(float x, float y, RECT* rect);

int GameGetWeaponModelIDFromWeaponID(int iWeaponID);

int Weapon_FireSniper(WEAPON_SLOT_TYPE* pWeaponSlot, PED_TYPE* pPed);
uintptr_t GetWeaponInfo(int iWeapon, int iSkill);

bool IsGameEntityArePlaceable(ENTITY_TYPE *pEntity);

void ProjectMatrix(VECTOR* vecOut, MATRIX4X4* mat, VECTOR *vecPos);
void RwMatrixOrthoNormalize(MATRIX4X4 *matIn, MATRIX4X4 *matOut);
void RwMatrixInvert(MATRIX4X4 *matOut, MATRIX4X4 *matIn);
void RwMatrixScale(MATRIX4X4 *matrix, VECTOR *vecScale);

float GetDistance(float X, float Y, float Z, float XX, float YY, float ZZ);

bool IsValidGamePed(PED_TYPE *pPed);

bool PreloadAnimFile(char *szAnimFile, uint16_t usSleep, uint16_t usHowTimes);

float GetDistanceFromVectorToVector(VECTOR* vecFrom, VECTOR* vecTo);
float GetDistanceBetween3DPoints(VECTOR* f, VECTOR* s);