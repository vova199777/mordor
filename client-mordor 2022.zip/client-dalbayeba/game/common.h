#pragma once

#define PLAYER_PED_SLOTS	120

#define MAX_REMOVE_MODELS	1200

typedef unsigned short VEHICLEID;
typedef unsigned short PLAYERID;

#define PADDING(x,y) uint8_t x[y]

#define IN_VEHICLE(x) ((x->dwStateFlags & 0x100) >> 8)

//-----------------------------------------------------------
typedef struct _WEAPON_SLOT_TYPE {
	uint32_t dwType;
	uint32_t dwState;
	uint32_t dwAmmoInClip;
	uint32_t dwAmmo;
	
	PADDING(_pwep1,12);
} WEAPON_SLOT_TYPE;

#pragma pack(1)
typedef struct _RECT
{
	float fLeft;
	float fBottom;
	float fRight;
	float fTop;
} RECT, *PRECT;

#pragma pack(1)
typedef struct _VECTOR 
{
	float X,Y,Z;
} VECTOR, *PVECTOR;

// VEHICLE DAMAGE COMPONENTS
enum eVehicleDamageComponent {
	COMPONENT_WHEEL_LF = 1,
	COMPONENT_WHEEL_RF = 2,
	COMPONENT_WHEEL_LR = 3,
	COMPONENT_WHEEL_RR = 4,
	COMPONENT_BONNET = 5,
	COMPONENT_BOOT = 6,
	COMPONENT_DOOR_LF = 7,
	COMPONENT_DOOR_RF = 8,
	COMPONENT_DOOR_LR = 9,
	COMPONENT_DOOR_RR = 10,
	COMPONENT_WING_LF = 11,
	COMPONENT_WING_RF = 12,
	COMPONENT_WING_LR = 13,
	COMPONENT_WING_RR = 14,
	COMPONENT_WINDSCREEN = 15,
	COMPONENT_BUMP_FRONT = 16,
	COMPONENT_BUMP_REAR = 17
};

enum eWheelStatus
{
	DT_WHEEL_INTACT = 0,
	//  DT_WHEEL_CAP_MISSING,
	//  DT_WHEEL_WARPED,
	DT_WHEEL_BURST,
	DT_WHEEL_MISSING,

	// MTA custom state
	DT_WHEEL_INTACT_COLLISIONLESS,
};

enum eDoorStatus
{
	DT_DOOR_INTACT = 0,
	DT_DOOR_SWINGING_FREE,
	DT_DOOR_BASHED,
	DT_DOOR_BASHED_AND_SWINGING_FREE,
	DT_DOOR_MISSING
};

enum ePlaneComponentStatus
{
	DT_PLANE_INTACT = 0,
	DT_PLANE_BASHED,
	//  DT_PLANE_BASHED2,
	DT_PLANE_MISSING
};

enum eComponentStatus
{
	DT_PANEL_INTACT = 0,
	//  DT_PANEL_SHIFTED,
	DT_PANEL_BASHED,
	DT_PANEL_BASHED2,
	DT_PANEL_MISSING
};

enum eLightStatus
{
	DT_LIGHT_OK = 0,
	DT_LIGHT_SMASHED
};

enum eDoors
{
	BONNET = 0,
	BOOT,
	FRONT_LEFT_DOOR,
	FRONT_RIGHT_DOOR,
	REAR_LEFT_DOOR,
	REAR_RIGHT_DOOR,
	MAX_DOORS
};

enum ePanels
{
	FRONT_LEFT_PANEL = 0,
	FRONT_RIGHT_PANEL,
	REAR_LEFT_PANEL,
	REAR_RIGHT_PANEL,
	WINDSCREEN_PANEL,            // needs to be in same order as in component.h
	FRONT_BUMPER,
	REAR_BUMPER,

	MAX_PANELS            // MUST BE 8 OR LESS
};

enum eLights
{
	// these have to correspond to their respective panels
	LEFT_HEADLIGHT = 0,
	RIGHT_HEADLIGHT,
	LEFT_TAIL_LIGHT,
	RIGHT_TAIL_LIGHT,
	/*  LEFT_BRAKE_LIGHT,
		RIGHT_BRAKE_LIGHT,
		FRONT_LEFT_INDICATOR,
		FRONT_RIGHT_INDICATOR,
		REAR_LEFT_INDICATOR,
		REAR_RIGHT_INDICATOR,*/

	MAX_LIGHTS            // MUST BE 16 OR LESS
};

enum eWheelPosition
{
	FRONT_LEFT_WHEEL = 0,
	REAR_LEFT_WHEEL,
	FRONT_RIGHT_WHEEL,
	REAR_RIGHT_WHEEL,

	MAX_WHEELS

};

typedef struct _DAMAGE_MANAGER_INTERFACE            // 28 bytes due to the way its packed (24 containing actual data)
{
	float fWheelDamageEffect;
	uint8_t  bEngineStatus;            // old - wont be used
	uint8_t  Wheel[MAX_WHEELS];
	uint8_t  Door[MAX_DOORS];
	uint32_t Lights;            // 2 bits per light
	uint32_t Panels;            // 4 bits per panel
} DAMAGE_MANAGER_INTERFACE;

#pragma pack(1)
struct VehicleAudioPropertiesStruct
{
	int16_t VehicleType;		//	1: +  0
	int16_t EngineOnSound;	//  2: +  2
	int16_t EngineOffSound;	//  3: +  4
	int16_t field_4;			//  4: +  6
	float field_5;			//  5: +  8
	float field_6;			//  6: + 12
	char HornTon;				//  7: + 16
	char field_8[3];			//	8: + 17, zeros
	float HornHigh;			//  9: + 20
	char DoorSound;			// 10: + 24
	char field_11[1];			// 11: + 25, zeros
	char RadioNum;			// 12: + 26
	char RadioType;			// 13: + 27
	char field_14;			// 14: + 28
	char field_15[3];			// 15: + 29, zeros
	float field_16;			// 16: + 32
};

#pragma pack(1)
typedef struct _MATRIX4X4 
{
	VECTOR right;		// 0-12 	; r11 r12 r13
	uint32_t  flags;	// 12-16
	VECTOR up;			// 16-28	; r21 r22 r23
	float  pad_u;		// 28-32
	VECTOR at;			// 32-44	; r31 r32 r33
	float  pad_a;		// 44-48
	VECTOR pos;			// 48-60
	float  pad_p;		// 60-64
} MATRIX4X4, *PMATRIX4X4;

//-----------------------------------------------------------

#pragma pack(1)
typedef struct _ENTITY_TYPE
{
	// ENTITY STUFF
	uint32_t vtable; 		// 0-4		;vtable
	PADDING(_pad91, 16);	// 4-20
	MATRIX4X4 *mat; 		// 20-24	;mat
	uintptr_t pdwRenderWare;// 24-28
	uint32_t dwProcessingFlags;//28-32
	PADDING(_pad92, 2);	    // 32-34
	uint16_t nModelIndex; 	// 34-36	;ModelIndex
	PADDING(_pad93, 32);	// 36-68
	VECTOR vecMoveSpeed; 	// 68-80	;vecMoveSpeed
	VECTOR vecTurnSpeed; 	// 80-92	;vecTurnSpeed
	PADDING(_pad94, 88);	// 92-180
	uintptr_t dwUnkModelRel; // 180-184 ;����� ����

} ENTITY_TYPE;


typedef struct _BULLET_DATA {
	uint32_t unk;
	VECTOR vecOrigin;
	VECTOR vecPos;
	VECTOR vecOffset;
	ENTITY_TYPE* pEntity;
} BULLET_DATA;

//-----------------------------------------------------------

#pragma pack(1)
typedef struct
{
	ENTITY_TYPE* pEntity;
	float fDamage;
	uint32_t dwBodyPart;
	uint32_t dwWeapon;
	bool bSpeak;
} stPedDamageResponse;

//-----------------------------------------------------------

typedef struct
{
	char unk[0x14];
	int iNodeId;

} AnimBlendFrameData;

//-----------------------------------------------------------

#pragma pack(1)
struct BULLET_SYNC
{
	uint8_t hitType;
	uint16_t hitId;
	float origin[3];
	float hitPos[3];
	float offsets[3];
	uint8_t weapId;
};

#pragma pack(1)
typedef struct _PED_TASKS_TYPE
{
	uint32_t* pdwPed;
	// Basic Tasks
	uint32_t* pdwDamage;
	uint32_t* pdwFallEnterExit;
	uint32_t* pdwSwimWasted;
	uint32_t* pdwJumpJetPack;
	uint32_t* pdwAction;
	// Extended Tasks
	uint32_t* pdwFighting;
	uint32_t* pdwCrouching;
	uint32_t* pdwSay;
	uint32_t* pdwFacialComplex;
	uint32_t* pdwPartialAnim;
	uint32_t* pdwIK;
} PED_TASKS_TYPE;


#pragma pack(1)
typedef struct _PED_TYPE
{
	ENTITY_TYPE entity; 				// 0000-0184	;entity
	PADDING(_pad106, 174);				// 0184-0358
	PADDING(_pad107, 726);				// 0358-1088
	PED_TASKS_TYPE *Tasks;				// 1084-1088
	uintptr_t dwPlayerInfoOffset;		// 1088-1092
	PADDING(_pad101, 4);				// 1092-1096
	uint32_t dwAction;					// 1096-1100	;Action
	PADDING(_pad102, 52);				// 1100-1152
	uint32_t dwStateFlags; 				// 1152-1156	;StateFlags
	PADDING(_pad1021, 12);				// 1156-1168
	AnimBlendFrameData* aPedBones[19];	// 1168-1244
	PADDING(_pad103, 100);				// 1244-1344
	float fHealth;		 				// 1344-1348	;Health
	float fMaxHealth;					// 1348-1352	;MaxHealth
	float fArmour;						// 1352-1356	;Armour ---
	PADDING(_pad104, 12);				// 1356-1368
	float fRotation1;					// 1368-1372	;Rotation1
	float fRotation2;					// 1372-1376	;Rotation2
	float fUnkRotRel;					// 1376-1380
	float fRotCamAdjust;				// 1380-1384
	uint32_t pContactVehicle; 			// 1384-1388	
	PADDING(_pad105, 32);				// 1388-1420
	uint32_t pVehicle;					// 1420-1424	;pVehicle
	PADDING(_pad108, 8);				// 1424-1432
	uint32_t dwPedType;					// 1432-1436	;dwPedType
	PADDING(_pad110, 4);				// 1436-1440
	WEAPON_SLOT_TYPE WeaponSlots[13]; 	// 1440-1804
	PADDING(_pad10g, 12);				// 1804-1816
	uint8_t byteCurWeaponSlot;			// 1816-1817
	PADDING(_pad10b, 28);				// 1817-1845
	uint8_t byteFightingStyle;			// 1845-1846
	uint8_t byteFightingType;			// 1846-1847
	PADDING(_pad1052, 41);				// 1847-1888
	uint32_t dwWeaponUsed; 				// 1888-1892
	uint32_t* pdwDamageEntity;			// 1892-1896	;pdwDamageEntity
} PED_TYPE;

//-----------------------------------------------------------

#pragma pack(1)
typedef struct _VEHICLE_TYPE
{
	//ENTITY_TYPE entity;			// 0000-0184	;entity
	//PADDING(_pad201124, 716);		// 0184-900
	//tHandlingData* pHandling;	// 900-904	
	//PADDING(_pad201, 160);		// 904-1064
	
	ENTITY_TYPE entity;			// 0000-0184	;entity
	PADDING(_pad201, 880);		// 0184-1064	
	
	struct {
		unsigned char bIsLawEnforcer : 1;
		unsigned char bIsAmbulanceOnDuty : 1;
		unsigned char bIsFireTruckOnDuty : 1;
		unsigned char bIsLocked : 1;
		unsigned char bEngineOn : 1;
		unsigned char bIsHandbrakeOn : 1;
		unsigned char bLightsOn : 1;
		unsigned char bFreebies : 1;

		unsigned char bIsVan : 1;
		unsigned char bIsBus : 1;
		unsigned char bIsBig : 1;
		unsigned char bLowVehicle : 1;
		unsigned char bComedyControls : 1;
		unsigned char bWarnedPeds : 1;
		unsigned char bCraneMessageDone : 1;
		unsigned char bTakeLessDamage : 1;

		unsigned char bIsDamaged : 1;
		unsigned char bHasBeenOwnedByPlayer : 1;
		unsigned char bFadeOut : 1;
		unsigned char bIsBeingCarJacked : 1;
		unsigned char bCreateRoadBlockPeds : 1;
		unsigned char bCanBeDamaged : 1;
		unsigned char bOccupantsHaveBeenGenerated : 1;
		unsigned char bGunSwitchedOff : 1;

		unsigned char bVehicleColProcessed : 1;
		unsigned char bIsCarParkVehicle : 1;
		unsigned char bHasAlreadyBeenRecorded : 1;
		unsigned char bPartOfConvoy : 1;
		unsigned char bHeliMinimumTilt : 1;
		unsigned char bAudioChangingGear : 1;
		unsigned char bIsDrowning : 1;
		unsigned char bTyresDontBurst : 1;

		unsigned char bCreatedAsPoliceVehicle : 1;
		unsigned char bRestingOnPhysical : 1;
		unsigned char bParking : 1;
		unsigned char bCanPark : 1;
		unsigned char bFireGun : 1;
		unsigned char bDriverLastFrame : 1;
		unsigned char bNeverUseSmallerRemovalRange : 1;
		unsigned char bIsRCVehicle : 1;

		unsigned char bAlwaysSkidMarks : 1;
		unsigned char bEngineBroken : 1;
		unsigned char bVehicleCanBeTargetted : 1;
		unsigned char bPartOfAttackWave : 1;
		unsigned char bWinchCanPickMeUp : 1;
		unsigned char bImpounded : 1;
		unsigned char bVehicleCanBeTargettedByHS : 1;
		unsigned char bSirenOrAlarm : 1;

		unsigned char bHasGangLeaningOn : 1;
		unsigned char bGangMembersForRoadBlock : 1;
		unsigned char bDoesProvideCover : 1;
		unsigned char bMadDriver : 1;
		unsigned char bUpgradedStereo : 1;
		unsigned char bConsideredByPlayer : 1;
		unsigned char bPetrolTankIsWeakPoint : 1;
		unsigned char bDisableParticles : 1;

		unsigned char bHasBeenResprayed : 1;
		unsigned char bUseCarCheats : 1;
		unsigned char bDontSetColourWhenRemapping : 1;
		unsigned char bUsedForReplay : 1;
	} nFlags;					// 1064-1072
	
	unsigned int m_nCreationTime; // 1072-1076
	
	uint8_t byteColor1;			// 1076-1077	;byteColor1
	uint8_t byteColor2;			// 1077-1078	;byteColor2
	PADDING(_pad204, 42);		// 1078-1120
	PED_TYPE *pDriver;			// 1120-1124	;driver
	PED_TYPE *pPassengers[7];	// 1124-1152	;pPassengers
	PADDING(_pad202, 72);		// 1152-1224
	float fHealth;				// 1224-1228	;fHealth
	uint32_t unk;				// 1228-1232 	;unk
	uint32_t dwTrailer;			// 1232-1236 	;trailer
	PADDING(_pad203, 48);		// 1236-1284
	uint32_t dwDoorsLocked;		// 1284-1288	;dwDoorsLocked
	
	
	/*
	ENTITY_TYPE entity;			// 0000-0184	;entity
	PADDING(_pad201, 892);		// 0184-1076
	uint8_t byteColor1;			// 1076-1077	;byteColor1
	uint8_t byteColor2;			// 1077-1078	;byteColor2
	PADDING(_pad204, 42);		// 1078-1120
	PED_TYPE *pDriver;			// 1120-1124	;driver
	PED_TYPE *pPassengers[7];	// 1124-1152	;pPassengers
	PADDING(_pad202, 72);		// 1152-1224
	float fHealth;				// 1224-1228	;fHealth
	PADDING(_pad203, 56);		// 1228-1284
	uint32_t dwDoorsLocked;		// 1284-1288	;dwDoorsLocked	
	*/
	
} VEHICLE_TYPE;

//-----------------------------------------------------------

#define	VEHICLE_SUBTYPE_CAR				1
#define	VEHICLE_SUBTYPE_BIKE			2
#define	VEHICLE_SUBTYPE_HELI			3
#define	VEHICLE_SUBTYPE_BOAT			4
#define	VEHICLE_SUBTYPE_PLANE			5
#define	VEHICLE_SUBTYPE_PUSHBIKE		6
#define	VEHICLE_SUBTYPE_TRAIN			7

//-----------------------------------------------------------

#define TRAIN_PASSENGER_LOCO			538
#define TRAIN_FREIGHT_LOCO				537
#define TRAIN_PASSENGER					570
#define TRAIN_FREIGHT					569
#define TRAIN_TRAM						449
#define HYDRA							520

//-----------------------------------------------------------

#define ACTION_WASTED					55
#define ACTION_DEATH					54
#define ACTION_INCAR					50
#define ACTION_NORMAL					1
#define ACTION_SCOPE					12
#define ACTION_NONE						0 

//-----------------------------------------------------------

#define WEAPON_MODEL_BRASSKNUCKLE		331 // was 332
#define WEAPON_MODEL_GOLFCLUB			333
#define WEAPON_MODEL_NITESTICK			334
#define WEAPON_MODEL_KNIFE				335
#define WEAPON_MODEL_BAT				336
#define WEAPON_MODEL_SHOVEL				337
#define WEAPON_MODEL_POOLSTICK			338
#define WEAPON_MODEL_KATANA				339
#define WEAPON_MODEL_CHAINSAW			341
#define WEAPON_MODEL_DILDO				321
#define WEAPON_MODEL_DILDO2				322
#define WEAPON_MODEL_VIBRATOR			323
#define WEAPON_MODEL_VIBRATOR2			324
#define WEAPON_MODEL_FLOWER				325
#define WEAPON_MODEL_CANE				326
#define WEAPON_MODEL_GRENADE			342 // was 327
#define WEAPON_MODEL_TEARGAS			343 // was 328
#define WEAPON_MODEL_MOLOTOV			344 // was 329
#define WEAPON_MODEL_COLT45				346
#define WEAPON_MODEL_SILENCED			347
#define WEAPON_MODEL_DEAGLE				348
#define WEAPON_MODEL_SHOTGUN			349
#define WEAPON_MODEL_SAWEDOFF			350
#define WEAPON_MODEL_SHOTGSPA			351
#define WEAPON_MODEL_UZI				352
#define WEAPON_MODEL_MP5				353
#define WEAPON_MODEL_AK47				355
#define WEAPON_MODEL_M4					356
#define WEAPON_MODEL_TEC9				372
#define WEAPON_MODEL_RIFLE				357
#define WEAPON_MODEL_SNIPER				358
#define WEAPON_MODEL_ROCKETLAUNCHER		359
#define WEAPON_MODEL_HEATSEEKER			360
#define WEAPON_MODEL_FLAMETHROWER		361
#define WEAPON_MODEL_MINIGUN			362
#define WEAPON_MODEL_SATCHEL			363
#define WEAPON_MODEL_BOMB				364
#define WEAPON_MODEL_SPRAYCAN			365
#define WEAPON_MODEL_FIREEXTINGUISHER	366
#define WEAPON_MODEL_CAMERA				367
#define WEAPON_MODEL_NIGHTVISION		368	// newly added
#define WEAPON_MODEL_INFRARED			369	// newly added
#define WEAPON_MODEL_JETPACK			370	// newly added
#define WEAPON_MODEL_PARACHUTE			371

#define OBJECT_PARACHUTE				3131
#define OBJECT_CJ_CIGGY					1485
#define OBJECT_DYN_BEER_1				1486
#define OBJECT_CJ_BEER_B_2				1543
#define OBJECT_CJ_PINT_GLASS			1546

#define WEAPON_BRASSKNUCKLE				1
#define WEAPON_GOLFCLUB					2
#define WEAPON_NITESTICK				3
#define WEAPON_KNIFE					4
#define WEAPON_BAT						5
#define WEAPON_SHOVEL					6
#define WEAPON_POOLSTICK				7
#define WEAPON_KATANA					8
#define WEAPON_CHAINSAW					9
#define WEAPON_DILDO					10
#define WEAPON_DILDO2					11
#define WEAPON_VIBRATOR					12
#define WEAPON_VIBRATOR2				13
#define WEAPON_FLOWER					14
#define WEAPON_CANE						15
#define WEAPON_GRENADE					16
#define WEAPON_TEARGAS					17
#define WEAPON_MOLTOV					18
#define WEAPON_ROCKET					19
#define WEAPON_ROCKET_HS				20
#define WEAPON_FREEFALLBOMB				21
#define WEAPON_COLT45					22
#define WEAPON_SILENCED					23
#define WEAPON_DEAGLE					24
#define WEAPON_SHOTGUN					25
#define WEAPON_SAWEDOFF					26
#define WEAPON_SHOTGSPA					27
#define WEAPON_UZI						28
#define WEAPON_MP5						29
#define WEAPON_AK47						30
#define WEAPON_M4						31
#define WEAPON_TEC9						32
#define WEAPON_RIFLE					33
#define WEAPON_SNIPER					34
#define WEAPON_ROCKETLAUNCHER			35
#define WEAPON_HEATSEEKER				36
#define WEAPON_FLAMETHROWER				37
#define WEAPON_MINIGUN					38
#define WEAPON_SATCHEL					39
#define WEAPON_BOMB						40
#define WEAPON_SPRAYCAN					41
#define WEAPON_FIREEXTINGUISHER			42
#define WEAPON_CAMERA					43
#define WEAPON_NIGHTVISION				44
#define WEAPON_INFRARED					45
#define WEAPON_PARACHUTE				46
#define WEAPON_ARMOUR					47
#define WEAPON_VEHICLE					49
#define WEAPON_HELIBLADES				50
#define WEAPON_EXPLOSION				51
#define WEAPON_DROWN					53
#define WEAPON_COLLISION				54
