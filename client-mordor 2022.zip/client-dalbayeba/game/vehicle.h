#pragma once

#include "common.h"

enum E_HANDLING_PARAMS
{
	hpMaxSpeed,
	hpAcceleration,
	hpGear,
	hpEngineInertion,
	hpMass,
	hpMassTurn,

	hpBrakeDeceleration,
	hpTractionMultiplier,
	hpTractionLoss,
	hpTractionBias,
	hpSuspensionLowerLimit,
	hpSuspensionBias,

	hpWheelSize,

	hpMax
};

void* GetSuspensionLinesFromModel(int nModelIndex, int& numWheels);
uint8_t* GetCollisionDataFromModel(int nModelIndex);

class CVehicle : public CEntity
{
public:
	CVehicle(int iType, float fPosX, float fPosY, float fPosZ, float fRotation = 0.0f, bool bSiren = false);
	~CVehicle();

	void LinkToInterior(int iInterior);
	void SetColor(int iColor1, int iColor2);

	void SetHealth(float fHealth);
	float GetHealth();

	// 0.3.7
	bool IsOccupied();

	// 0.3.7
	void SetInvulnerable(bool bInv);
	// 0.3.7
	bool IsDriverLocalPlayer();
	// 0.3.7
	bool HasSunk();

	void ProcessMarkers();

	void RemoveEveryoneFromVehicle();

	void SetWheelPopped(uint8_t bytePopped);
	void SetDoorState(int iState);

	void UpdateDamageStatus(uint32_t dwPanelDamage, uint32_t dwDoorDamage, uint8_t byteLightDamage, uint8_t byteTireDamage);

	unsigned int GetVehicleSubtype();

	void SetEngineState(bool bState);
	void SetLightState(bool bState);
	void SetBonnetState(int iState);
	void SetBootState(int iState);
	
	void SetSirenOn(uint8_t byteState);
	uint8_t IsSirenOn();
	
	void AttachTrailer();
	void DetachTrailer();
	void SetTrailer(CVehicle* pTrailer);
	CVehicle* GetTrailer();
	
	//void SetHandlingData(std::vector<SHandlingData>& vHandlingData);
	void ResetVehicleHandling();
	
	void ProcessDamage();
	void GetDamageStatusEncoded(uint8_t* byteTyreFlags, uint8_t* byteLightFlags, uint32_t* dwDoorFlags, uint32_t *dwPanelFlags);
	
	/* CDamageManager functions */
	uint8_t GetWheelStatus(eWheelPosition bWheel);
	void SetWheelStatus(eWheelPosition bWheel, uint8_t bTireStatus);
	void SetPanelStatus(uint8_t bPanel, uint8_t bPanelStatus);
	void SetPanelStatus(uint32_t ulPanelStatus);
	uint8_t GetPanelStatus(uint8_t bPanel);
	uint32_t GetPanelStatus();
	void SetLightStatus(uint8_t bLight, uint8_t bLightStatus);
	void SetLightStatus(uint8_t ucStatus);
	uint8_t GetLightStatus(uint8_t bLight);
	uint8_t GetDoorStatus(eDoors bDoor);
	void SetDoorStatus(eDoors bDoor, uint8_t bDoorStatus, bool spawnFlyingComponen);
	void SetDoorStatus(uint32_t dwDoorStatus, bool spawnFlyingComponen);
	void SetBikeWheelStatus(uint8_t bWheel, uint8_t bTireStatus);
	uint8_t GetBikeWheelStatus(uint8_t bWheel);	
	bool HasDamageModel();

private:
	void CopyGlobalSuspensionLinesToPrivate();
	

public:
	VEHICLE_TYPE	*m_pVehicle;
	bool 			m_bIsLocked;
	bool			m_bIsEngineOn;
	bool			m_bIsLightsOn;
	CVehicle		*m_pTrailer;
	uint32_t		m_dwMarkerID;
	bool 			m_bIsInvulnerable;
	bool 			m_bDoorsLocked;
	uint8_t			m_byteObjectiveVehicle; // Is this a special objective vehicle? 0/1
	uint8_t			m_bSpecialMarkerEnabled;
	
	// Damage status
	uint8_t			m_byteTyreStatus;
	uint8_t			m_byteLightStatus;
	uint32_t		m_dwDoorStatus;
	uint32_t		m_dwPanelStatus;
	
	/*tHandlingData* m_pCustomHandling;
	
	bool m_bWheelAlignmentX;
	float m_fWheelAlignmentX;

	bool m_bWheelAlignmentY;
	float m_fWheelAlignmentY;

	bool m_bWheelSize;
	float m_fWheelSize;

	bool m_bWheelWidth;
	float m_fWheelWidth;

	bool m_bWheelOffsetX;
	float m_fWheelOffsetX;

	bool m_bWheelOffsetY;
	float m_fWheelOffsetY;

	float m_fNewOffsetX;
	float m_fNewOffsetY;

	bool m_bWasWheelOffsetProcessedX;
	bool m_bWasWheelOffsetProcessedY;
	uint32_t m_uiLastProcessedWheelOffset;
	
	void* m_pSuspensionLines;
	bool bHasSuspensionLines;	

	MATRIX4X4 m_vInitialWheelMatrix[4];
	*/

	uint8_t			m_byteColor1;
	uint8_t			m_byteColor2;
	bool 			m_bColorChanged;
};