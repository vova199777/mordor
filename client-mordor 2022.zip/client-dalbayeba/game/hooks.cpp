#include "../main.h"
#include "../util/armhook.h"
#include "RW/RenderWare.h"
#include "game.h"
#include "net/netgame.h"
#include "gui/gui.h"

#include <jni.h>

#include "audiostream.h"
//#include "removebuilding.h"

#include "settings.h"
#include "chatwindow.h"

#include "world.h"

//#include "CHandlingDefault.h"

#include "../vendor/hash/md5.h"

#include "../vendor/ini/config.h"

extern CNetGame *pNetGame;
extern CGUI *pGUI;
extern CSettings *pSettings;

extern CGame *pGame;

extern CChatWindow *pChatWindow;

extern CAudioStream *pAudioStream;

//extern CRemoveBuilding *pRemoveBuilding;

extern CWorld *pWorld;

extern bool screen;

// Neiae/SAMP
bool g_bPlaySAMP = false;

void InitSAMP();
void InitInMenu();
void MainLoop();
void HookCPad();

void RwGrabScreen(RwCamera *cam);

extern int g_iLagCompensation;

extern "C" JNIEXPORT void JNICALL Java_com_nvidia_dev_1one_NvEventQueueActivity_sendResponseClient(JNIEnv *env, jobject thiz,jint button_state,jint listitem,jbyteArray inputtext, jint dialog_id)
{
	if(pNetGame)
	{
		jboolean isCopy;
		
		jbyte* pText = env->GetByteArrayElements(inputtext, &isCopy);
		jsize length = env->GetArrayLength(inputtext);

		std::string str((char*)pText, length);
		
		std::string get_str = str;

		env->ReleaseByteArrayElements(inputtext, pText, JNI_ABORT);
		
		char szDialogInputBuf[100];
		memset(szDialogInputBuf, 0, 100);
		strcpy(szDialogInputBuf, get_str.c_str());
		
		pNetGame->SendDialogResponse(dialog_id, button_state, listitem, szDialogInputBuf);
	}
}


/* ================ ie?oee aey ani. anoaaie =================== */

extern "C" uintptr_t get_lib() 
{
 	return g_libGTASA;
}

/* ====================================================== */

struct stFile
{
	int isFileExist;
	FILE *f;
};

stFile* (*NvFOpen)(const char*, const char*, int, int);
stFile* NvFOpen_hook(const char* r0, const char* r1, int r2, int r3)
{
	lastfunc("h1");
	DebugHook("h1 start");
	
	char path[0xFF] = { 0 };
	
	//Log("NvFOpen %s",r1);
	
	// ----------------------------
	if(!strncmp(r1+12, BOEV("mainV1.scm"), 10))
	{
		//sprintf(path, BOEV("%sSAMP/main.scm"), g_pszStorage);
		sprintf(path, BOEV("%sSAMP/mainone.scm"), g_pszStorage);
		Log("Loading mainV1.scm..");
		//Log("md5file: %s\n", md5file(path).c_str());
		if(strncmp(BOEV("ab72a2f3d2ec5cc7a6fa9454e323e289"),md5file(path).c_str(),s2d(BOEV("32"))) != 0)
		{
			Log("[anti-bypass] mainone.scm not original!");
			std::terminate();
		}
		else
		{
			Log("[anti-bypass] mainone.scm loaded");
		}		
		goto open;
	}
	// ----------------------------
	if(!strncmp(r1+12, BOEV("SCRIPTV1.IMG"), 12))
	{
		//sprintf(path, BOEV("%sSAMP/script.img"), g_pszStorage);
		sprintf(path, BOEV("%sSAMP/scriptone.img"), g_pszStorage);
		Log("Loading script.img..");
		//Log("md5file: %s\n", md5file(path).c_str());
		if(strncmp(BOEV("6e142bb5dd5ec20af8fbd63f9ad4b457"),md5file(path).c_str(),s2d(BOEV("32"))) != 0)
		{
			Log("[anti-bypass] scriptone.img not original!");
			std::terminate();
		}
		else
		{
			Log("[anti-bypass] scriptone.img loaded");
		}		
		goto open;
	}
	//-----------------------------
	if(!strncmp(r1, BOEV("DATA/GTA.DAT"), 12))
	{
		sprintf(path, BOEV("%s/SAMP/gta.dat"), g_pszStorage);
		Log("Loading gta.dat..");
		//Log("md5file: %s\n", md5file(path).c_str());
		if(strncmp(BOEV("d8caaaa7f4fff9e5c2703d6690f43771"),md5file(path).c_str(),s2d(BOEV("32"))) != 0)
		{
			Log("[anti-bypass] gta.dat not original!");
			std::terminate();
		}
		else
		{
			Log("[anti-bypass] gta.dat loaded");
		}		
		goto open;
		
	}	
	// ----------------------------
	if(!strncmp(r1, BOEV("DATA/PEDS.IDE"), 13))
	{
		sprintf(path, BOEV("%s/SAMP/peds.ide"), g_pszStorage);
		Log("Loading peds.ide..");
		//Log("md5file: %s\n", md5file(path).c_str());			
		goto open;
	}
	// ----------------------------
	if(!strncmp(r1, BOEV("DATA/VEHICLES.IDE"), 17))
	{
		sprintf(path, BOEV("%s/SAMP/vehicles.ide"), g_pszStorage);
		///sprintf(path, BOEV("%s/vehicles.ide"), g_pszStorage);
		Log("Loading vehicles.ide..");
		//Log("md5file: %s\n", md5file(path).c_str());	
		if(strncmp(BOEV("404582d8126d6e86c6a34067d14c893e"),md5file(path).c_str(),s2d(BOEV("32"))) != 0)
		{
			Log("[anti-bypass] vehicles.ide not original!");
			std::terminate();
			//Log("md5: %s",md5file(path).c_str());
		}
		else
		{
			Log("[anti-bypass] vehicles.ide loaded");
		}		
		goto open;
	}	
	// ----------------------------
	if(!strncmp(r1, BOEV("DATA/HANDLING.CFG"), 17))
	{
		sprintf(path, BOEV("%s/SAMP/handling.cfg"), g_pszStorage);
		Log("Loading handling.cfg..");
		//Log("md5file: %s\n", md5file(path).c_str());
		if(strncmp(BOEV("351ef92fc22fa3c1042dd26b1cd73a30"),md5file(path).c_str(),s2d(BOEV("32"))) != 0)
		{
			Log("[anti-bypass] handling.cfg not original!");
			std::terminate();
		}
		else
		{
			Log("[anti-bypass] handling.cfg loaded");
		}		
		goto open;
	}	
	// ----------------------------
	if(!strncmp(r1, BOEV("DATA/WEAPON.DAT"), 15))
	{
		sprintf(path, BOEV("%s/SAMP/weapon.dat"), g_pszStorage);
		Log("Loading weapon.dat..");
		if(strncmp(BOEV("0a9bb49003680364f9f9768e9bcea982"),md5file(path).c_str(),s2d(BOEV("32"))) != 0)
		{
			Log("[anti-bypass] weapon.dat not original!");
			std::terminate();
		}
		else
		{
			Log("[anti-bypass] weapon.dat loaded");
		}
		goto open;
	}	
	
	DebugHook("h1 end");

orig:
	return NvFOpen(r0, r1, r2, r3);

open:
	stFile *st = (stFile*)malloc(8);
	st->isFileExist = false;
	
	FILE *f  = fopen(path, "rb");
	if(f)
	{
		st->isFileExist = true;
		st->f = f;
		return st;
	}
	else
	{
		Log("NVFOpen hook | Error: file not found (%s)", path);
		free(st);
		st = nullptr;
		return 0;
	}
}

/* ====================================================== */

bool bGameStarted = false;
void (*Render2dStuff)();
void Render2dStuff_hook()
{
	lastfunc("h2");
	DebugHook("h2 start");
	bGameStarted = true;
	MainLoop();	

	Render2dStuff();
	DebugHook("h2 end");
	return;
}

/* ====================================================== */

// CGame::InitialiseRenderWare
void (*InitialiseRenderWare)();
void InitialiseRenderWare_hook()
{
	lastfunc("h3");
	DebugHook("h3 start");
	Log("Loading \"samp\" cd..");

	InitialiseRenderWare();
	// TextureDatabaseRuntime::Load()
	(( void (*)(const char*,int,int))(pack("0x1BF244")+1))(BOEV("samp"),0,5);
	
	(( void (*)(const char*,int,int))(pack("0x1BF244")+1))(BOEV("cars"),0,5);
	
	DebugHook("h3 end");
	return;
}

/* ====================================================== */

void RenderSplashScreen();
void (*CLoadingScreen_DisplayPCScreen)();
void CLoadingScreen_DisplayPCScreen_hook()
{
	lastfunc("h4");
	DebugHook("h4 start");
	
	RwCamera* camera = *(RwCamera**)(pack("0x95B064"));

	if(RwCameraBeginUpdate(camera))
	{
		DefinedState2d();
		(( void (*)())(pack("0x5519C8")+1))(); // CSprite2d::InitPerFrame()
		RwRenderStateSet(rwRENDERSTATETEXTUREADDRESS, (void*)rwTEXTUREADDRESSCLAMP);
		(( void (*)(bool))(pack("0x198010")+1))(0); // emu_GammaSet()
		RenderSplashScreen();
		RwCameraEndUpdate(camera);
		RwCameraShowRaster(camera, 0, 0);
	}

	DebugHook("h4 end");
	return;
}

/* ====================================================== */

void (*TouchEvent)(int, int, int posX, int posY);
void TouchEvent_hook(int type, int num, int posX, int posY)
{
	//lastfunc("h5");
	//if(pChatWindow) pChatWindow->AddDebugMessage(">> %d %d %d %d", type, num, posX, posY);
	
	bool bRet = pGUI->OnTouchEvent(type, num, posX, posY);

	if(bRet) 
		return TouchEvent(type, num, posX, posY);
}

/* ====================================================== */

void (*CStreaming_InitImageList)();
void CStreaming_InitImageList_hook()
{
	lastfunc("h6");
	DebugHook("h6 start");
	
	char* ms_files = (char*)(g_libGTASA+0x6702FC);
	ms_files[0] = 0;
	*(uint32_t*)&ms_files[44] = 0;
	ms_files[48] = 0;
	*(uint32_t*)&ms_files[92] = 0;
	ms_files[96] = 0;
	*(uint32_t*)&ms_files[140] = 0;
	ms_files[144] = 0;
	*(uint32_t*)&ms_files[188] = 0;
	ms_files[192] = 0;
	*(uint32_t*)&ms_files[236] = 0;
	ms_files[240] = 0;
	*(uint32_t*)&ms_files[284] = 0;
	ms_files[288] = 0;
	*(uint32_t*)&ms_files[332] = 0;
	ms_files[336] = 0;
	*(uint32_t*)&ms_files[380] = 0;

	((uint32_t (*)(char*, uint32_t))(pack("0x28E7B1")))(BOEV("TEXDB\\GTA3.IMG"), 1);	
	((uint32_t (*)(char*, uint32_t))(pack("0x28E7B1")))(BOEV("TEXDB\\GTA_INT.IMG"), 1);
	((uint32_t (*)(char*, uint32_t))(pack("0x28E7B1")))(BOEV("TEXDB\\SAMP.IMG"), 1);
	((uint32_t (*)(char*, uint32_t))(pack("0x28E7B1")))(BOEV("TEXDB\\SAMPCOL.IMG"), 1);
	
	((uint32_t (*)(char*, uint32_t))(pack("0x28E7B1")))(BOEV("TEXDB\\CARS.IMG"), 1);
	
	DebugHook("h6 end");
}

/* ====================================================== */
typedef struct _PED_MODEL
{
	uintptr_t 	vtable;
	uint8_t		data[88];
} PED_MODEL; // SIZE = 92

PED_MODEL PedsModels[380]; //315
int PedsModelsCount = 0;

PED_MODEL* (*CModelInfo_AddPedModel)(int id);
PED_MODEL* CModelInfo_AddPedModel_hook(int id)
{
	//Log("loading skin model %d", id);
	lastfunc("h7");

	PED_MODEL* model = &PedsModels[PedsModelsCount];
	memset(model, 0, sizeof(PED_MODEL));
    model->vtable = (uintptr_t)(pack("0x5C6E90"));

    // CClumpModelInfo::CClumpModelInit()
    (( uintptr_t (*)(PED_MODEL*))(*(void**)(model->vtable+0x1C)))(model);

    *(PED_MODEL**)(pack("0x87BF48")+(id*4)) = model; // CModelInfo::ms_modelInfoPtrs

	PedsModelsCount++;
	return model;
}
/* ====================================================== */

typedef struct _OBJECT_MODEL
{
	uintptr_t 	vtable;
	uint8_t		data[52];
} OBJECT_MODEL; // SIZE = 56

OBJECT_MODEL ObjsModels[22000];
int ObjsModelsCount = 0;

OBJECT_MODEL* (*CModelInfo_AddAtomicModel)(int id);
OBJECT_MODEL* CModelInfo_AddAtomicModel_hook(int id)
{
	//Log("loading object model %d", id);

	OBJECT_MODEL* model = &ObjsModels[ObjsModelsCount];
	memset(model, 0, sizeof(OBJECT_MODEL));
    model->vtable = (uintptr_t)(g_libGTASA+0x5C6C68);

    // CClumpModelInfo::CClumpModelInit()
    (( uintptr_t (*)(OBJECT_MODEL*))(*(void**)(model->vtable+0x1C)))(model);

    *(OBJECT_MODEL**)(g_libGTASA+0x87BF48+(id*4)) = model; // CModelInfo::ms_modelInfoPtrs

	ObjsModelsCount++;
	return model;
}

/* ====================================================== */
typedef struct _VEHICLE_MODEL
{
	uintptr_t 	vtable;
	uint8_t		data[932];
} VEHICLE_MODEL; // SIZE = 936

VEHICLE_MODEL VehicleModels[370];
int VehicleModelsCount = 0;

VEHICLE_MODEL* (*CModelInfo_AddVehicleModel)(int id);
VEHICLE_MODEL* CModelInfo_AddVehicleModel_hook(int id)
{
	/*VEHICLE_MODEL* model = &VehicleModels[VehicleModelsCount];
	memset(model, 0, sizeof(VEHICLE_MODEL));

	((void(*)(void* thiz))(g_libGTASA + 0x00337AA0 + 1))((void*)model); // CVehicleModelInfo::CVehicleModelInfo();

	model->vtable = (uintptr_t)(g_libGTASA + 0x005C6EE0);			// assign CVehicleModelInfo vmt

	((uintptr_t(*)(VEHICLE_MODEL*))(*(void**)(model->vtable + 0x1C)))(model); // CVehicleModelInfo::Init()

	*(VEHICLE_MODEL * *)(g_libGTASA + 0x87BF48 + (id * 4)) = model; // CModelInfo::ms_modelInfoPtrs

	VehicleModelsCount++;
	*/
	VEHICLE_MODEL* model = &VehicleModels[VehicleModelsCount];
	memset(model, 0, sizeof(VEHICLE_MODEL));
	model->vtable = (uintptr_t)(g_libGTASA+0x005C6EE0);
	
	// CClumpModelInfo::CClumpModelInit()
    (( uintptr_t (*)(VEHICLE_MODEL*))(*(void**)(model->vtable+0x1C)))(model);
	
	*(VEHICLE_MODEL * *)(g_libGTASA + 0x87BF48 + (id * 4)) = model;
	
	VehicleModelsCount++;
	
	return model;
}
/* ====================================================== */

uint32_t (*CRadar__GetRadarTraceColor)(uint32_t color, uint8_t bright, uint8_t friendly);
uint32_t CRadar__GetRadarTraceColor_hook(uint32_t color, uint8_t bright, uint8_t friendly)
{
	return TranslateColorCodeToRGBA(color);
}

int (*CRadar__SetCoordBlip)(int r0, float X, float Y, float Z, int r4, int r5, char* name);
int CRadar__SetCoordBlip_hook(int r0, float X, float Y, float Z, int r4, int r5, char* name)
{
	if(pNetGame && !strncmp(name, BOEV("CODEWAY"), 7))
	{
		float findZ = (( float (*)(float, float))(pack("0x3C3DD8")+1))(X, Y);
		findZ += 1.5f;

		//Log("OnPlayerClickMap: %f, %f, %f", X, Y, Z);
		RakNet::BitStream bsSend;
		bsSend.Write(X);
		bsSend.Write(Y);
		bsSend.Write(findZ);
		pNetGame->GetRakClient()->RPC(&RPC_MapMarker, &bsSend, HIGH_PRIORITY, RELIABLE, 0, false, UNASSIGNED_NETWORK_ID, nullptr);
	}

	return CRadar__SetCoordBlip(r0, X, Y, Z, r4, r5, name);
}

uint8_t bGZ = 0;
void (*CRadar__DrawRadarGangOverlay)(uint8_t v1);
void CRadar__DrawRadarGangOverlay_hook(uint8_t v1)
{
	//Log("CRadar__DrawRadarGangOverlay");
	bGZ = v1;
	if (pNetGame && pNetGame->GetGangZonePool())
	{
		if(pGame->m_freezed == true)
		{
			pNetGame->GetGangZonePool()->Draw();
		}
	}
}

uint32_t dwParam1, dwParam2;
extern "C" void pickup_ololo()
{
	if(pNetGame && pNetGame->GetPickupPool())
	{
		CPickupPool *pPickups = pNetGame->GetPickupPool();
		pPickups->PickedUp( ((dwParam1-(pack("0x70E264")))/0x20) );
	}
}

__attribute__((naked)) void PickupPickUp_hook()
{
	//LOGI("PickupPickUp_hook");

	// calculate and save ret address
	__asm__ volatile("push {lr}\n\t"
					"push {r0}\n\t"
					"blx get_lib\n\t"
					"add r0, #0x2D0000\n\t"
					"add r0, #0x009A00\n\t"
					"add r0, #1\n\t"
					"mov r1, r0\n\t"
					"pop {r0}\n\t"
					"pop {lr}\n\t"
					"push {r1}\n\t");
	
	// 
	__asm__ volatile("push {r0-r11, lr}\n\t"
					"mov %0, r4" : "=r" (dwParam1));

	__asm__ volatile("blx pickup_ololo\n\t");


	__asm__ volatile("pop {r0-r11, lr}\n\t");

	// restore
	__asm__ volatile("ldrb r1, [r4, #0x1C]\n\t"
					"sub.w r2, r1, #0xD\n\t"
					"sub.w r2, r1, #8\n\t"
					"cmp r1, #6\n\t"
					"pop {pc}\n\t");
}

extern "C" bool NotifyEnterVehicle(VEHICLE_TYPE *_pVehicle)
{
    //Log("NotifyEnterVehicle");
 
    if(!pNetGame) return false;
 
    CVehiclePool *pVehiclePool = pNetGame->GetVehiclePool();
    CVehicle *pVehicle;
    VEHICLEID VehicleID = pVehiclePool->FindIDFromGtaPtr(_pVehicle);
 
    if(VehicleID == INVALID_VEHICLE_ID) return false;
    if(!pVehiclePool->GetSlotState(VehicleID)) return false;
    pVehicle = pVehiclePool->GetAt(VehicleID);
    if(pVehicle->m_bDoorsLocked) return false;
    if(pVehicle->m_pVehicle->entity.nModelIndex == TRAIN_PASSENGER) return false;
 
    if(pVehicle->m_pVehicle->pDriver &&
        pVehicle->m_pVehicle->pDriver->dwPedType != 0)
        return false;
 
    CLocalPlayer *pLocalPlayer = pNetGame->GetPlayerPool()->GetLocalPlayer();
 
    //if(pLocalPlayer->GetPlayerPed() && pLocalPlayer->GetPlayerPed()->GetCurrentWeapon() == WEAPON_PARACHUTE)
    //  pLocalPlayer->GetPlayerPed()->SetArmedWeapon(0);
 
    pLocalPlayer->SendEnterVehicleNotification(VehicleID, false);
 
    return true;
}

void (*CTaskComplexEnterCarAsDriver)(uint32_t thiz, uint32_t pVehicle);
extern "C" void call_taskEnterCarAsDriver(uintptr_t a, uint32_t b)
{
	CTaskComplexEnterCarAsDriver(a, b);
}
void __attribute__((naked)) CTaskComplexEnterCarAsDriver_hook(uint32_t thiz, uint32_t pVehicle)
{
    __asm__ volatile("push {r0-r11, lr}\n\t"
                    "mov r2, lr\n\t"
                    "blx get_lib\n\t"
                    "add r0, #0x3A0000\n\t"
                    "add r0, #0xEE00\n\t"
                    "add r0, #0xF7\n\t"
                    "cmp r2, r0\n\t"
                    "bne 1f\n\t" // !=
                    "mov r0, r1\n\t"
                    "blx NotifyEnterVehicle\n\t" // call NotifyEnterVehicle
                    "1:\n\t"  // call orig
                    "pop {r0-r11, lr}\n\t"
    				"push {r0-r11, lr}\n\t"
    				"blx call_taskEnterCarAsDriver\n\t"
    				"pop {r0-r11, pc}");
}

void (*CTaskComplexLeaveCar)(uintptr_t** thiz, VEHICLE_TYPE *pVehicle, int iTargetDoor, int iDelayTime, bool bSensibleLeaveCar, bool bForceGetOut);
void CTaskComplexLeaveCar_hook(uintptr_t** thiz, VEHICLE_TYPE *pVehicle, int iTargetDoor, int iDelayTime, bool bSensibleLeaveCar, bool bForceGetOut) 
{
 	uintptr_t dwRetAddr = 0;
 	__asm__ volatile ("mov %0, lr" : "=r" (dwRetAddr));
 	dwRetAddr -= g_libGTASA;
 
 	if (dwRetAddr == 0x3AE905 || dwRetAddr == 0x3AE9CF) 
 	{
 		if (pNetGame) 
 		{
 			if (GamePool_FindPlayerPed()->pVehicle == (uint32_t)pVehicle) 
 			{
 				CVehiclePool *pVehiclePool=pNetGame->GetVehiclePool();
 				VEHICLEID VehicleID=pVehiclePool->FindIDFromGtaPtr((VEHICLE_TYPE *)GamePool_FindPlayerPed()->pVehicle);
 				CLocalPlayer *pLocalPlayer = pNetGame->GetPlayerPool()->GetLocalPlayer();
 				pLocalPlayer->SendExitVehicleNotification(VehicleID);
 			}
 		}
 	}
 
 	(*CTaskComplexLeaveCar)(thiz, pVehicle, iTargetDoor, iDelayTime, bSensibleLeaveCar, bForceGetOut);
}

//2.0 adaptation

bool file_exist(const char* name)
{
    if (FILE *file = fopen(name, BOEV("r"))) 
	{
        fclose(file);
        return true;
    } 
	else 
	{
        return false;
    }   
}

uintptr_t FindUselessLibrary(const char* library)
{
    char filename[0xFF] = {0},
    buffer[2048] = {0};
    FILE *fp = 0;
    uintptr_t address = 0;

    sprintf( filename, BOEV("/proc/%d/maps"), getpid() );

    fp = fopen( filename, BOEV("rt") );
    if(fp == 0)
    {
        Log("ERROR: can't open file %s", filename);
        goto done;
    }

    while(fgets(buffer, sizeof(buffer), fp))
    {
        //if( strstr( buffer, library ) )
        //{
			//__android_log_print(ANDROID_LOG_INFO, "anus", "md5file: %s", md5file(buffer).c_str());
		//	Log("lib path: %s",buffer);
        //    address = (uintptr_t)strtoul( buffer, 0, 16 );
            //break;
        //}
		Log("lib path: %s",buffer);
    }

    done:

    if(fp)
      fclose(fp);

    return address;
}

int (*OS_FileOpen)(int a1, uintptr_t **a2, const char *a3, int a4);
int OS_FileOpen_hook(int a1, uintptr_t **a2, const char *a3, int a4)
{
	//Log("a1 %d a2 %d a3 %s a4 %d",a1,a2,a3,a4);
	
	//if(pChatWindow) pChatWindow->AddDebugMessage("a3 %s",a3);
	//Log("a3 %s",a3);
	
	lastfunc("h14");
	DebugHook("h14 start");
	
	//AND_GetAndroidBuildinfo
	//char* test = (( char* (*)(int))(g_libGTASA+0x26BCD0+1))(1);
	//Log("test %s",test);
	
	static bool get_storage = false;
	g_pszStorage = (const char*)(pack("0x63C4B8"));
	if(!get_storage)
	{
		if(!g_pszStorage)
		{
			Log("Error: storage path not found!");
			std::terminate();
			return 0;
		}		
		
		Log("Load game client 1.08, version: %d", CLIENT_VERS);

		Log("Storage: %s", g_pszStorage);
		
		//check and read/write sens.ini
		char pathtmp[0xFF] = { 0 };
		sprintf(pathtmp, BOEV("%s/SAMP/sens.ini"), g_pszStorage);
		
		ini_table_s* config = ini_table_create();
		if (!ini_table_read_from_file(config, pathtmp)) 
		{
			Log("[SENSIVITY] sens.ini does not exist! Creating file!");
			
			for(int i = 0; i < 18; i++)
			{
				char table_entry[10] = { 0 };
				sprintf(table_entry, BOEV("lineX%d"),i);
				ini_table_create_entry_as_int(config, "sens", table_entry, 0);
				sprintf(table_entry, BOEV("lineY%d"),i);
				ini_table_create_entry_as_int(config, "sens", table_entry, 0);
			}
			ini_table_write_to_file(config, pathtmp);
		}
		else 
		{
			for(int i = 0; i < 18; i++)
			{
				char table_entry[10] = { 0 };
				sprintf(table_entry, BOEV("lineX%d"),i);
				sensx[i] = ini_table_get_entry_as_int(config, "sens", table_entry, 0);
				sprintf(table_entry, BOEV("lineY%d"),i);
				sensy[i] = ini_table_get_entry_as_int(config, "sens", table_entry, 0);				
				//debug
				///Log("sens[%d] = %d", i, ini_table_get_entry_as_int(config, "sens", table_entry,0));
			}
		}
		ini_table_destroy(config);		
		
		//FindUselessLibrary("libGTASAONE.so");
		
		Log(">> Checking for SAMP files...");
		
		char path[0xFF] = { 0 };
		
		const char* files[] = { 	BOEV("mainone.scm"),
									BOEV("scriptone.img"),
									BOEV("gta.dat"),
									BOEV("handling.cfg"),
									BOEV("weapon.dat"),
									BOEV("water.dat"),
									BOEV("water1.dat") 
								};
								
		const char* md5hash[] = {	BOEV("ab72a2f3d2ec5cc7a6fa9454e323e289"),
									BOEV("6e142bb5dd5ec20af8fbd63f9ad4b457"),
									BOEV("d8caaaa7f4fff9e5c2703d6690f43771"),
									BOEV("351ef92fc22fa3c1042dd26b1cd73a30"),
									BOEV("0a9bb49003680364f9f9768e9bcea982"),
									BOEV("690400ecc92169d9eaddaaa948903efb"),
									BOEV("16fe5a3e8c57d02eb62a44a96d8b9d39") 
								};
		
		for(int i = 0; i < 7; i++)
		{
			sprintf(path, BOEV("%s/SAMP/%s"), g_pszStorage, files[i]);
			if(!file_exist(path))
			{
				Log(">> File %s not found in folder SAMP",files[i]);
				std::terminate();
			}
			if(strncmp(md5hash[i],md5file(path).c_str(),s2d(BOEV("32"))) != 0)
			{
				Log(">> %s not original!",files[i]);
				std::terminate();
			}
		}
		
		Log(">> SAMP files exist!");

		pSettings = new CSettings();

		get_storage = true;
	}
	
	DebugHook("h14 end");
	return OS_FileOpen(a1,a2,a3,a4);
}

void(*CPools_Initialise)(void);
void CPools_Initialise_hook(void)
{
	//Log("GTA pools initializing..");
	lastfunc("h15");
	DebugHook("h15 start");

	struct PoolAllocator {

		struct Pool {
			void *objects;
			uint8_t *flags;
			uint32_t count;
			uint32_t top;
			uint32_t bInitialized;
		};
		static_assert(sizeof(Pool) == 0x14);

		static Pool* Allocate(size_t count, size_t size) {
			
			Pool *p = new Pool;

			p->objects = new char[size*count];
			p->flags = new uint8_t[count];
			p->count = count;
			p->top = 0xFFFFFFFF;
			p->bInitialized = 1;

			for (size_t i = 0; i < count; i++) {
				p->flags[i] |= 0x80;
				p->flags[i] &= 0x80;
			}

			return p;
		}
	};
	
	// 600000 / 75000 = 8
	static auto ms_pPtrNodeSingleLinkPool	= PoolAllocator::Allocate(100000,	8);		// 75000
	// 72000 / 6000 = 12
	static auto ms_pPtrNodeDoubleLinkPool	= PoolAllocator::Allocate(20000,	12);	// 6000
	// 10000 / 500 = 20
	static auto ms_pEntryInfoNodePool		= PoolAllocator::Allocate(20000,	20);	// 500
	// 279440 / 140 = 1996
	static auto ms_pPedPool					= PoolAllocator::Allocate(240,		1996);	// 140
	// 286440 / 110 = 2604
	static auto ms_pVehiclePool				= PoolAllocator::Allocate(2000,		2604);	// 110
	// 840000 / 14000 = 60
	static auto ms_pBuildingPool			= PoolAllocator::Allocate(20000,	60);	// 14000
	// 147000 / 350 = 420
	static auto ms_pObjectPool				= PoolAllocator::Allocate(3000,		420);	// 350
	// 210000 / 3500 = 60
	static auto ms_pDummyPool				= PoolAllocator::Allocate(40000,	60);	// 3500
	// 487200 / 10150 = 48
	static auto ms_pColModelPool			= PoolAllocator::Allocate(50000,	48);	// 10150
	// 64000 / 500 = 128
	static auto ms_pTaskPool				= PoolAllocator::Allocate(5000,		128);	// 500
	// 13600 / 200 = 68
	static auto ms_pEventPool				= PoolAllocator::Allocate(1000,		68);	// 200
	// 6400 / 64 = 100
	static auto ms_pPointRoutePool			= PoolAllocator::Allocate(200,		100);	// 64
	// 13440 / 32 = 420
	static auto ms_pPatrolRoutePool			= PoolAllocator::Allocate(200,		420);	// 32
	// 2304 / 64 = 36
	static auto ms_pNodeRoutePool			= PoolAllocator::Allocate(200,		36);	// 64
	// 512 / 16 = 32
	static auto ms_pTaskAllocatorPool		= PoolAllocator::Allocate(3000,		32);	// 16
	// 92960 / 140 = 664
	static auto ms_pPedIntelligencePool		= PoolAllocator::Allocate(240,		664);	// 140
	// 15104 / 64 = 236
	static auto ms_pPedAttractorPool		= PoolAllocator::Allocate(200,		236);	// 64

	*(PoolAllocator::Pool**)(pack("0x8B93E0")) = ms_pPtrNodeSingleLinkPool;
	*(PoolAllocator::Pool**)(pack("0x8B93DC")) = ms_pPtrNodeDoubleLinkPool;
	*(PoolAllocator::Pool**)(pack("0x8B93D8")) = ms_pEntryInfoNodePool;
	*(PoolAllocator::Pool**)(pack("0x8B93D4")) = ms_pPedPool;
	*(PoolAllocator::Pool**)(pack("0x8B93D0")) = ms_pVehiclePool;
	*(PoolAllocator::Pool**)(pack("0x8B93CC")) = ms_pBuildingPool;
	*(PoolAllocator::Pool**)(pack("0x8B93C8")) = ms_pObjectPool;
	*(PoolAllocator::Pool**)(pack("0x8B93C4")) = ms_pDummyPool;
	*(PoolAllocator::Pool**)(pack("0x8B93C0")) = ms_pColModelPool;
	*(PoolAllocator::Pool**)(pack("0x8B93BC")) = ms_pTaskPool;
	*(PoolAllocator::Pool**)(pack("0x8B93B8")) = ms_pEventPool;
	*(PoolAllocator::Pool**)(pack("0x8B93B4")) = ms_pPointRoutePool;
	*(PoolAllocator::Pool**)(pack("0x8B93B0")) = ms_pPatrolRoutePool;
	*(PoolAllocator::Pool**)(pack("0x8B93AC")) = ms_pNodeRoutePool;
	*(PoolAllocator::Pool**)(pack("0x8B93A8")) = ms_pTaskAllocatorPool;
	*(PoolAllocator::Pool**)(pack("0x8B93A4")) = ms_pPedIntelligencePool;
	*(PoolAllocator::Pool**)(pack("0x8B93A0")) = ms_pPedAttractorPool;
	
	DebugHook("h15 end");
}

bool is_held = false;
uint32_t (*CPad__GetDisplayVitalStats)(uint32_t thiz, uint32_t cPed);
uint32_t CPad__GetDisplayVitalStats_hook(uint32_t thiz, uint32_t cPed)
{
	lastfunc("h16");
    int IsHeldDown = (( int (*)(int, int))(pack("0x26F254")+1))(160, 1);

	if(IsHeldDown)
	{
		//if(pChatWindow) pChatWindow->AddDebugMessage("Pressed");
	}
	
	return 0;
}

//================ test stand retexture ?? WORK ?? ===================================

/*
uintptr_t GetTextureFor(const char* texname)
{
	Log(">GetTextureFor");
	// TextureDatabaseRuntime::GetTexture
	uintptr_t texture = ((uintptr_t(*)(const char*))(g_libGTASA + 0x1E9CE4 + 1))(texname);
	if (texture == 0) return 0;
	int count = *(int*)(texture + 0x54);
	count++;
	*(int*)(texture + 0x54) = count;
	return texture;
}

uintptr_t AtomicCallback(uintptr_t atomic, uintptr_t* pMaterialTextures)
{
	Log(">AtomicCallback");
	if(pMaterialTextures == nullptr || *(uint8_t*)(atomic) != 1) return atomic;

	uintptr_t geometry = *(uintptr_t*)(atomic + 0x18);
	int iTotalEntries = *(int*)(geometry + 0x24);
	uintptr_t* materials = *(uintptr_t**)(geometry + 0x20);

	for (int i = 0; i < iTotalEntries; i++)
	{
		if (pMaterialTextures[i] != 0)
		{
			*(uintptr_t**)materials[i] = (uintptr_t*)pMaterialTextures[i];
		}
	}

	return atomic;
}

void SetObjectMaterial(uintptr_t rwObject, uintptr_t* pMaterialTextures)
{
	Log(">SetObjectMaterial");
	if (rwObject != 0)
	{
		uintptr_t parent = *(uintptr_t*)(rwObject + 4);
		// RwFrameForAllObjects
		((void (*)(uintptr_t, uintptr_t, uintptr_t*))(g_libGTASA + 0x1D88D8 + 1))(parent, (uintptr_t)AtomicCallback, pMaterialTextures);
	}
}


uintptr_t LoadTextureFromDataBase(const char* dbname, const char* texture)
{
	Log(">LoadTextureFromDataBase");
	// TextureDatabaseRuntime::GetDatabase(dbname)
	uintptr_t db_handle = (( uintptr_t (*)(const char*))(g_libGTASA+0x1EAC8C+1))(dbname);
	if(!db_handle) return 0;

	// TextureDatabaseRuntime::Register(db)
	(( void (*)(uintptr_t))(g_libGTASA+0x1E9BC8+1))(db_handle);
	uintptr_t tex = GetTextureFor(texture);
	// TextureDatabaseRuntime::Unregister(db)
	(( void (*)(uintptr_t))(g_libGTASA+0x1E9C80+1))(db_handle);

	return tex;
}*/

/*uintptr_t LoadTexture(const char* texname)
{
	Log(">LoadTexture");
	static const char* texdb[] = { "samp", "gta3", "gta_int", "player", "txd" };

	for (int i = 0; i < 5; i++)
	{
		uintptr_t texture = LoadTextureFromDataBase(texdb[i], texname);
		if (texture != 0)
		{
			Log(">texture finded");
			return texture;
		}
	}
	
	Log("texture not found");
	return 0;
}*/

//RwTexture* go_hule = nullptr;
//bool load_texture = false;
int g_iLastRenderedObject;
uint32_t (*CObject__Render)(ENTITY_TYPE *thiz);
uint32_t CObject__Render_hook(ENTITY_TYPE *thiz)
{	
	/*ENTITY_TYPE* object = thiz;
	if (pNetGame && object != 0)
	{
		CObject* pObject = pNetGame->GetObjectPool()->GetObjectFromGtaPtr(object);
		//if (pObject && pObject->m_bHasMaterial)
		if (pObject)	
		{
			uintptr_t rwObject = pObject->GetRWObject();
			//uintptr_t m_MaterialTexture[16];
			RwTexture* m_MaterialTexture[16];
			
			//
			if(!load_texture)
			{
				RwImage* hi_png = RtPNGImageRead("./salam/red.png");
				
				RwInt32 width, height, depth, flags;

				RwImageFindRasterFormat(hi_png, rwRASTERTYPETEXTURE, &width, &height, &depth, &flags);

				RwRaster *raster = RwRasterCreate(width, height, depth, flags);

				RwRasterSetFromImage(raster, hi_png);

				RwImageDestroy(hi_png);
				
				go_hule = RwTextureCreate(raster);
				
				load_texture = true;
			}
			
			for(int a = 0; a < 16; a++)
			{
				//m_MaterialTexture[a] = (uintptr_t)LoadTexture("afk_icon");
				//m_MaterialTexture[a] = (RwTexture*)LoadTexture("afk_icon");
				if(a == 0)
				{
					m_MaterialTexture[a] = go_hule;
				}
			}
			
			//SetObjectMaterial(g_libGTASA, rwObject, pObject->m_MaterialTexture);
			SetObjectMaterial(rwObject, (uintptr_t*)m_MaterialTexture);
			((void (*)(void))(g_libGTASA + 0x5D1F49))(); //DeActivateDirectional
			CObject__Render(thiz);
			((int (*)(void))(g_libGTASA + 0x5D1F5D))(); //ActivateDirectional
		}
	}	
	return CObject__Render(thiz);
	*/
	
	if (pNetGame && thiz != 0)
	{
		CObjectPool* pObjectPool = pNetGame->GetObjectPool();
		if (pObjectPool)
		{
			CObject* pObject = pObjectPool->GetObjectFromGtaPtr(thiz);
			if (pObject)
			{
				if (pObject->m_pEntity)
				{
					g_iLastRenderedObject = pObject->m_pEntity->nModelIndex;
					
					if(pSettings->Get().objdebug)
					{
						//reset materials
						memset(materials,0,2048);
						
						//pizdec!
						uintptr_t pAtomic = thiz->pdwRenderWare;
						RpGeometry* pGeom = *(RpGeometry * *)(pAtomic + 24);
						if (!pGeom)
						{
							return CObject__Render(thiz);
						}

						int numMats = pGeom->matList.numMaterials;	
						//if(pChatWindow) pChatWindow->AddDebugMessage("numMats %d [%d]",numMats,g_iLastRenderedObject);

						sprintf(materials,BOEV("numMaterials: %d\n"), numMats);

						// get name textures
						for (int i = 0; i < numMats; i++)
						{
							RpMaterial* pMat = pGeom->matList.materials[i];
							if (!pMat)
							{
								continue;
							}
							
							sprintf(materials,BOEV("%s(%d) %s\n"), materials, i, pMat->texture->name);

							//if(pChatWindow) pChatWindow->AddDebugMessage("id [%d](%d) %s", g_iLastRenderedObject, i, pMat->texture->name);
						}
					}
				}
			}
		}
	}
	return CObject__Render(thiz); // CObject::Render(CObject*)
}

// 51AAE4 ; int __fastcall CVehicle::Render(int result, int, int, int)
int g_iLastRenderedVehicle;
uint32_t (*CVehicle__Render)(ENTITY_TYPE *thiz);
uint32_t CVehicle__Render_hook(ENTITY_TYPE *thiz)
{
	if (pNetGame && thiz != 0)
	{
		CVehiclePool* pVehiclePool = pNetGame->GetVehiclePool();
		if (pVehiclePool)
		{
			VEHICLEID vehId = pVehiclePool->FindIDFromGtaPtr((VEHICLE_TYPE*)thiz);
			if (vehId != INVALID_VEHICLE_ID)
			{
				CVehicle* pVehicle = pVehiclePool->GetAt(vehId);
				if (pVehicle)
				{
					g_iLastRenderedVehicle = pVehicle->m_pEntity->nModelIndex;
				}
			}		
		}
	}
	return CVehicle__Render(thiz);
}

//======================================================================================
//get texture name...
uint32_t (*TextureDatabaseRuntime__GetTexture)(const char *a2);
uint32_t TextureDatabaseRuntime__GetTexture_hook(const char *a2)
{
	//if(a2)
		//Log("Texture %s",a2);
	return TextureDatabaseRuntime__GetTexture(a2);
}

#include "rgba.h"
void (*Render2dStuffAfterFade)();
void Render2dStuffAfterFade_hook()
{
	Render2dStuffAfterFade();
	
	//if game is paused
	if(!*(uint8_t*)(g_libGTASA + 0x8C9BA3))
	{
		if(pSettings && pSettings->Get().DEBUGFPS == true)
		{
			//DisplayFPS
			CFont::SetBackground(0, 0);
			uint32_t backcolor = 0x00000080;
			CFont::SetBackgroundColor(&backcolor);
			CFont::SetScale(0.85, 1.3);
			CFont::SetOrientation(1);
			CFont::SetJustify(0);
			CFont::SetWrapX(640.0);
			CFont::SetProportional(1);
			CFont::SetFontStyle(1);
			CFont::SetEdge(0);
			uint32_t color = 0xFFFFFFFF;
			CFont::SetColor(&color);
			
			char fps_tmp_str[200];
			uint16_t fps_string[200];
				
			//fps counter
			static float framesPerSecond = 0.0f;
			static int fps;
			static float lastTime = 0.0f;
			float currentTime = GetTickCount() * 0.001f;
			++framesPerSecond;
			if (currentTime - lastTime > 1.0f)
			{
				lastTime = currentTime;
				fps = (int)framesPerSecond;
				framesPerSecond = 0;
			}
			
			if(fps > pSettings->Get().fps)
			{
				fps = pSettings->Get().fps;
			}
			
			if(pNetGame)
			{
				pNetGame->UpdatePlayerScoresAndPings();
				CPlayerPool* pPlayerPool = pNetGame->GetPlayerPool();
				sprintf(fps_tmp_str, "FPS: %d~n~PING: %d", fps, pPlayerPool->GetLocalPlayerPing());
			}
			else
			{
				sprintf(fps_tmp_str, "FPS: %d~n~PING: -", fps);
			}
			
			CFont::PrintString(10.0f, RsGlobal->maximumHeight/2, fps_tmp_str);		
		}
	}
	
	if(pGUI && bGameStarted) pGUI->Render();
	return;
}

/*
//5A55F0 SetTextMaterialCB
// перерисовать любую текстуру автомобиля (верт в т.ч.)
uint32_t (*SetTextMaterialCB)(RpMaterial* material, void* data);
uint32_t SetTextMaterialCB_hook(RpMaterial* material, void* data)
{	
	//red
	//material->color.red = 255;
	//green
	//material->color.green = 255;
	//blue
	//material->color.blue = 255;
	
	RwTexture* texture = material->texture;
	if (texture)
	{
		if (texture != (RwTexture *)0xFFFFFFF0)
		{
			Log("name %s",texture->name);
			//if (!strcmp("carplate", texture->name))
			if (!strcmp("vehiclegeneric256", texture->name))
			{
				//red
				material->color.red = 255;
				//green
				material->color.green = 255;
				//blue
				material->color.blue = 255;
			}
			if (!strcmp("vehiclegrunge256", texture->name))
			{
				//red
				material->color.red = 255;
				//green
				material->color.green = 255;
				//blue
				material->color.blue = 255;
			}			
		}
	}
	
	return SetTextMaterialCB(material,data);
}
*/

//uint32_t GetLastRemoveRWObject = 0;

bool allow_reconnect = false;
void gorecon();

uint32_t temprecon = GetTickCount();

void (*CGame__Process)();
void CGame__Process_hook()
{
	lastfunc("h17");
	DebugHook("h17 start");
	CGame__Process();
	
	// for 1.08 92A1AB
	
	/*
	if(*(uint32_t*)(pack("0x96B514")) == 0) //if game not pause
	{
		if(GetTickCount() - GetLastRemoveRWObject > 1000)
		{
			(( void (*)())(g_libGTASA+0x2CFDBC+1))(); // CStreaming::DeleteAllRwObjects
			GetLastRemoveRWObject = GetTickCount();
		}
	}
	*/
	
	*(uint8_t*)(pack("0x63E444")) = 1;
	
	//if game is paused
	if(*(uint8_t*)(g_libGTASA + 0x8C9BA3)) return;

	//MainLoop();
	
	//start reconnect!
	if(allow_reconnect)
	{
		if(GetTickCount() - temprecon < 1000 * 7)
		{
			//todo
		}
		else
		{
			gorecon();
			temprecon = GetTickCount();
			allow_reconnect = false;
		}
	}
	
	if (pNetGame)
	{
		CTextDrawPool* pTextDrawPool = pNetGame->GetTextDrawPool();
		if (pTextDrawPool) 
		{
			pTextDrawPool->SnapshotProcess();
		}
	}
	DebugHook("h17 end");
}

int onDamage(PED_TYPE* issuer, PED_TYPE* damaged)
{
	PED_TYPE *pPedPlayer = GamePool_FindPlayerPed();
	int LocalPed = 0;
	if (!pNetGame) return 0;
	uint32_t v5 = *(uint32_t*)issuer;
	if ( issuer != pPedPlayer && damaged == (PED_TYPE*)(pack("0x5C7A98")) )
		return 1;
	
	//==========================================================
	float *Damage = (float*)issuer; //damage
	int WeaponID = *((uint32_t*)Damage + 3); //id weapon
	int BodyPart = *((uint32_t*)Damage + 2); //bodypart	
	//==========================================================
	
	if (damaged == pPedPlayer)
	{
		LocalPed = 1;
	}
	else if ( (PED_TYPE*)v5 != pPedPlayer )
	{
		return 0;
	}
	//todo
	//if(LocalPed)
	//{
		//todo
		//if(BodyPart != 54) //todo
		if(damaged == pPedPlayer)
		{
			CPlayerPool* pPlayerPool = pNetGame->GetPlayerPool();
			//if(pChatWindow) pChatWindow->AddDebugMessage("[TAKE] %f %d %d",Damage[1],WeaponID,BodyPart);
			pPlayerPool->GetLocalPlayer()->SendTakeDamage(pNetGame->GetPlayerPool()->FindRemotePlayerIDFromGtaPtr((PED_TYPE*)issuer), Damage[1], WeaponID, BodyPart);
		}
		//return 1;
	//}
	if (pNetGame->GetPlayerPool()->FindRemotePlayerIDFromGtaPtr((PED_TYPE*)damaged) != INVALID_PLAYER_ID)
	{
		CPlayerPool* pPlayerPool = pNetGame->GetPlayerPool();
		//if(pChatWindow) pChatWindow->AddDebugMessage("[GIVE] %f %d %d",Damage[1],WeaponID,BodyPart);
		pPlayerPool->GetLocalPlayer()->SendGiveDamage(pNetGame->GetPlayerPool()->FindRemotePlayerIDFromGtaPtr((PED_TYPE*)damaged), Damage[1], WeaponID, BodyPart);
		return 1;
	}
	return 1;
}

//uintptr_t issuer, uintptr_t ped, uint16_t unk, int weaponType, int bodyPart, bool bSpeak
/*uint32_t (*CPedDamageResponseCalculator__ComputeDamageResponse)(uintptr_t issuer, uintptr_t ped, int a3, int weaponType, int bodyPart, bool bSpeak);
uint32_t CPedDamageResponseCalculator__ComputeDamageResponse_hook(uintptr_t issuer, uintptr_t ped, int a3, int weaponType, int bodyPart, bool bSpeak)
{
	lastfunc("h20");
	if(issuer && ped) 
	{
		//float *unk1 = (float*)issuer; //damage
		//int unk2 = *((uint32_t*)unk1 + 3); //id weapon
		//int unk3 = *((uint32_t*)unk1 + 2); //bodypart
		
		float *Damage = (float*)issuer; //damage
		int WeaponID = *((uint32_t*)Damage + 3);		
		
		//onDamage((PED_TYPE*)issuer, (PED_TYPE*)ped);
		RakNet::BitStream bsRPC;
		bsRPC.Write((bool)false);
		bsRPC.Write((PLAYERID)pNetGame->GetPlayerPool()->FindRemotePlayerIDFromGtaPtr((PED_TYPE*)ped));
		bsRPC.Write((float)Damage[1]);
		bsRPC.Write((uint32_t)WeaponID);
		bsRPC.Write((uint32_t)1);
		pNetGame->GetRakClient()->RPC(&RPC_PlayerGiveTakeDamage, &bsRPC, HIGH_PRIORITY, UNRELIABLE_SEQUENCED, 0, false, UNASSIGNED_NETWORK_ID, nullptr);		
	}
	return CPedDamageResponseCalculator__ComputeDamageResponse(issuer, ped, a3, weaponType, bodyPart, bSpeak);
}*/

/*void (*CPedDamageResponseCalculator__ComputeDamageResponse)(uintptr_t* thiz, PED_TYPE* pPed, uintptr_t damageResponse, bool bSpeak);
void CPedDamageResponseCalculator__ComputeDamageResponse_hook(uintptr_t* thiz, PED_TYPE* pPed, uintptr_t damageResponse, bool bSpeak)
{
	if(pNetGame && damageResponse)
	{
		CPlayerPool* pPlayerPool = pNetGame->GetPlayerPool();
		if(pPlayerPool)
		{
			PED_TYPE* pPed2 = *(PED_TYPE**)thiz;
			
			PLAYERID damagedid = pPlayerPool->FindRemotePlayerIDFromGtaPtr(pPed2);
			PLAYERID issuerid = pPlayerPool->FindRemotePlayerIDFromGtaPtr(pPed);
			
			//if(pChatWindow) pChatWindow->AddDebugMessage("damagerid %d | ussuerid %d", damagedid, issuerid);
			
			float *unk1 = (float*)thiz; //damage
			int WeaponID = *((uint32_t*)unk1 + 3); //id weapon
			int BodyPart = *((uint32_t*)unk1 + 2); //bodypart	
			float test_dmg = *((uint32_t*)unk1 + 4); //damage from gun
			
			//test_dmg = test_dmg / 3.03030303;
			
			stPedDamageResponse* tmp_GetDamage = (stPedDamageResponse*)thiz;
			float GetDamage = tmp_GetDamage->fDamage;
			
			//работает когда стреляют в локального игрока
			int aaaa = (int)thiz;
			float* bbbb = (float*)pPed;
			float* v10 = bbbb + 336;
			float v13 = *v10 - *(float *)(aaaa + 4);
			float v11 = bbbb[336];
			float v17 = v11 - v13;			

			//																 -86.20   53.80   140.0
			//																 -132.40  7.60    140.0
			//if(pChatWindow) pChatWindow->AddDebugMessage("stPedDamageResponse %0.2f | %0.2f | %0.2f", v13, v11, v17);
			
			//работает когда локальный игрок стреляет в кого-то
			
			float* v4 = (float *)damageResponse;
			float v5 = (float)(*v4 + v4[1]);
			float v4_1 = (float)*v4;
			float v4_2 = v4[1];
			
			//if(pChatWindow) pChatWindow->AddDebugMessage("stPedDamageResponse %0.2f | %0.2f | %0.2f", unk1[1], v5, *(float *)((int)thiz + 4));

			// self damage like fall damage, drowned, etc
			if(issuerid == INVALID_PLAYER_ID && damagedid == INVALID_PLAYER_ID)
			{
				//PLAYERID playerId = pPlayerPool->GetLocalPlayerID();
				//pPlayerPool->GetLocalPlayer()->SendGiveDamage(playerId, thiz->fDamage, thiz->dwWeapon, thiz->dwBodyPart);
			}

			// give player damage
			if(issuerid != INVALID_PLAYER_ID && damagedid == INVALID_PLAYER_ID)
			{
				//pPlayerPool->GetLocalPlayer()->SendGiveDamage(issuerid, GetDamage, WeaponID, BodyPart);
			}

			// player take damage
			else if(issuerid == INVALID_PLAYER_ID && damagedid != INVALID_PLAYER_ID)
			{
				pPlayerPool->GetLocalPlayer()->SendTakeDamage(damagedid, test_dmg, WeaponID, BodyPart);
			}
		}
	}

	return CPedDamageResponseCalculator__ComputeDamageResponse(thiz, pPed, damageResponse, bSpeak);
}*/

//возможно надо заюзать говно
void ProcessPedDamage(PED_TYPE* pIssuer, PED_TYPE* pDamaged, int bodypart)
{
	if (!pNetGame) return;

	PED_TYPE* pPedPlayer = GamePool_FindPlayerPed();
	if (pDamaged && (pPedPlayer == pIssuer))
	{
		if (pNetGame->GetPlayerPool()->FindRemotePlayerIDFromGtaPtr((PED_TYPE*)pDamaged) != INVALID_PLAYER_ID)
		{
			CPlayerPool* pPlayerPool = pNetGame->GetPlayerPool();
			CAMERA_AIM* caAim = pPlayerPool->GetLocalPlayer()->GetPlayerPed()->GetCurrentAimFix();

			VECTOR aim;
			aim.X = caAim->f1x;
			aim.Y = caAim->f1y;
			aim.Z = caAim->f1z;

			pPlayerPool->GetLocalPlayer()->SendBulletSyncData(pPlayerPool->FindRemotePlayerIDFromGtaPtr((PED_TYPE*)pDamaged), 1, aim, bodypart);
		}
	}
}

uintptr_t (*ComputeDamageResponse)(uintptr_t, uintptr_t, int, int);
uintptr_t ComputeDamageResponse_hooked(uintptr_t issuer, uintptr_t ped, int a3, int a4)
{
	float *unk1 = (float*)issuer; //damage
	int unk3 = *((uint32_t*)unk1 + 2); //bodypart	
	
	ProcessPedDamage((PED_TYPE*)*(uintptr_t*)issuer, (PED_TYPE*)ped,unk3);
	return ComputeDamageResponse(issuer, ped, a3, a4);
}

uint32_t (*CHud__DrawScriptText)(unsigned char text);
uint32_t CHud__DrawScriptText_hook(unsigned char text)
{
	lastfunc("h21");
	DebugHook("h21 start");
	//handler audiostream
	pAudioStream->Process();
	
	DebugHook("h21 end");
	return CHud__DrawScriptText(text);
}

int (*CEntity__Render)(ENTITY_TYPE* pInterface);
int CEntity__Render_hook(ENTITY_TYPE* pInterface)
{
	lastfunc("h22");
	DebugHook("h22 start");
    if(pWorld)
    {
        if(pWorld->ProcessRemovedEntities(pInterface) == false)
            return 0;
    }
	DebugHook("h22 end");
    return CEntity__Render(pInterface);
}

void (*CWorld__ProcessPedsAfterPreRender)();
void CWorld__ProcessPedsAfterPreRender_hook()
{
	lastfunc("h23");
	DebugHook("h23 start");
	CWorld__ProcessPedsAfterPreRender();

	if(pNetGame)
	{
		CPlayerPool *pPlayerPool = pNetGame->GetPlayerPool();

		if(pPlayerPool)
		{
			CLocalPlayer* pLocalPlayer = pPlayerPool->GetLocalPlayer();
			if(pLocalPlayer)
			{
				CPlayerPed *pPlayerPed = pLocalPlayer->GetPlayerPed();

				if(pPlayerPed) 
				{
					pPlayerPed->ProcessAttachedObjects();
				}
			}

			for(int i=0; i<MAX_PLAYERS; i++)
			{
				CRemotePlayer *pRemotePlayer = pPlayerPool->GetAt(i);
				if(pRemotePlayer)
				{
					CPlayerPed *pPlayerPed = pRemotePlayer->GetPlayerPed();
					if(pPlayerPed) 
					{
						pPlayerPed->ProcessAttachedObjects();
					}
				}
			}
		}
	}
	DebugHook("h23 end");
}

char **(*CPhysical__Add)(uintptr_t thiz);
char **CPhysical__Add_hook(uintptr_t thiz)
{
	//if(!thiz)
	//{
	//	Log("physical add nullptr detect");
	//	return 0;
	//}
	
    if(pNetGame)
    {
        CPlayerPed *pPlayerPed = pGame->FindPlayerPed();
        if(pPlayerPed)
        {
            for(size_t i = 0; i < 10; i++)
            {
                if(pPlayerPed->m_bObjectSlotUsed[i])
                {
                    if((uintptr_t)pPlayerPed->m_pAttachedObjects[i]->m_pEntity == thiz)
                    {
						CObject *pObject = pPlayerPed->m_pAttachedObjects[i];
						if(pObject->m_pEntity->mat->pos.X > 20000.0f || pObject->m_pEntity->mat->pos.Y > 20000.0f || pObject->m_pEntity->mat->pos.Z > 20000.0f ||
							pObject->m_pEntity->mat->pos.X < -20000.0f || pObject->m_pEntity->mat->pos.Y < -20000.0f || pObject->m_pEntity->mat->pos.Z < -20000.0f)	
						{
							//if(pChatWindow)
                            //{
                            //    pChatWindow->AddDebugMessage(BOEV("WARNING!!! WARNING!!! WARNING!!! CRASH EXCEPTED!!! LOCAL"));
                            //}
                            return 0;
						}
                    }
                }
            }
        }
 
        CPlayerPool *pPlayerPool = pNetGame->GetPlayerPool();
 
        if(pPlayerPool)
        {
            for(size_t i = 0; i < MAX_PLAYERS; i++)
            {
                if(pPlayerPool->GetSlotState(i))
                {
                    CRemotePlayer *pRemotePlayer = pPlayerPool->GetAt(i);
                    if(pRemotePlayer)
                    {
                        if(pRemotePlayer->GetPlayerPed() && pRemotePlayer->GetPlayerPed()->IsAdded())
                        {
                            CPlayerPed *pPlayerPed = pRemotePlayer->GetPlayerPed();
                            for(size_t i = 0; i < 10; i++)
                            {
                                if(pPlayerPed->m_bObjectSlotUsed[i])
                                {
                                    if((uintptr_t)pPlayerPed->m_pAttachedObjects[i]->m_pEntity == thiz)
                                    {
                                        CObject *pObject = pPlayerPed->m_pAttachedObjects[i];
                                        //if(pObject->m_pEntity->mat->pos.X > 20000.0f || pObject->m_pEntity->mat->pos.Y > 20000.0f || pObject->m_pEntity->mat->pos.Z > 20000.0f)
										if(pObject->m_pEntity->mat->pos.X > 20000.0f || pObject->m_pEntity->mat->pos.Y > 20000.0f || pObject->m_pEntity->mat->pos.Z > 20000.0f ||
											pObject->m_pEntity->mat->pos.X < -20000.0f || pObject->m_pEntity->mat->pos.Y < -20000.0f || pObject->m_pEntity->mat->pos.Z < -20000.0f)	
                                        {
                                            //if(pChatWindow)
                                            //{
                                            //    pChatWindow->AddDebugMessage(BOEV("WARNING!!! WARNING!!! WARNING!!! CRASH EXCEPTED!!!"));
                                            //}
                                            return 0;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
 
    //if(result == 0)
    //{
    //    Log(BOEV("Processing unknown object."));
    //    result = CPhysical__Add(thiz);
    //}
 
    //Log(BOEV("Processed."));
	
	DebugHook("h24 end");
 
    return CPhysical__Add(thiz);
}


void (*CPhysical__RemoveAndAdd)(uintptr_t thiz);
void CPhysical__RemoveAndAdd_hook(uintptr_t thiz)
{
	lastfunc("h25");
	DebugHook("h25 start");
	if (pNetGame)
	{
		CPlayerPed* pPlayerPed = pGame->FindPlayerPed();
		if (pPlayerPed)
		{
			for (size_t i = 0; i < 10; i++)
			{
				if (pPlayerPed->m_bObjectSlotUsed[i])
				{
					if ((uintptr_t)pPlayerPed->m_pAttachedObjects[i]->m_pEntity == thiz)
					{
						CObject* pObject = pPlayerPed->m_pAttachedObjects[i];
						if (pObject->m_pEntity->mat->pos.X > 20000.0f || pObject->m_pEntity->mat->pos.Y > 20000.0f || pObject->m_pEntity->mat->pos.Z > 20000.0f ||
							pObject->m_pEntity->mat->pos.X < -20000.0f || pObject->m_pEntity->mat->pos.Y < -20000.0f || pObject->m_pEntity->mat->pos.Z < -20000.0f)
						{
							//if(pChatWindow)
							//{
							//    pChatWindow->AddDebugMessage(BOEV("WARNING!!! WARNING!!! WARNING!!! CRASH EXCEPTED!!! LOCAL"));
							//}
							return;
						}
					}
				}
			}
		}

		CPlayerPool* pPlayerPool = pNetGame->GetPlayerPool();

		if (pPlayerPool)
		{
			for (size_t i = 0; i < MAX_PLAYERS; i++)
			{
				if (pPlayerPool->GetSlotState(i))
				{
					CRemotePlayer* pRemotePlayer = pPlayerPool->GetAt(i);
					if (pRemotePlayer)
					{
						if (pRemotePlayer->GetPlayerPed() && pRemotePlayer->GetPlayerPed()->IsAdded())
						{
							CPlayerPed* pPlayerPed = pRemotePlayer->GetPlayerPed();
							for (size_t i = 0; i < 10; i++)
							{
								if (pPlayerPed->m_bObjectSlotUsed[i])
								{
									if ((uintptr_t)pPlayerPed->m_pAttachedObjects[i]->m_pEntity == thiz)
									{
										CObject* pObject = pPlayerPed->m_pAttachedObjects[i];
										//if(pObject->m_pEntity->mat->pos.X > 20000.0f || pObject->m_pEntity->mat->pos.Y > 20000.0f || pObject->m_pEntity->mat->pos.Z > 20000.0f)
										if (pObject->m_pEntity->mat->pos.X > 20000.0f || pObject->m_pEntity->mat->pos.Y > 20000.0f || pObject->m_pEntity->mat->pos.Z > 20000.0f ||
											pObject->m_pEntity->mat->pos.X < -20000.0f || pObject->m_pEntity->mat->pos.Y < -20000.0f || pObject->m_pEntity->mat->pos.Z < -20000.0f)
										{
											//if(pChatWindow)
											//{
											//    pChatWindow->AddDebugMessage(BOEV("WARNING!!! WARNING!!! WARNING!!! CRASH EXCEPTED!!!"));
											//}
											return;
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}

	//if(result == 0)
	//{
	//    Log(BOEV("Processing unknown object."));
	//    result = CPhysical__Add(thiz);
	//}

	//Log(BOEV("Processed."));
	
	DebugHook("h25 end");

    return CPhysical__RemoveAndAdd(thiz);
}

signed int (*CBulletInfo_AddBullet)(ENTITY_TYPE* pEntity, WEAPON_SLOT_TYPE* pWeapon, VECTOR vec1, VECTOR vec2);
signed int CBulletInfo_AddBullet_hook(ENTITY_TYPE* pEntity, WEAPON_SLOT_TYPE* pWeapon, VECTOR vec1, VECTOR vec2)
{
	DebugHook("h26 start");
	//CBulletInfo_AddBullet(a1,a2,a3,a4,a5,a6,a7,a8);
	//((void (*)(void))(pack("0x55E170")))(); //CBulletInfo::Update
	vec2.X *= 50.0f;
    vec2.Y *= 50.0f;
    vec2.Z *= 50.0f;
	CBulletInfo_AddBullet(pEntity, pWeapon, vec1, vec2);
	// CBulletInfo::Update
	(( void (*)())(g_libGTASA+0x55E170+1))();
	DebugHook("h26 end");
	return 1;
}

uint32_t (*CWeapon_FireSniper)(WEAPON_SLOT_TYPE *pWeaponSlot, PED_TYPE *pFiringEntity, ENTITY_TYPE *a3, VECTOR *vecOrigin); 
uint32_t CWeapon_FireSniper_hook(WEAPON_SLOT_TYPE *pWeaponSlot, PED_TYPE *pFiringEntity, ENTITY_TYPE *a3, VECTOR *vecOrigin) 
{ 
    if(GamePool_FindPlayerPed() == pFiringEntity) 
    { 
        if(pGame) 
        { 
            CPlayerPed* pPlayerPed = pGame->FindPlayerPed(); 
            if(pPlayerPed) 
			{
				pPlayerPed->FireInstant(); 
			}
		} 
    } 
    return 1; 
}

extern CPlayerPed *g_pCurrentFiredPed;
CPlayerPed *g_pCurrentFiredPed2;
extern BULLET_DATA *g_pCurrentBulletData;

void SendBulletSync(VECTOR *vecOrigin, VECTOR *vecEnd, VECTOR *vecPos, ENTITY_TYPE **ppEntity)
{
	static BULLET_DATA bulletData;
	memset(&bulletData, 0, sizeof(BULLET_DATA));

	bulletData.vecOrigin.X = vecOrigin->X;
  	bulletData.vecOrigin.Y = vecOrigin->Y;
  	bulletData.vecOrigin.Z = vecOrigin->Z;
  	bulletData.vecPos.X = vecPos->X;
  	bulletData.vecPos.Y = vecPos->Y;
  	bulletData.vecPos.Z = vecPos->Z;

  	if(ppEntity) 
	{
  		static ENTITY_TYPE *pEntity;
  		pEntity = *ppEntity;
  		if(pEntity) {
  			if(pEntity->mat) 
			{
  				if(g_iLagCompensation) 
				{
  					bulletData.vecOffset.X = vecPos->X - pEntity->mat->pos.X;
		  			bulletData.vecOffset.Y = vecPos->Y - pEntity->mat->pos.Y;
		  			bulletData.vecOffset.Z = vecPos->Z - pEntity->mat->pos.Z;
  				} 
				else 
				{
  					static MATRIX4X4 mat1;
  					memset(&mat1, 0, sizeof(mat1));

  					static MATRIX4X4 mat2;
		  			memset(&mat2, 0, sizeof(mat2));

		  			RwMatrixOrthoNormalize(&mat2, pEntity->mat);
		  			RwMatrixInvert(&mat1, &mat2);
		  			ProjectMatrix(&bulletData.vecOffset, &mat1, vecPos);
  				}
  			}

  			bulletData.pEntity = pEntity;
  		}
  	}

  	pGame->FindPlayerPed()->ProcessBulletData(&bulletData);
}

uintptr_t (*CWorld__ProcessLineOfSight)(VECTOR*,VECTOR*, VECTOR*, PED_TYPE**, bool, bool, bool, bool, bool, bool, bool, bool);
uintptr_t CWorld__ProcessLineOfSight_hook(VECTOR* vecOrigin, VECTOR* vecEnd, VECTOR* vecPos, PED_TYPE** ppEntity, 
	bool b1, bool b2, bool b3, bool b4, bool b5, bool b6, bool b7, bool b8)
{
	//lastfunc("h19");
	uintptr_t dwRetAddr = 0;
 	__asm__ volatile ("mov %0, lr" : "=r" (dwRetAddr));

 	dwRetAddr -= g_libGTASA;
	
 	if(	dwRetAddr == 0x55E2FE + 1 || // CBulletInfo::Update
 		dwRetAddr == 0x5681BA + 1 ||  // CWeapon::ProcessLineOfSight 1
 		dwRetAddr == 0x567AFC + 1)	// CWeapon::ProcessLineOfSight 2
 	{
 		ENTITY_TYPE *pEntity = nullptr;
 		MATRIX4X4 *pMatrix = nullptr;
 		static VECTOR vecPosPlusOffset;

 		if(g_iLagCompensation != 2)
		{
 			if(g_pCurrentFiredPed != pGame->FindPlayerPed())
			{
 				if(g_pCurrentBulletData)
				{
					if(g_pCurrentBulletData->pEntity)
					{
						if(!pEntity->vtable != g_libGTASA+0x5C7358)
						{
							pMatrix = g_pCurrentBulletData->pEntity->mat;
							if(pMatrix)
							{
								if(g_iLagCompensation)
								{
									vecPosPlusOffset.X = pMatrix->pos.X + g_pCurrentBulletData->vecOffset.X;
									vecPosPlusOffset.Y = pMatrix->pos.Y + g_pCurrentBulletData->vecOffset.Y;
									vecPosPlusOffset.Z = pMatrix->pos.Z + g_pCurrentBulletData->vecOffset.Z;
								}
								else
								{
									ProjectMatrix(&vecPosPlusOffset, pMatrix, &g_pCurrentBulletData->vecOffset);
								}

								vecEnd->X = vecPosPlusOffset.X - vecOrigin->X + vecPosPlusOffset.X;
								vecEnd->Y = vecPosPlusOffset.Y - vecOrigin->Y + vecPosPlusOffset.Y;
								vecEnd->Z = vecPosPlusOffset.Z - vecOrigin->Z + vecPosPlusOffset.Z;
							}
						}
					}
 				}
 			}
 		}

 		static uint32_t result = 0;
 		result = CWorld__ProcessLineOfSight(vecOrigin, vecEnd, vecPos, ppEntity,
 			b1, b2, b3, b4, b5, b6, b7, b8);

 		if(g_iLagCompensation == 2)
 		{
 			if(g_pCurrentFiredPed)
 			{
 				if(g_pCurrentFiredPed == pGame->FindPlayerPed())
				{		
					SendBulletSync(vecOrigin, vecEnd, vecPos, (ENTITY_TYPE**)ppEntity);
				}
			}

 			return result;
 		}

 		if(g_pCurrentFiredPed)
 		{
 			if(g_pCurrentFiredPed != pGame->FindPlayerPed())
 			{
 				if(g_pCurrentBulletData)
 				{
 					if(!g_pCurrentBulletData->pEntity)
 					{
 						PED_TYPE *pLocalPed = pGame->FindPlayerPed()->GetGtaActor();
 						if(*ppEntity == pLocalPed || (IN_VEHICLE(pLocalPed) &&  *(uintptr_t*)ppEntity == pLocalPed->pVehicle))
						{
 							*ppEntity = nullptr;
 							vecPos->X = 0.0f;
 							vecPos->Y = 0.0f;
 							vecPos->Z = 0.0f;
 							return 0;
 						}
 					}
 				}
 			}
 		}

 		if(g_pCurrentFiredPed)
 		{
 			if(g_pCurrentFiredPed == pGame->FindPlayerPed())
 			{				
				SendBulletSync(vecOrigin, vecEnd, vecPos, (ENTITY_TYPE**)ppEntity);
			}
		}

 		return result;
 	}

	return CWorld__ProcessLineOfSight(vecOrigin, vecEnd, vecPos, ppEntity,
		b1, b2, b3, b4, b5, b6, b7, b8);
}

uint32_t (*CWeapon__FireInstantHit)(WEAPON_SLOT_TYPE* thiz, PED_TYPE* pFiringEntity, VECTOR* vecOrigin, VECTOR* muzzlePosn, ENTITY_TYPE* targetEntity, VECTOR *target, VECTOR* originForDriveBy, int arg6, int muzzle);
uint32_t CWeapon__FireInstantHit_hook(WEAPON_SLOT_TYPE* thiz, PED_TYPE* pFiringEntity, VECTOR* vecOrigin, VECTOR* muzzlePosn, ENTITY_TYPE* targetEntity, VECTOR *target, VECTOR* originForDriveBy, int arg6, int muzzle)
{
	uintptr_t dwRetAddr = 0;
 	__asm__ volatile ("mov %0, lr" : "=r" (dwRetAddr));

 	dwRetAddr -= g_libGTASA;
	
 	if(	dwRetAddr == 0x569A84 + 1 ||
 		dwRetAddr == 0x569616 + 1 ||
 		dwRetAddr == 0x56978A + 1 ||
 		dwRetAddr == 0x569C06 + 1)
 	{
		g_pCurrentFiredPed2 = pGame->FindPlayerPed();
		PED_TYPE *pLocalPed = pGame->FindPlayerPed()->GetGtaActor();
		if(pLocalPed)
		{
			if(pFiringEntity != pLocalPed)
				return muzzle;

			if(pNetGame)
			{
				CPlayerPool *pPlayerPool = pNetGame->GetPlayerPool();
				if(pPlayerPool)
				{
					pPlayerPool->ApplyCollisionChecking();
				}
			}

			if(pGame)
			{
				CPlayerPed* pPlayerPed = pGame->FindPlayerPed();
				if(pPlayerPed)
				{
					pPlayerPed->FireInstant();
				}
			}

			if(pNetGame)
			{
				CPlayerPool *pPlayerPool = pNetGame->GetPlayerPool();
				if(pPlayerPool)
				{
					pPlayerPool->ResetCollisionChecking();
				}
			}

			return muzzle;
		}
 	}

	return CWeapon__FireInstantHit(thiz, pFiringEntity, vecOrigin, muzzlePosn, targetEntity, target, originForDriveBy, arg6, muzzle);
}

// 3F0DD4 ; _DWORD __fastcall CFileMgr::OpenFile(CFileMgr *this, const char *, const char *)
uint32_t (*CFileMgr__OpenFile)(const char* a2, const char* a3);
uint32_t CFileMgr__OpenFile_hook(const char* a2, const char* a3)
{
	DebugHook("h29 start");
    std::string str1 = a2;
    int pos1 = str1.find(BOEV("water.dat"));
	if(pos1 != -1)
	{
		Log("Loading water.dat..");
		const char* test = BOEV("SAMP/water.dat");
		return CFileMgr__OpenFile(test,a3);		
	}
	
    std::string str2 = a2;
    int pos2 = str2.find(BOEV("water1.dat"));
	if(pos2 != -1)
	{
		Log("Loading water1.dat..");
		const char* test = BOEV("SAMP/water1.dat");
		return CFileMgr__OpenFile(test,a3);		
	}	
	DebugHook("h29 end");
	return CFileMgr__OpenFile(a2,a3);
}

int (*MainMenuScreen__Update) (uintptr_t thiz, float a2);
int MainMenuScreen__Update_hook(uintptr_t thiz, float a2)
{
	MainMenuScreen__Update(thiz,a2);
	
	static bool StartGame = false;
	
	if(!StartGame)
	{
		Log(">> Starting game!");
		
		InitInMenu();
		
		((void (*)(void))(pack("0x261C8C") + 1))(); //StartGameScreen::OnNewGameCheck
		
		StartGame = true;
		return 0;
	}
	
	return 1;
}

//useless shit
int (*CUpsideDownCarCheck__IsCarUpsideDown)(int thiz, uintptr_t a2); 
int CUpsideDownCarCheck__IsCarUpsideDown_hook(int thiz, uintptr_t a2) 
{ 
	DebugHook("h30 start");
	if(*(uintptr_t*)(a2 + 20)) 
	{ 
		DebugHook("h30 start(if)");
		return CUpsideDownCarCheck__IsCarUpsideDown(thiz, a2); 
	}
	DebugHook("h30 end");
	return 0; 
}

void (*CAutomobile__BreakTowLink)(uintptr_t* thiz); 
void CAutomobile__BreakTowLink_hook(uintptr_t* thiz) 
{ 
	DebugHook("h31 start");
	uintptr_t* v6 = (uintptr_t*)*((uint32_t*)thiz + 307);
	if(*(uintptr_t*)(v6 + 1232))
	{ 
		CAutomobile__BreakTowLink(thiz); 
	} 
	DebugHook("h31 end");
	return; 
}

//fix return null from eglGetProcAddress("glAlphaFuncQCOM")
#include <dlfcn.h>
uintptr_t eglGetProcAddress_hook(const char* proc)
{
	void *libgl;
	libgl = dlopen(BOEV("libGLESv2.so"), RTLD_LAZY | RTLD_GLOBAL); //load libGLESv2 traditional way
	
	//if not found (it's impossible)
	if(libgl == 0)
	{
		return 0;
	}
	
	void *res;
    res = dlsym((void*)libgl, proc); //find glAlphaFuncQCOM and other...
	return (uintptr_t)res;
}

void (*CStreaming_Init2)(); 
void CStreaming_Init2_hook() 
{ 
	CStreaming_Init2();
	*(uint32_t*)(g_libGTASA + 0x5DE734) = 0x10000000;
	return; 
}

uint32_t (*CPlayerInfo__FindObjectToSteal)(uintptr_t* thiz); 
uint32_t CPlayerInfo__FindObjectToSteal_hook(uintptr_t* thiz) 
{
	return 0;
}

uint32_t (*CWidgetRadar__IsHeldDown)(uintptr_t* thiz); 
uint32_t CWidgetRadar__IsHeldDown_hook(uintptr_t* thiz) 
{
	//int test = CWidgetRadar__IsHeldDown(thiz);
	//if(test > 0)
	//	if(pChatWindow) pChatWindow->AddDebugMessage("is held down epta");
	//return 0;
	
	static bool rectangle = false;
	bool pressed = false;
	uintptr_t* v5 = thiz;
	//v6 = CHID::Implements(*((_DWORD *)this + 1));
	//int v6 = (( int (*)(int))(g_libGTASA+0x24D014+1))(*((uint32_t *)thiz + 1));
	//float v7 = *((float *)v5 + 17);
	//float v8 = *((float *)v5 + 35);
	
	//if ( !v6 )
	//	return v7 >= v8;
	//if ( v7 < v8 )
	//	return 0;
	//return CHID::IsPressed(*((_DWORD *)v5 + 1), 0);
	float v7 = *((float *)v5 + 17);

	/*
	if (v7 > 1.20 && v7 < 1.40)
	{
		if(!rectangle)
		{
			//rectangle radar
			UnFuck("0x3DED84");
			*(float*)(g_libGTASA+0x3DED84) = 0;
			rectangle = true;
			return 0;
		}
	}
	else if(v7 > 1.41 && v7 < 1.60)
	{
		if(rectangle)
		{
			UnFuck("0x3DED84");
			*(float*)(g_libGTASA+0x3DED84) = 1.5708;	
			rectangle = false;
			return 0;
		}		
	}
	*/
	
	/*
	if(!rectangle)
	{
		if (v7 > 1.20 && v7 < 1.40)
		{
			//rectangle radar
			UnFuck("0x3DED84");
			*(float*)(g_libGTASA+0x3DED84) = 0;
			rectangle = true;
			return 0;
		}	
	}
	else
	{
		if (v7 > 1.20 && v7 < 1.40)
		{
			//rectangle radar
			UnFuck("0x3DED84");
			*(float*)(g_libGTASA+0x3DED84) = 1.5708;
			rectangle = false;
			return 0;
		}			
	}
	*/
	return 0;
}

int (*_rwFreeListFreeReal)(int a1, unsigned int a2);
int _rwFreeListFreeReal_hook(int a1, unsigned int a2)
{
	DebugHook("h32 start");
	if (a1)
	{
		DebugHook("h32 (if)");
		return _rwFreeListFreeReal(a1, a2);
	}
	else
	{
		DebugHook("h32 end");
		return 0;
	}
}

struct flags {
    unsigned int bHasBulletProofVest : 1;
    unsigned int bUsingMobilePhone : 1;
    unsigned int bUpperBodyDamageAnimsOnly : 1;
    unsigned int bStuckUnderCar : 1;
    unsigned int bKeepTasksAfterCleanUp : 1; // If true ped will carry on with task even after cleanup
    unsigned int bIsDyingStuck : 1;
    unsigned int bIgnoreHeightCheckOnGotoPointTask : 1; // set when walking round buildings, reset when task quits
    unsigned int bForceDieInCar : 1;
};

//327EE4 ; _DWORD __fastcall CEventDamage::ComputeDamageAnim(CEventDamage *__hidden this, CPed *, bool)
uintptr_t (*CEventDamage__ComputeDamageAnim)(uintptr_t* a1, uintptr_t* a2, int a3);
uintptr_t CEventDamage__ComputeDamageAnim_hook(uintptr_t* a1, uintptr_t* a2, int a3)
{
	DebugHook("h33 start");
	// enable anti stun
	reinterpret_cast<flags*>(*reinterpret_cast<int**>(g_libGTASA + 0x8B0808) + 0x48C)->bUpperBodyDamageAnimsOnly = 0;
	
	DebugHook("h33 end");
	return 0;
}

#include "..//nv_event.h"
int32_t(*NVEventGetNextEvent_hooked)(NVEvent* ev, int waitMSecs);
int32_t NVEventGetNextEvent_hook(NVEvent* ev, int waitMSecs)
{
	//DebugHook("h34 start");
	int32_t ret = NVEventGetNextEvent_hooked(ev, waitMSecs);

	if (ret)
	{
		if (ev->m_type == NV_EVENT_MULTITOUCH)
		{
			// process manually
			ev->m_type = (NVEventType)228;
		}

	}

	NVEvent event;
	NVEventGetNextEvent(&event);

	if (event.m_type == NV_EVENT_MULTITOUCH)
	{
		int type = event.m_data.m_multi.m_action & NV_MULTITOUCH_ACTION_MASK;
		int num = (event.m_data.m_multi.m_action & NV_MULTITOUCH_POINTER_MASK) >> NV_MULTITOUCH_POINTER_SHIFT;

		int x1 = event.m_data.m_multi.m_x1;
		int y1 = event.m_data.m_multi.m_y1;

		int x2 = event.m_data.m_multi.m_x2;
		int y2 = event.m_data.m_multi.m_y2;

		int x3 = event.m_data.m_multi.m_x3;
		int y3 = event.m_data.m_multi.m_y3;

		if (type == NV_MULTITOUCH_CANCEL)
		{
			type = NV_MULTITOUCH_UP;
		}

		if ((x1 || y1) || num == 0)
		{
			if (num == 0 && type != NV_MULTITOUCH_MOVE)
			{
				((void(*)(int, int, int posX, int posY))(g_libGTASA + 0x239D5C + 1))(type, 0, x1, y1); // AND_TouchEvent
			}
			else
			{
				((void(*)(int, int, int posX, int posY))(g_libGTASA + 0x239D5C + 1))(NV_MULTITOUCH_MOVE, 0, x1, y1); // AND_TouchEvent
			}
		}

		if ((x2 || y2) || num == 1)
		{
			if (num == 1 && type != NV_MULTITOUCH_MOVE)
			{
				((void(*)(int, int, int posX, int posY))(g_libGTASA + 0x239D5C + 1))(type, 1, x2, y2); // AND_TouchEvent
			}
			else
			{
				((void(*)(int, int, int posX, int posY))(g_libGTASA + 0x239D5C + 1))(NV_MULTITOUCH_MOVE, 1, x2, y2); // AND_TouchEvent
			}
		}
		if ((x3 || y3) || num == 2)
		{
			if (num == 2 && type != NV_MULTITOUCH_MOVE)
			{
				((void(*)(int, int, int posX, int posY))(g_libGTASA + 0x239D5C + 1))(type, 2, x3, y3); // AND_TouchEvent
			}
			else
			{
				((void(*)(int, int, int posX, int posY))(g_libGTASA + 0x239D5C + 1))(NV_MULTITOUCH_MOVE, 2, x3, y3); // AND_TouchEvent
			}
		}
	}
	
	//DebugHook("h34 end");

	return ret;
}

int RemoveModelIDs[MAX_REMOVE_MODELS];
VECTOR RemovePos[MAX_REMOVE_MODELS];
float RemoveRad[MAX_REMOVE_MODELS];
int iTotalRemovedObjects = 0;


#include "util.h"

int(*CFileLoader__LoadObjectInstance)(uintptr_t, uintptr_t);
int CFileLoader__LoadObjectInstance_hook(uintptr_t thiz, uintptr_t name)
{
	DebugHook("h35 start");
	for (int i = 0; i < iTotalRemovedObjects; i++)
	{
		if (RemoveModelIDs[i] == *(uint32_t*)(thiz + 28))
		{
			VECTOR pos;
			pos.X = *(float*)(thiz);
			pos.Y = *(float*)(thiz + 4);
			pos.Z = *(float*)(thiz + 8);
			if (GetDistanceBetween3DPoints(&pos, &RemovePos[i]) <= RemoveRad[i])
			{
				*(int*)(thiz + 28) = 19300;
			}
		}
	}
	DebugHook("h35 end");
	return CFileLoader__LoadObjectInstance(thiz, name);
}

//194B20 ; _DWORD __fastcall emu_ArraysGetID(unsigned int)
int (*emu_ArraysGetID)(unsigned int a1);
int emu_ArraysGetID_hook(unsigned int a1)
{
	bool v1; // zf
	int result; // r0

	v1 = a1 == 0;
	if ( a1 )
	v1 = *(uint32_t *)(a1 + 36) == 0;
	if ( v1 )
	result = 0;
	else
	result = emu_ArraysGetID(a1);
	return result;
}

int (*SetCompAlphaCB)(int, int);
int SetCompAlphaCB_hook(int a1, char a2)
{
	int result; // r0

	if ( a1 )
		result = SetCompAlphaCB(a1, a2);
	else
		result = 0;
	return result;
}

typedef struct _RWRECT
{
	float x1;
	float y1;
	float x2;
	float y2;
} RWRECT;

float dot_change = 0;

#include "../rgba.h"

float radar_x1 = 0.0f;
float radar_y1 = 0.0f;
float radar_sizeX = 0.0f;
float radar_sizeY = 0.0f;

extern "C"
{
	JNIEXPORT void JNICALL Java_com_nvidia_dev_1one_NvEventQueueActivity_RadarPos(JNIEnv* pEnv, jobject thiz, jint x1, jint y1, jint sizeX, jint sizeY)
	{
		radar_x1 = x1;
		radar_y1 = y1;
		radar_sizeX = sizeX;
		radar_sizeY = sizeY;
	}		
}

//fix crosshair
//bool msgcross = false;
int (*CSprite2d__Draw)(uintptr_t* a0, RWRECT* a1, CRGBA* a2);
int CSprite2d__Draw_hook(uintptr_t* a0, RWRECT* a1, CRGBA* a2)
{
	// RADAR POSITION + SCALE
	float* thiz = (float*) * (uintptr_t*)(g_libGTASA + 0x6580C8);
	if (thiz)
	{
		ImGuiIO& io = ImGui::GetIO();
		
		float wX = (radar_sizeX / (io.DisplaySize.x / 640))/2;
		float wY = (radar_sizeY / (io.DisplaySize.y / 448))/2;
		
		thiz[3] = ((radar_x1 / (io.DisplaySize.x / 640)) / 2) + (wX);
		thiz[4] = ((radar_y1 / (io.DisplaySize.y / 448)) / 2) + (wY);

		thiz[5] = wX;
		thiz[6] = wX;
		
		//thiz[5] = 45.0f * (radar_sizeX / 100.0f);
		//thiz[6] = 45.0f * (radar_sizeX / 100.0f);
		
		//if(pChatWindow) pChatWindow->AddDebugMessage("x %0.2f | y %0.2f | w %0.2f | h %0.2f", radar_x1, radar_y1, radar_sizeX, radar_sizeY);
		
		//if(pChatWindow) pChatWindow->AddDebugMessage("x %0.2f | y %0.2f | w %0.2f | h %0.2f", thiz[3], thiz[4], thiz[5], thiz[6]);
	}	
		
	
	if(pSettings)
	{
		if(pSettings->Get().ch == false)
		{
			//if(!msgcross)
			//{
			//	if(pChatWindow) pChatWindow->AddDebugMessage(">> default crosshair");
			//	msgcross = true;
			//}
			return CSprite2d__Draw(a0,a1,a2);
		}
	}
	
	//if(!msgcross)
	//{
	//	if(pChatWindow) pChatWindow->AddDebugMessage(">> fix crosshair");
	//	msgcross = true;
	//}	
	
	uintptr_t dwRetAddr = 0;
 	__asm__ volatile ("mov %0, lr" : "=r" (dwRetAddr));
 	dwRetAddr -= g_libGTASA;
	
	CPlayerPed* mPed = pGame->FindPlayerPed();

	// ***** IF AIM / SIMPLE AIM ****
	if(dwRetAddr == 0x3D4B67)
	{
		float GetCalcCrosshair = a1->x2 - a1->x1;
		
		dot_change = GetCalcCrosshair;
		
		if(mPed->GetWeaponRadiusOnScreen() >= 0.200001f)
		{
			a1->x1 -= GetCalcCrosshair + (mPed->GetWeaponRadiusOnScreen() * 5.0f);
			a1->y1 += GetCalcCrosshair;
			a1->x2 -= GetCalcCrosshair;
			a1->y2 += GetCalcCrosshair - (mPed->GetWeaponRadiusOnScreen() * 5.0f);		
		}
		else
		{
			a1->x1 -= GetCalcCrosshair;
			a1->y1 += GetCalcCrosshair;
			a1->x2 -= GetCalcCrosshair;
			a1->y2 += GetCalcCrosshair;	
		}
		
		//if(pChatWindow) pChatWindow->AddDebugMessage("-. %0.2f|%0.2f|%0.2f|%0.2f", a1->x1, a1->y1, a1->x2, a1->y2);
	}
	if(dwRetAddr == 0x3D4B93)
	{
		//if(pChatWindow) pChatWindow->AddDebugMessage("2. %0.2f|%0.2f|%0.2f|%0.2f", a1->x1, a1->y1, a1->x2, a1->y2);
		float GetCalcCrosshair = a1->y1 - a1->y2;
		if(mPed->GetWeaponRadiusOnScreen() >= 0.200001f)
		{
			a1->x1 -= GetCalcCrosshair - (mPed->GetWeaponRadiusOnScreen() * 5.0f);
			a1->y1 += GetCalcCrosshair;
			a1->x2 -= GetCalcCrosshair;
			a1->y2 += GetCalcCrosshair - (mPed->GetWeaponRadiusOnScreen() * 5.0f);			
		}
		else
		{
			a1->x1 -= GetCalcCrosshair;
			a1->y1 += GetCalcCrosshair;
			a1->x2 -= GetCalcCrosshair;
			a1->y2 += GetCalcCrosshair;	
		}
	}
	if(dwRetAddr == 0x3D4BBF)
	{
		//if(pChatWindow) pChatWindow->AddDebugMessage("3. %0.2f|%0.2f|%0.2f|%0.2f", a1->x1, a1->y1, a1->x2, a1->y2);
		float GetCalcCrosshair = a1->x2 - a1->x1;
		if(mPed->GetWeaponRadiusOnScreen() >= 0.200001f)
		{
			a1->x1 -= GetCalcCrosshair + (mPed->GetWeaponRadiusOnScreen() * 5.0f);
			a1->y1 += GetCalcCrosshair;
			a1->x2 -= GetCalcCrosshair;
			a1->y2 += GetCalcCrosshair + (mPed->GetWeaponRadiusOnScreen() * 5.0f);		
		}
		else
		{
			a1->x1 -= GetCalcCrosshair;
			a1->y1 += GetCalcCrosshair;
			a1->x2 -= GetCalcCrosshair;
			a1->y2 += GetCalcCrosshair;	
		}

	
	}
	if(dwRetAddr == 0x3D4BE7)
	{
		//if(pChatWindow) pChatWindow->AddDebugMessage("4. %0.2f|%0.2f|%0.2f|%0.2f", a1->x1, a1->y1, a1->x2, a1->y2);
		float GetCalcCrosshair = a1->y2 - a1->y1;
		if(mPed->GetWeaponRadiusOnScreen() >= 0.200001f)
		{
			a1->x1 -= GetCalcCrosshair - (mPed->GetWeaponRadiusOnScreen() * 5.0f);
			a1->y1 += GetCalcCrosshair;
			a1->x2 -= GetCalcCrosshair;
			a1->y2 += GetCalcCrosshair + (mPed->GetWeaponRadiusOnScreen() * 5.0f);		
		}
		else
		{
			a1->x1 -= GetCalcCrosshair;
			a1->y1 += GetCalcCrosshair;
			a1->x2 -= GetCalcCrosshair;
			a1->y2 += GetCalcCrosshair;	
		}	
	}	
	
	// FPS M16
	//...
	
	//if(pChatWindow) pChatWindow->AddDebugMessage("x %0.2f | y %0.2f | w %0.2f | h %0.2f", thiz[3], thiz[4], thiz[5], thiz[6]);
	
	return CSprite2d__Draw(a0,a1,a2);
}	

int (*CSprite2d__DrawRect)(RWRECT* a1, CRGBA* a2);
int CSprite2d__DrawRect_hook(RWRECT* a1, CRGBA* a2)
{
	if(pSettings)
	{
		if(pSettings->Get().ch == false) return CSprite2d__DrawRect(a1, a2);
	}	
	
	uintptr_t dwRetAddr = 0;
 	__asm__ volatile ("mov %0, lr" : "=r" (dwRetAddr));
 	dwRetAddr -= g_libGTASA;
	
	// dot in center
	if(dwRetAddr == 0x3D4CDD)
	{
		//if(pChatWindow) pChatWindow->AddDebugMessage("0. %0.2f|%0.2f|%0.2f|%0.2f", a1->x1, a1->y1, a1->x2, a1->y2);
		a1->x1 -= dot_change * 1.0f;
		a1->y1 += dot_change * 1.0f;
		a1->x2 -= dot_change * 1.0f;
		a1->y2 += dot_change * 1.0f;
	}
	
	return CSprite2d__DrawRect(a1, a2);
}

//454F60 ; _DWORD CPlayerPed::GetWeaponRadiusOnScreen(CPlayerPed *__hidden this)
float (*CPlayerPed__GetWeaponRadiusOnScreen)(uintptr_t* a1);
float CPlayerPed__GetWeaponRadiusOnScreen_hook(uintptr_t* a1)
{
	if(pSettings)
	{
		if(pSettings->Get().ch == false) return CPlayerPed__GetWeaponRadiusOnScreen(a1);
	}	
	
	uintptr_t dwRetAddr = 0;
 	__asm__ volatile ("mov %0, lr" : "=r" (dwRetAddr));
 	dwRetAddr -= g_libGTASA;

	if(dwRetAddr == 0x3D4ADE + 1)
	{
		return 0.2f;
	}

	return CPlayerPed__GetWeaponRadiusOnScreen(a1);
}

int (*CPopulation__AddPed)(int a1, unsigned int a2, int *a3, int a4);
int CPopulation__AddPed_hook(int a1, unsigned int a2, int *a3, int a4)
{
	DebugHook("h40 started");
	return 0;
}

static uint32_t dwRLEDecompressSourceSize = 0;

int(*OS_FileRead)(void* a1, void* a2, int a3);
int OS_FileRead_hook(void* a1, void* a2, int a3)
{
	uintptr_t calledFrom = 0;
	__asm__ volatile ("mov %0, lr" : "=r" (calledFrom));
	calledFrom -= g_libGTASA;
	
	// не уверен
	/*if(!a1)
	{
		Log("detect empty file");
		return 0;
	}*/

	if (!a3)
	{
		return 0;
	}
	
	//decrypt files
	/*if (calledFrom == 0x001BCEE0 + 1 && a1 == (void*)lastOpenedFile)
	{
		lastOpenedFile = 0;
		
		AES_ctx ctx;
		InitCTX(ctx, &g_iEncryptionKeyTXD[0]);

		int retv = OS_FileRead(a1, a2, a3);
		int fileSize = a3;
		int iters = fileSize / PART_SIZE_TXD;
		uintptr_t pointer = (uintptr_t)a2;
		for (int i = 0; i < iters; i++)
		{
			AES_CBC_decrypt_buffer(&ctx, (uint8_t*)pointer, PART_SIZE_TXD);
			pointer += PART_SIZE_TXD;
		}
		return retv;
	}*/

	if (calledFrom == 0x1BDD34 + 1)
	{
		int retn = OS_FileRead(a1, a2, a3);

		dwRLEDecompressSourceSize = *(uint32_t*)a2;

		return retn;
	}
	else
	{
		int retn = OS_FileRead(a1, a2, a3);

		return retn;
	}
}

uint8_t* (*RLEDecompress)(uint8_t* pDest, size_t uiDestSize, uint8_t const* pSrc, size_t uiSegSize, uint32_t uiEscape);
uint8_t* RLEDecompress_hook(uint8_t* pDest, size_t uiDestSize, uint8_t const* pSrc, size_t uiSegSize, uint32_t uiEscape) {
	if (!pDest) 
	{
		return pDest;
	}

	if (!pSrc) 
	{
		return pDest;
	}

	uint8_t* pTempDest = pDest;
	const uint8_t* pTempSrc = pSrc;
	uint8_t* pEndOfDest = &pDest[uiDestSize];

	uint8_t* pEndOfSrc = (uint8_t*)&pSrc[dwRLEDecompressSourceSize];

	if (pDest < pEndOfDest) 
	{
		do 
		{
			if (*pTempSrc == uiEscape) 
			{
				uint8_t ucCurSeg = pTempSrc[1];
				if (ucCurSeg) 
				{
					uint8_t* ucCurDest = pTempDest;
					uint8_t ucCount = 0;
					do 
					{
						++ucCount;
						//Log("WRITE111 TO 0x%x FROM 0x%x SIZE %d", ucCurDest, pTempSrc + 2, uiSegSize);
						pDest = (uint8_t*)memcpy(ucCurDest, pTempSrc + 2, uiSegSize);
						
						ucCurDest += uiSegSize;
					} while (ucCurSeg != ucCount);


					pTempDest += uiSegSize * ucCurSeg;
				}
				pTempSrc += 2 + uiSegSize;
			}

			else 
			{
				if (pTempSrc + uiSegSize >= pEndOfSrc)
				{
					//Log("AVOID CRASH TO 0x%x FROM 0x%x SIZE %d END OF SRC 0x%x", pTempDest, pTempSrc, pEndOfSrc - pTempSrc - 1, pEndOfSrc);
					return pDest;
				}
				else
				{
					//Log("WRITE222 TO 0x%x FROM 0x%x SIZE %d END OF SRC 0x%x", pTempDest, pTempSrc, uiSegSize, pEndOfSrc);
					pDest = (uint8_t*)memcpy(pTempDest, pTempSrc, uiSegSize);
					pTempDest += uiSegSize;
					pTempSrc += uiSegSize;
				}
			}
		} while (pEndOfDest > pTempDest);
	}

	dwRLEDecompressSourceSize = 0;

	return pDest;
}

char* (*RenderQueue__ProcessCommand)(uintptr_t thiz, char* a2);
char* RenderQueue__ProcessCommand_hook(uintptr_t thiz, char* a2)
{
	DebugHook("h42 start");
	if (!thiz || !a2) return nullptr;
	return RenderQueue__ProcessCommand(thiz, a2);
}

int (*RwFrameAddChild)(int a1, int a2);
int RwFrameAddChild_hook(int a1, int a2)
{
	DebugHook("h43 start");
	uintptr_t dwRetAddr = 0;
	__asm__ volatile ("mov %0, lr" : "=r" (dwRetAddr));
	dwRetAddr -= g_libGTASA;
	
	if (!a2 && !a1)
	{
		return 0;	
	}
	
	//its dont fix crash...
	//if(!*(uint32_t*)(a1 + 0x98))
	//	return 0;
	
	if(dwRetAddr == 0x338BD7)
	{
		if(a1 == 0)
		{
			DebugHook("h43 start (if)");
			return 0;
		}
	}
	DebugHook("h43 end");
	return RwFrameAddChild(a1, a2);
}

uintptr_t (*CWanted__Initialise)(uintptr_t* a1);
uintptr_t CWanted__Initialise_hook(uintptr_t* a1)
{
	//uintptr_t dwRetAddr = 0;
	//__asm__ volatile ("mov %0, lr" : "=r" (dwRetAddr));
	//dwRetAddr -= g_libGTASA;

	//if(dwRetAddr == 0x3AD859)
	//{
		if(a1 == 0)
		{
			if(pChatWindow) pChatWindow->AddDebugMessage("crash detect, moved!!!");
			return 0;
		}
	//}
	return CWanted__Initialise(a1);
}

//*** audio hook

void readVehiclesAudioSettings();
void (*CVehicleModelInfo__SetupCommonData)();
void CVehicleModelInfo__SetupCommonData_hook()
{
	CVehicleModelInfo__SetupCommonData();
	readVehiclesAudioSettings();
}

extern VehicleAudioPropertiesStruct VehicleAudioProperties[20000];
static uintptr_t addr_veh_audio = (uintptr_t)& VehicleAudioProperties[0];

void (*CAEVehicleAudioEntity__GetVehicleAudioSettings)(uintptr_t thiz, int16_t a2, int a3);
void CAEVehicleAudioEntity__GetVehicleAudioSettings_hook(uintptr_t dest, int16_t a2, int ID)
{
	memcpy((void*)dest, &VehicleAudioProperties[(ID - 400)], sizeof(VehicleAudioPropertiesStruct));
}
//***
/*
static char szLastBufferedName[40];
int (*cHandlingDataMgr__FindExactWord)(uintptr_t thiz, char* line, char* nameTable, int entrySize, int entryCount);
int cHandlingDataMgr__FindExactWord_hook(uintptr_t thiz, char* line, char* nameTable, int entrySize, int entryCount)
{
	strncpy(&szLastBufferedName[0], line, entrySize);
	return cHandlingDataMgr__FindExactWord(thiz, line, nameTable, entrySize, entryCount);
}

void (*cHandlingDataMgr__ConvertDataToGameUnits)(uintptr_t thiz, tHandlingData* handling);
void cHandlingDataMgr__ConvertDataToGameUnits_hook(uintptr_t thiz, tHandlingData* handling)
{
	int iHandling = ((int(*)(uintptr_t, char*))(g_libGTASA + 0x004FBC4C + 1))(thiz, &szLastBufferedName[0]);

	CHandlingDefault::FillDefaultHandling((uint16_t)iHandling, handling);

	return cHandlingDataMgr__ConvertDataToGameUnits(thiz, handling);
}
*/
void (*FxEmitterBP_c__Render)(uintptr_t* a1, int a2, int a3, float a4, char a5);
void FxEmitterBP_c__Render_hook(uintptr_t* a1, int a2, int a3, float a4, char a5)
{
	DebugHook("h44 start");
	uintptr_t* temp = *((uintptr_t**)a1 + 3);
	if (!temp)
	{
		DebugHook("h44 start (if)");
		return;
	}
	FxEmitterBP_c__Render(a1, a2, a3, a4, a5);
	DebugHook("h44 end");
}

/*void (*CWidgetButton__Update)(int result, int a2, int a3, int a4);
void CWidgetButton__Update_hook(int result, int a2, int a3, int a4)
{
	if (!result)
	{
		return;
	}
		
	uintptr_t* CTouchInterface__m_bWidgets = (uintptr_t*)(g_libGTASA + 0x00657E48);
	if(!CTouchInterface__m_bWidgets) return;

	// if now button Accelerate
	if (result == CTouchInterface__m_bWidgets[2] || result == CTouchInterface__m_bWidgets[158])
	{
		if(pNetGame)
		{
			CPlayerPool *pPlayerPool;
			CLocalPlayer *pLocalPlayer;		
			pPlayerPool = pNetGame->GetPlayerPool();
			if(pPlayerPool)
			{
				pLocalPlayer = pPlayerPool->GetLocalPlayer();
				if(pLocalPlayer)
				{
					if(!pLocalPlayer->GetPlayerPed()->IsInVehicle())
					{
						//if(pChatWindow) pChatWindow->AddDebugMessage("fix accelerate");
						//*(int8_t *)(result + 77) = 0;
						// 274178 ; _DWORD __fastcall CWidget::SetEnabled(CWidget *__hidden this, bool)
						(( void (*)(uintptr_t*, bool))(pack("0x274178")+1))((uintptr_t*)result, false);
						return;
					}
					//else CWidgetButton__Update(result, a2, a3, a4);
				}
			}
		}
	}
	CWidgetButton__Update(result, a2,a3,a4);
}*/

void (*CWidget__SetEnabled)(int result, bool a2);
void CWidget__SetEnabled_hook(int result, bool a2)
{
	if (!result)
	{
		return;
	}
		
	uintptr_t* CTouchInterface__m_bWidgets = (uintptr_t*)(g_libGTASA + 0x00657E48);
	if(!CTouchInterface__m_bWidgets) return;

	// if now button Accelerate
	if (result == CTouchInterface__m_bWidgets[2] || result == CTouchInterface__m_bWidgets[158])
	{
		if(pNetGame)
		{
			CPlayerPool *pPlayerPool;
			CLocalPlayer *pLocalPlayer;		
			pPlayerPool = pNetGame->GetPlayerPool();
			if(pPlayerPool)
			{
				pLocalPlayer = pPlayerPool->GetLocalPlayer();
				if(pLocalPlayer)
				{
					if(!pLocalPlayer->GetPlayerPed()->IsInVehicle())
					{
						a2 = false;
					}
				}
			}
		}
	}
	CWidget__SetEnabled(result, a2);
}

int (*FxSystem_c__AddParticle)(uintptr_t *particle, VECTOR *position, VECTOR *velocity, float unk, uintptr_t *particleData, float a6, float brightness, float a8, int a9);
int FxSystem_c__AddParticle_hook(uintptr_t *particle, VECTOR *position, VECTOR *velocity, float unk, uintptr_t *particleData, float a6, float brightness, float a8, int a9)
{
	//if(pChatWindow) pChatWindow->AddDebugMessage("fxsystem addparticle!!!");
	if(!particle) 
	{
		///if(pChatWindow) pChatWindow->AddDebugMessage("fxsystem a0 detected");
		return 0;
	}
	else
	{
		if(!*(uint32_t*)(particle + 8))
		{
			///if(pChatWindow) pChatWindow->AddDebugMessage("fxsystem a0 + 8 detected");
			return 0;
		}
		else
		{
			char z0 = *(uint32_t*)(particle + 8);
			if (!*(char *)(z0 + 27))
			{
				///if(pChatWindow) pChatWindow->AddDebugMessage("fxsystem z0 + 27 detected");
				return 0;
			}
			else
			{
				FxSystem_c__AddParticle(particle, position, velocity, unk, particleData, a6, brightness, a8, a9);
			}
		}
	}
	return FxSystem_c__AddParticle(particle, position, velocity, unk, particleData, a6, brightness, a8, a9);
}

uint16_t gxt_string[0x7F];
uint16_t* (*CText_Get)(uintptr_t thiz, const char* text);
uint16_t* CText_Get_hook(uintptr_t thiz, const char* text)
{
	if(text[0] == 'S' && text[1] == 'A' && text[2] == 'M' && text[3] == 'P')
	{
		const char* code = &text[5];
		if(!strcmp(code, "MP")) CFont::AsciiToGxtChar("Reconnect", gxt_string);

    	return gxt_string;
	}

	return CText_Get(thiz, text);
}

uint32_t reconnect = GetTickCount();

void gorecon()
{
	if(pChatWindow) pChatWindow->m_ChatWindowEntries.clear();
	
	if (pNetGame)
	{
		pNetGame->ShutDownForGameRestart();
		if (pNetGame->GetRakClient())
		{
			pNetGame->GetRakClient()->Disconnect(500, 1);
		}
	}	
	
	//remove players full
	if(pNetGame)
	{
		CPlayerPool* pPlayerPool = pNetGame->GetPlayerPool();
		if(pPlayerPool)
		{
			for(PLAYERID playerId = 0; playerId < MAX_PLAYERS; playerId++)
			{
				if(pPlayerPool->GetSlotState(playerId) == true)
				{
					CRemotePlayer* pPlayer = pPlayerPool->GetAt(playerId);
					pPlayer->Remove();
				}
			}
		}
	}	
	
	pNetGame = new CNetGame(pNetGame->m_szHostOrIp,
			pNetGame->m_iPort,
			pSettings->Get().szNickName,
			"");
			
	//remove bots nahui
	// its called crash in CPed::SetCharCreatedBy
	//CPopulation::AddPed
	///WriteMemory("0x45F1A4", (uintptr_t)"\xF7\x46", 2);
	NOP("0x4612A0", 9);  // CPedIntelligence::SetPedDecisionMakerType from CPopulation::AddPedAtAttractor
	WriteMemory("0x45FC20", (uintptr_t)"\x4F\xF0\x00\x00\xF7\x46", 6); // CPopulation::AddToPopulation	
	
	return;
}

//i fucked up with this shit(rabotaet kak obichno cherez zhopy)
void MenuItem_Reconnect()
{
	if(GetTickCount() - reconnect < 1000 * 10) //10 seconds
	{
		if(pChatWindow) pChatWindow->AddDebugMessage("**Реконнект крашнет игру через %d сек.",(int)(GetTickCount()-reconnect));
		//MobileMenu::Exit((MobileMenu *)gMobileMenu);
		uintptr_t gMobileMenu = (uintptr_t)(pack("0x63E048"));
		(( int (*)(uintptr_t))(pack("0x25A0CC")+1))(gMobileMenu);		
		return;
	}
	
	if(!pNetGame)
	{
		//if(pChatWindow) pChatWindow->AddDebugMessage("");
		return;
	}
	
	if(pNetGame->GetGameState() != GAMESTATE_CONNECTED)
	{
		return;
	}	
	
	reconnect = GetTickCount();
	allow_reconnect = true;	
	temprecon = GetTickCount();
	
	//send packet about reconnect 
	RakNet::BitStream bsSend;
	bsSend.Write((uint8_t)179);
	bsSend.Write((uint8_t)77);
	pNetGame->GetRakClient()->Send(&bsSend, HIGH_PRIORITY, UNRELIABLE_SEQUENCED, 0);

	if(pChatWindow) pChatWindow->AddDebugMessage("{ffffff}***Reconnect after 7 seconds..");

	//MobileMenu::Exit((MobileMenu *)gMobileMenu);
	uintptr_t gMobileMenu = (uintptr_t)(pack("0x63E048"));
	(( int (*)(uintptr_t))(pack("0x25A0CC")+1))(gMobileMenu);		

	return;
}

void (*OSArray_FlowScreen__MenuItem___Add)(int r0, uintptr_t r1);
void OSArray_FlowScreen__MenuItem___Add_hook(int r0, uintptr_t r1)
{
	uintptr_t dwRetAddr = 0;
	__asm__ volatile ("mov %0, lr" : "=r" (dwRetAddr));
	dwRetAddr -= g_libGTASA;
	
	char* name = *(char**)(r1+4);
	
	//IsGamePause
	//if(*(uint8_t*)(g_libGTASA + 0x8C9BA3))
	if(!strcmp(name, BOEV("FEP_STG")))
	{
		if(dwRetAddr == 0x269BEF)
		{
			*(char**)(r1+4) = "SAMP_MP";
			*(uintptr_t*)(r1+8) = (uintptr_t)MenuItem_Reconnect;
			return OSArray_FlowScreen__MenuItem___Add(r0,r1);
		}
	}
	
	return OSArray_FlowScreen__MenuItem___Add(r0,r1);
}

bool (*CAutomobile__BurstTyre)(uintptr_t thiz, int a2, int a3);
bool CAutomobile__BurstTyre_hook(uintptr_t thiz, int a2, int a3)
{
	if (pNetGame)
	{
		// Did we get ped who fired?
		if (g_pCurrentFiredPed2)
		{
			// Trying to get vehicle pointer
			CVehiclePool* pVehiclePool = pNetGame->GetVehiclePool();
			if (pVehiclePool)
			{
				VEHICLEID vehId = pVehiclePool->FindIDFromGtaPtr((VEHICLE_TYPE*)thiz);
				if (vehId != INVALID_VEHICLE_ID)
				{
					CVehicle* pVehicle = pVehiclePool->GetAt(vehId);
					if (pVehicle)
					{
						pVehicle->ProcessDamage();
					}
				}
			}
		}
	}
	return CAutomobile__BurstTyre(thiz, a2, a3);
}

//23B910 ; signed int __fastcall OS_FileSetPosition(void *, int, int, int)
int (*OS_FileSetPosition)(uintptr_t *a1, int a2, int a3, int a4);
int OS_FileSetPosition_hook(uintptr_t *a1, int a2, int a3, int a4)
{
	if(!a1)
	{
		Log("file pos not exist (1)");
		return 0;
	}
	if (!*((int32_t*)a1))
	{
		Log("file pos not exist (2)");
		return 0;
	}	
	return OS_FileSetPosition(a1,a2,a3,a4);
}

uintptr_t(*GetTexture_orig)(const char* a1);
uintptr_t GetTexture_hook(const char* a1)
{
	//001BE990
	uintptr_t tex = ((uintptr_t(*)(const char*))(pack("0x001BE990") + 1))(a1);
	if (!tex)
	{
		Log("Texture %s was not found", a1);
		return 0;
	}
	else
	{
		++* (uintptr_t*)(tex + 84);
		return tex;
	}
}

int (*CRadar__DrawRadarSprite)(unsigned int iconID, float x, float y, unsigned int alpha);
int CRadar__DrawRadarSprite_hook(unsigned int iconID, float x, float y, unsigned int alpha)
{
	// for hide Radar North
	if(iconID == 4)
	{
		return 0;
	}
	return CRadar__DrawRadarSprite(iconID, x, y, alpha);
}

// 1BDB80 ; int __fastcall TextureDatabaseEntry::LoadPNG(TextureDatabaseEntry *this, const char *)
int (*TextureDatabase__LoadEntry)(uintptr_t* thiz, char* a2);
int TextureDatabase__LoadEntry_hook(uintptr_t* thiz, char* a2)
{
	if(pChatWindow) pChatWindow->AddDebugMessage("tex %s", a2);
	return TextureDatabase__LoadEntry(thiz, a2);
}

//=========================== screenshot ===================================
#include "vendor/libpng/png.h"
void writePNG(RwImage *img, const char *filename)
{
	FILE *f;
	png_structp png;
	png_infop info;
	int x, y;
	png_byte **rows;
	uint8_t *line;

	if(img->depth != 32)
		return;
	if(f = fopen(filename, "wb"), f == nullptr)
		return;

	png = png_create_write_struct(PNG_LIBPNG_VER_STRING, nullptr, nullptr, nullptr);
	if(png == nullptr)
		goto fail1;

	info = png_create_info_struct(png);
	if(info == nullptr)
		goto fail2;

	if(setjmp(png_jmpbuf(png)))
		goto fail2;
	
	if(pChatWindow) pChatWindow->AddDebugMessage("png %d %d", img->width, img->height);

	png_set_IHDR(png,
		info,
		img->width,
		img->height,
		8,
		PNG_COLOR_TYPE_RGB,
		PNG_INTERLACE_NONE,
		PNG_COMPRESSION_TYPE_DEFAULT,
		PNG_FILTER_TYPE_DEFAULT);

	rows = (png_byte**)png_malloc(png, img->height * sizeof(png_byte*));
	line = img->cpPixels;
	for(y = 0; y < img->height; y++) {
		png_byte *row = (png_byte*)png_malloc(png, img->width * 3);
		rows[y] = row;
		for(x = 0; x < img->width; x++) {
			*row++ = line[x*4 + 0];
			*row++ = line[x*4 + 1];
			*row++ = line[x*4 + 2];
		}
		line += img->stride;
	}

	png_init_io(png, f);
	png_set_rows(png, info, rows);
	png_write_png(png, info, PNG_TRANSFORM_IDENTITY, nullptr);

	for(y = 0; y < img->height; y++)
		png_free(png, rows[y]);
	png_free(png, rows);

fail2:
	png_destroy_write_struct(&png, &info);
fail1:
	fclose(f);	
	
	
	if(pChatWindow) pChatWindow->AddDebugMessage("test!");
}

RwImage* psGrabScreen(RwCamera *cam)
{
	RwRaster *ras = cam->frameBuffer;
	
	if(pChatWindow) pChatWindow->AddDebugMessage("size %d %d", ras->width, ras->height);
	
	RwImage *img = RwImageCreate(ras->width, ras->height, 32);
	RwImageAllocatePixels(img);
	RwImageSetFromRaster(img, ras);
	return img;
}

RwRaster* memas = nullptr;
void RwGrabScreen(RwCamera *cam)
{
	char name[256];
	RwImage *img = psGrabScreen(cam);
	sprintf(name, BOEV("%sSAMP/test1.png"), g_pszStorage);
	writePNG(img, name);
	RwImageDestroy(img);
}

//463DE0; int __fastcall RsCameraShowRaster(int, int, int, int)
void (*RsCameraShowRaster)(RwCamera* cam);
void RsCameraShowRaster_hook(RwCamera* cam)
{
	if(screen)
	{
		RwCamera* camera = *(RwCamera**)(pack("0x95B064"));
		RwGrabScreen(camera);
		screen = false;
	}
	return RsCameraShowRaster(cam);
}

//1A8708; int __fastcall RenderQueue::Flush(RenderQueue *this)
void (*RenderQueue__Flush)(uintptr_t* a1);
void RenderQueue__Flush_hook(uintptr_t* a1)
{
	if(screen)
	{
		RwCamera* camera = *(RwCamera**)(pack("0x95B064"));
		RwGrabScreen(camera);
		screen = false;
	}
	return RenderQueue__Flush(a1);
}

//==========================================================================

void InstallSpecialHooks()
{
	InstallMethodHook("0x5CD9D4", (uintptr_t)eglGetProcAddress_hook);
	
	Hook("0x25E660", (uintptr_t)MainMenuScreen__Update_hook, (uintptr_t*)&MainMenuScreen__Update);
	Hook("0x269974", (uintptr_t)OSArray_FlowScreen__MenuItem___Add_hook, (uintptr_t*)&OSArray_FlowScreen__MenuItem___Add);
	
	Hook("0x23BB84", (uintptr_t)OS_FileOpen_hook, (uintptr_t*)&OS_FileOpen);
	Hook("0x23B3DC", (uintptr_t)NvFOpen_hook, (uintptr_t*)&NvFOpen);
	Hook("0x23BEDC", (uintptr_t)OS_FileRead_hook, (uintptr_t*)&OS_FileRead);
	Hook("0x40C530", (uintptr_t)InitialiseRenderWare_hook, (uintptr_t*)&InitialiseRenderWare);
	Hook("0x3AF1A0", (uintptr_t)CPools_Initialise_hook, (uintptr_t*)&CPools_Initialise);
	Hook("0x4D3864", (uintptr_t)CText_Get_hook, (uintptr_t*)&CText_Get);
	Hook("0x4042A8", (uintptr_t)CStreaming_Init2_hook, (uintptr_t*)&CStreaming_Init2);
	Hook("0x23ACC4", (uintptr_t)NVEventGetNextEvent_hook, (uintptr_t*)&NVEventGetNextEvent_hooked);
}

void InstallHooks() 
{
	///Hook("0x1BC818", (uintptr_t)TextureDatabase__LoadEntry_hook, (uintptr_t*)&TextureDatabase__LoadEntry);
	
	Hook("0x463DE0", (uintptr_t)RsCameraShowRaster_hook, (uintptr_t*)&RsCameraShowRaster);
	//Hook("0x1A8708", (uintptr_t)RenderQueue__Flush_hook, (uintptr_t*)&RenderQueue__Flush);

	//remove Radar North
	Hook("0x3DC6C8", (uintptr_t)CRadar__DrawRadarSprite_hook, (uintptr_t*)&CRadar__DrawRadarSprite);
	
	//remove building
	Hook("0x395994", (uintptr_t)CFileLoader__LoadObjectInstance_hook, (uintptr_t*)&CFileLoader__LoadObjectInstance);

	Hook("0x327EE4", (uintptr_t)CEventDamage__ComputeDamageAnim_hook, (uintptr_t*)&CEventDamage__ComputeDamageAnim);
	
	//Hook("0x274AB4", (uintptr_t)CWidgetButton__Update_hook, (uintptr_t*)& CWidgetButton__Update);
	Hook("0x274178", (uintptr_t)CWidget__SetEnabled_hook, (uintptr_t*)&CWidget__SetEnabled);
	
	//sync burst wheels
	Hook("0x4D7190", (uintptr_t)CAutomobile__BurstTyre_hook, (uintptr_t*)&CAutomobile__BurstTyre);
	
	//============== fix crashes game ==========================
	///Hook("0x23B910", (uintptr_t)OS_FileSetPosition_hook, (uintptr_t*)&OS_FileSetPosition); (не уверен)
	
	// gettexture fix crash
	Hook("0x258910", (uintptr_t)GetTexture_hook, (uintptr_t*)&GetTexture_orig);
	Hook("0x194B20", (uintptr_t)emu_ArraysGetID_hook, (uintptr_t*)&emu_ArraysGetID);
	Hook("0x50C5F8", (uintptr_t)SetCompAlphaCB_hook, (uintptr_t*)&SetCompAlphaCB);
	Hook("0x1B9D74", (uintptr_t)_rwFreeListFreeReal_hook, (uintptr_t*)& _rwFreeListFreeReal);
	//because we're patching it somewhere else
	Hook("0x4D6F84", (uintptr_t)CAutomobile__BreakTowLink_hook, (uintptr_t*)&CAutomobile__BreakTowLink);
	Hook("0x45F1A4", (uintptr_t)CPopulation__AddPed_hook, (uintptr_t*)&CPopulation__AddPed);
	Hook("0x1BC314", (uintptr_t)RLEDecompress_hook, (uintptr_t*)&RLEDecompress);
	Hook("0x1A8530", (uintptr_t)RenderQueue__ProcessCommand_hook, (uintptr_t*)&RenderQueue__ProcessCommand);
	Hook("0x1AECC0", (uintptr_t)RwFrameAddChild_hook, (uintptr_t*)&RwFrameAddChild);
	Hook("0x31B164", (uintptr_t)FxEmitterBP_c__Render_hook, (uintptr_t*)& FxEmitterBP_c__Render); //its maybe remove effect checkpoints...
	//Hook("0x320F2C", (uintptr_t)FxSystem_c__AddParticle_hook, (uintptr_t*)& FxSystem_c__AddParticle); //its remove effects bullet, blood and other
	// ne ebu mne pohui
	//Hook("0x3BFFBC", (uintptr_t)CWanted__Initialise_hook, (uintptr_t*)&CWanted__Initialise);
	//Hook("0x3AD84C", (uintptr_t)CPlayerPedData__AllocateData_hook, (uintptr_t*)&CPlayerPedData__AllocateData);	

	//==========================================================
	
	Hook("0x3AC114", (uintptr_t)CPlayerInfo__FindObjectToSteal_hook, (uintptr_t*)&CPlayerInfo__FindObjectToSteal);

	Hook("0x567964", (uintptr_t)CWeapon__FireInstantHit_hook, (uintptr_t*)&CWeapon__FireInstantHit);
	Hook("0x3C70C0", (uintptr_t)CWorld__ProcessLineOfSight_hook, (uintptr_t*)&CWorld__ProcessLineOfSight);	
	Hook("0x55E090", (uintptr_t)CBulletInfo_AddBullet_hook, (uintptr_t*)&CBulletInfo_AddBullet); 
	Hook("0x56668C", (uintptr_t)CWeapon_FireSniper_hook, (uintptr_t*)&CWeapon_FireSniper);

	//Hook("0x3F054C", (uintptr_t)CFileLoader__LoadObjectInstance_hook, (uintptr_t*)&CFileLoader__LoadObjectInstance);
	Hook("0x391E20", (uintptr_t)CEntity__Render_hook, (uintptr_t*)&CEntity__Render);
	Hook("0x3D5894", (uintptr_t)CHud__DrawScriptText_hook, (uintptr_t*)&CHud__DrawScriptText);
	Hook("0x3986CC", (uintptr_t)CGame__Process_hook, (uintptr_t*)&CGame__Process);
	Hook("0x3D7CA8", (uintptr_t)CLoadingScreen_DisplayPCScreen_hook, (uintptr_t*)&CLoadingScreen_DisplayPCScreen);
	Hook("0x39AEF4", (uintptr_t)Render2dStuff_hook, (uintptr_t*)&Render2dStuff);
	Hook("0x39B098", (uintptr_t)Render2dStuffAfterFade_hook, (uintptr_t*)&Render2dStuffAfterFade);
	Hook("0x239D5C", (uintptr_t)TouchEvent_hook, (uintptr_t*)&TouchEvent);
	Hook("0x28E83C", (uintptr_t)CStreaming_InitImageList_hook, (uintptr_t*)&CStreaming_InitImageList);
	Hook("0x336268", (uintptr_t)CModelInfo_AddAtomicModel_hook, (uintptr_t*)&CModelInfo_AddAtomicModel);
	Hook("0x336690", (uintptr_t)CModelInfo_AddPedModel_hook, (uintptr_t*)&CModelInfo_AddPedModel);
	Hook("0x3DBA88", (uintptr_t)CRadar__GetRadarTraceColor_hook, (uintptr_t*)&CRadar__GetRadarTraceColor);
	Hook("0x3DAF84", (uintptr_t)CRadar__SetCoordBlip_hook, (uintptr_t*)&CRadar__SetCoordBlip);
	Hook("0x3DE9A8", (uintptr_t)CRadar__DrawRadarGangOverlay_hook, (uintptr_t*)&CRadar__DrawRadarGangOverlay);
	Hook("0x482E60", (uintptr_t)CTaskComplexEnterCarAsDriver_hook, (uintptr_t*)&CTaskComplexEnterCarAsDriver);
	Hook("0x4833CC", (uintptr_t)CTaskComplexLeaveCar_hook, (uintptr_t*)&CTaskComplexLeaveCar); 
	
	Hook("0x3C1BF8", (uintptr_t)CWorld__ProcessPedsAfterPreRender_hook, (uintptr_t*)&CWorld__ProcessPedsAfterPreRender);
	Hook("0x3AA3C0", (uintptr_t)CPhysical__Add_hook, (uintptr_t*)&CPhysical__Add);
	Hook("0x3AA5C8", (uintptr_t)CPhysical__RemoveAndAdd_hook, (uintptr_t*)&CPhysical__RemoveAndAdd);
	
	Hook("0x39EBCC", (uintptr_t)CPad__GetDisplayVitalStats_hook, (uintptr_t*)&CPad__GetDisplayVitalStats);
	//Hook("0x327528", (uintptr_t)CPedDamageResponseCalculator__ComputeDamageResponse_hook, (uintptr_t*)&CPedDamageResponseCalculator__ComputeDamageResponse);
	Hook("0x327528", (uintptr_t)ComputeDamageResponse_hooked, (uintptr_t*)(&ComputeDamageResponse));
	Hook("0x3960DC", (uintptr_t)CFileMgr__OpenFile_hook, (uintptr_t*)&CFileMgr__OpenFile);	
	
	CodeInject("0x2D99F4", (uintptr_t)PickupPickUp_hook, 1);
	
	//fix crosshair
	Hook("0x55265C", (uintptr_t)CSprite2d__Draw_hook, (uintptr_t*)&CSprite2d__Draw);
	Hook("0x5529AC", (uintptr_t)CSprite2d__DrawRect_hook, (uintptr_t*)&CSprite2d__DrawRect);
	Hook("0x454F60", (uintptr_t)CPlayerPed__GetWeaponRadiusOnScreen_hook, (uintptr_t*)&CPlayerPed__GetWeaponRadiusOnScreen);
	
	//** handling
	//Hook("0x4FBBB0", (uintptr_t)cHandlingDataMgr__FindExactWord_hook, (uintptr_t*)& cHandlingDataMgr__FindExactWord);
	//Hook("0x4FBCF4", (uintptr_t)cHandlingDataMgr__ConvertDataToGameUnits_hook, (uintptr_t*)& cHandlingDataMgr__ConvertDataToGameUnits);
	
	//new cars
	Hook("0x336618", (uintptr_t)CModelInfo_AddVehicleModel_hook, (uintptr_t*)& CModelInfo_AddVehicleModel); // dangerous
	//**
	
	//** audio hooks
	Hook("0x4052B8", (uintptr_t)CVehicleModelInfo__SetupCommonData_hook, (uintptr_t*)& CVehicleModelInfo__SetupCommonData); 
	Hook("0x35BE30", (uintptr_t)CAEVehicleAudioEntity__GetVehicleAudioSettings_hook, (uintptr_t*)& CAEVehicleAudioEntity__GetVehicleAudioSettings);	
	
	//Hook("0x2D644C", (uintptr_t)CStreaming__AddEntity_hook, (uintptr_t*)&CStreaming__AddEntity);
	
	//Hook("0x5822C4", (uintptr_t)CVehicle__SetupRender_hook, (uintptr_t*)&CVehicle__SetupRender);
	
	//Hook("0x5A55F0", (uintptr_t)SetTextMaterialCB_hook, (uintptr_t*)&SetTextMaterialCB);
	
	//SetUpHook(g_libGTASA+0x1E9CE4, (uintptr_t)TextureDatabaseRuntime__GetTexture_hook, (uintptr_t*)&TextureDatabaseRuntime__GetTexture);
	
	Hook("0x3EF518", (uintptr_t)CObject__Render_hook, (uintptr_t*)&CObject__Render);
	Hook("0x51AAE4", (uintptr_t)CVehicle__Render_hook, (uintptr_t*)&CVehicle__Render);

	HookCPad();
}