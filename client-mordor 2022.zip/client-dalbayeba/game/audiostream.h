#pragma once

#include "bass.h"

class CAudioStream
{
public:
	CAudioStream();
	~CAudioStream();
	
	void ControlGameRadio();
	void DrawInfo();
	//void Play(char *a2, int a3, int a4, int a5, int a6, char a7);
	void Play(char *url,bool draw);
	void Process();
	void Reset();
	void Stop(bool a2);
	
	
public:
	uint8_t GetRadioVolume;
	//char szIcyName[264]; //_BYTE CAudioStream__szIcyName[264]
	//char szUrl[264]; //char CAudioStream__szUrl[264]
	//char szInfo[264]; //char CAudioStream__szInfo[264]
	//char szIcyUrl[260]; //_BYTE CAudioStream__szIcyUrl[260]
	//bool bIsPlaying; //bool CAudioStream__bIsPlaying
	//float position; //float CAudioStream__position (maybe Vector use?)
	//bool bIs3d; //bool CAudioStream__bIs3d
	//bool bNeedsToDestroy;
};