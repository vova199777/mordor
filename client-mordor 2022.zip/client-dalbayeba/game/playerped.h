#pragma once

#include "object.h"
#include "CRemoteData.h"

class CPlayerPed : public CEntity
{
public:
	CPlayerPed();	// local
	CPlayerPed(uint8_t bytePlayerNumber, int iSkin, float fX, float fY, float fZ, float fRotation); // remote
	~CPlayerPed();

	void Destroy();

	// 0.3.7
	bool IsInVehicle();
	// 0.3.7
	bool IsAPassenger();
	// 0.3.7
	VEHICLE_TYPE* GetGtaVehicle();
	VEHICLE_TYPE * GetGtaContactVehicle();
	// 0.3.7
	void RemoveFromVehicleAndPutAt(float fX, float fY, float fZ);
	// 0.3.7
	void SetInitialState();
	// 0.3.7
	void SetHealth(float fHealth);
	void SetArmour(float fArmour);
	// 0.3.7
	float GetHealth();
	float GetArmour();
	// 0.3.7
	void TogglePlayerControllable(bool bToggle);
	// 0.3.7
	void SetModelIndex(unsigned int uiModel);

	void SetInterior(uint8_t byteID);

	void PutDirectlyInVehicle(int iVehicleID, int iSeat);
	void EnterVehicle(int iVehicleID, bool bPassenger);
	// 0.3.7
	void ExitCurrentVehicle();
	// 0.3.7
	int GetCurrentVehicleID();
	int GetVehicleSeatID();

	ENTITY_TYPE* GetEntityUnderPlayer();

	// ��������
	void ClearAllWeapons();
	// ��������
	void DestroyFollowPedTask();
	// ��������
	void ResetDamageEntity();

	// 0.3.7
	void RestartIfWastedAt(VECTOR *vecRestart, float fRotation);
	// 0.3.7
	void ForceTargetRotation(float fRotation);
	// 0.3.7
	uint8_t GetActionTrigger();
	// 0.3.7
	bool IsDead();
	uint16_t GetKeys(uint16_t *lrAnalog, uint16_t *udAnalog);
	void SetKeys(uint16_t wKeys, uint16_t lrAnalog, uint16_t udAnalog);
	// 0.3.7
	void SetMoney(int iAmount);
	// 0.3.7
	void ShowMarker(uint32_t iMarkerColorID);
	// 0.3.7
	void HideMarker();
	// 0.3.7
	void SetFightingStyle(int iStyle);
	// 0.3.7
	void SetRotation(float fRotation);
	// 0.3.7
	void ApplyAnimation( char *szAnimName, char *szAnimFile, float fT, int opt1, int opt2, int opt3, int opt4, int iUnk );
	// 0.3.7
	void GetBonePosition(int iBoneID, VECTOR* vecOut);
	// roflan
	unsigned char FindDeathReasonAndResponsiblePlayer(PLAYERID *nPlayer);
	
	void ClumpUpdateAnimations(float step, int flag);

	PED_TYPE * GetGtaActor() { return m_pPed; };
	
	void SetAmmo(int iWeapon, int iAmmo);
	WEAPON_SLOT_TYPE* FindWeaponSlot(int iWeapon);
	void GiveWeapon(int iWeapon, int iAmmo);
	void SetArmedWeapon(int iWeapon);
	uint8_t GetCurrentWeapon();
	
	CAMERA_AIM* GetCurrentAim();
	CAMERA_AIM* GetCurrentAimFix();
	uint8_t GetCameraMode();
	WEAPON_SLOT_TYPE* GetCurrentWeaponSlot();
	float GetAimZ();
	float GetCameraExtendedZoom() { return GameGetLocalPlayerCameraExtZoom(); }
	void SetCameraMode(uint8_t byteCameraMode);
	void SetCurrentAim(CAMERA_AIM *pAim);
	void SetAimZ(float fAim);
	void SetCameraExtendedZoom(float fExtZoom, float fAspect);

	void FireInstant();
	void GetWeaponInfoForFire(int bLeft, VECTOR *vecBone, VECTOR *vecOut);
	VECTOR* GetCurrentWeaponFireOffset();
	void ProcessBulletData(BULLET_DATA *btData);	
	
	void SetDead();
	
	void ApplyCrouch();
	void ResetCrouch();
	bool IsCrouching();
	
	void ClearPlayerAimState();
	void SetPlayerAimState();
	
	bool IsHaveAttachedObject();
	
	void RemoveAllAttachedObjects();
	
	bool GetObjectSlotState(int iObjectIndex);
	
	void ProcessAttachedObjects();
	
	void GetBoneMatrix(MATRIX4X4 *matOut, int iBoneID);
	
	void UpdateAttachedObject(bool create, uint32_t index, uint32_t model, uint32_t bone, VECTOR vecOffset, VECTOR vecRotation, VECTOR vecScale, uint32_t materialcolor1, uint32_t materialcolor2);

	void ApplyCommandTask(char *szTaskName, int p1, int p2, int p3, VECTOR *p4, int p5, int p6, int p7, int p8, int p9);

	float GetWeaponRadiusOnScreen(); 
	
	void GetTransformedBonePosition(int iBoneID, VECTOR* vecOut);
	
	void ProcessParachuting();
	void ProcessParachuteSkydiving();
	void ProcessParachutes();
	void CheckVehicleParachute();
	
	void SetFloatStat(unsigned char ucStat, float fLevel);
	
	void SetWaitAnimationGunFlash(bool state);
	bool GetWaitAnimationGunFlash();
	
	bool IsInJetpackMode();
	void StartJetpack();
	void StopJetpack();
	
public:
	PED_TYPE*	m_pPed;
	uint8_t		m_bytePlayerNumber;
	uint32_t	m_dwArrow;
	
	bool			m_bHaveBulletData;
	BULLET_DATA 	m_bulletData;
	
	// Attached objects
	
	ATTACHED_OBJECT 	m_AttachedObjectInfo[10];
	bool 				m_bObjectSlotUsed[10];
	CObject* 			m_pAttachedObjects[10];	
	
	int			m_iParachuteState;
	uint32_t	m_dwParachuteObject;
	int			m_iParachuteAnim;
	
	CRemoteDataStorage* m_pData;
	
	bool		FireState; //its for 'sound effect fire' and 'visual effect fire'
};