#include "main.h"
#include "game.h"
#include "..//net/netgame.h"
//#include "CHandlingDefault.h"

extern CGame *pGame;
extern CNetGame* pNetGame;

CVehicle::CVehicle(int iType, float fPosX, float fPosY, float fPosZ, float fRotation, bool bSiren)
{
	lastfunc("v1");
	DebugLog("v1 start");
	MATRIX4X4 mat;
	uint32_t dwRetID = 0;

	//m_pCustomHandling = nullptr;
	m_pVehicle = nullptr;
	m_dwGTAId = 0;
	m_pTrailer = nullptr;

	if( (iType != TRAIN_PASSENGER_LOCO) &&
		(iType != TRAIN_FREIGHT_LOCO) &&
		(iType != TRAIN_PASSENGER) &&
		(iType != TRAIN_FREIGHT) &&
		(iType != TRAIN_TRAM)) 
	{
		// normal vehicle
		if(!pGame->IsModelLoaded(iType))
		{
			pGame->RequestModel(iType);
			pGame->LoadRequestedModels();
			while(!pGame->IsModelLoaded(iType)) usleep(10);
		}

		ScriptCommand(&create_car, iType, fPosX, fPosY, fPosZ, &dwRetID);
		ScriptCommand(&set_car_z_angle, dwRetID, fRotation);
		ScriptCommand(&car_gas_tank_explosion,dwRetID, 0);
		ScriptCommand(&set_car_hydraulics, dwRetID, 0);
		ScriptCommand(&toggle_car_tires_vulnerable, dwRetID, 0);

		m_pVehicle = (VEHICLE_TYPE*)GamePool_Vehicle_GetAt(dwRetID);
		m_pEntity = (ENTITY_TYPE*)m_pVehicle;
		m_dwGTAId = dwRetID;

		if(m_pVehicle)
		{
			m_pVehicle->dwDoorsLocked = 0;
			m_bIsLocked = false;
			m_bIsEngineOn = false;
			
			m_pVehicle->nFlags.bSirenOrAlarm = 0;

			GetMatrix(&mat);
			mat.pos.X = fPosX;
			mat.pos.Y = fPosY;
			mat.pos.Z = fPosZ;

			if( GetVehicleSubtype() != VEHICLE_SUBTYPE_BIKE && 
				GetVehicleSubtype() != VEHICLE_SUBTYPE_PUSHBIKE)
				mat.pos.Z += 0.25f;

			SetMatrix(mat);
			
			if(bSiren) 
			{
				SetSirenOn(1);
			} 
			else 
			{
				SetSirenOn(0);
			}			
		}
	}
	else if((iType == TRAIN_PASSENGER_LOCO) ||
			(iType == TRAIN_FREIGHT_LOCO) ||
			(iType == TRAIN_TRAM))
	{
		// train locomotives
	}
	else if((iType == TRAIN_PASSENGER) ||
			iType == TRAIN_FREIGHT)
	{

	}

	m_byteObjectiveVehicle = 0;
	m_bSpecialMarkerEnabled = false;
	m_bDoorsLocked = false;
	m_dwMarkerID = 0;
	m_bIsInvulnerable = false;
	/*
	bHasSuspensionLines = false;
	m_pSuspensionLines = nullptr;
	if (GetVehicleSubtype() == VEHICLE_SUBTYPE_CAR)
	{
		//CopyGlobalSuspensionLinesToPrivate();
	}	
	
	m_bWheelSize = false;
	m_bWheelWidth = false;
	m_bWheelAlignmentX = false;
	m_bWheelAlignmentY = false;

	m_bWheelOffsetX = false;
	m_bWheelOffsetY = false;
	m_fWheelOffsetX = 0.0f;
	m_fWheelOffsetY = 0.0f;
	m_fNewOffsetX = 0.0f;
	m_fNewOffsetY = 0.0f;
	m_bWasWheelOffsetProcessedX = true;
	m_bWasWheelOffsetProcessedY = true;
	m_uiLastProcessedWheelOffset = 0;	
	*/
	DebugLog("v1 end");
}

CVehicle::~CVehicle()
{
	lastfunc("v2");
	DebugLog("v2 start");
	m_pVehicle = GamePool_Vehicle_GetAt(m_dwGTAId);
	
	/*if (bHasSuspensionLines && m_pSuspensionLines)
	{
		delete[] m_pSuspensionLines;
		m_pSuspensionLines = nullptr;
		bHasSuspensionLines = false;
	}*/	

	if(m_pVehicle)
	{
		//SetInvulnerable(false);
		
		if(m_dwMarkerID)
		{
			ScriptCommand(&disable_marker, m_dwMarkerID);
			m_dwMarkerID = 0;
		}

		RemoveEveryoneFromVehicle();

		if(m_pTrailer)
		{
			// detach trailer (��������)
		}

		// ��� ��� �����-�� ���������� �����
		
		/*if (m_pCustomHandling)
		{
			delete m_pCustomHandling;
			m_pCustomHandling = nullptr;
		}*/		

		if( m_pVehicle->entity.nModelIndex == TRAIN_PASSENGER_LOCO ||
			m_pVehicle->entity.nModelIndex == TRAIN_FREIGHT_LOCO )
		{
			ScriptCommand(&destroy_train, m_dwGTAId);
		}
		else
		{
			int nModelIndex = m_pVehicle->entity.nModelIndex;
			ScriptCommand(&destroy_car, m_dwGTAId);

			if( !GetModelReferenceCount(nModelIndex) &&
				//!m_bKeepModelLoaded &&
				//(pGame->GetVehicleModelsCount() > 80) &&
				pGame->IsModelLoaded(nModelIndex))
			{
				// CStreaming::RemoveModel
				(( void (*)(int))(g_libGTASA+0x290C4C+1))(nModelIndex);
			}
		}
	}
	DebugLog("v2 end");
}

void CVehicle::LinkToInterior(int iInterior)
{
	lastfunc("v3");
	DebugLog("v3 start");
	if(GamePool_Vehicle_GetAt(m_dwGTAId)) 
	{
		ScriptCommand(&link_vehicle_to_interior, m_dwGTAId, iInterior);
	}
	DebugLog("v3 end");
}

void CVehicle::SetColor(int iColor1, int iColor2)
{
	lastfunc("v4");
	DebugLog("v4 start");
	if(m_pVehicle)
	{
		if(GamePool_Vehicle_GetAt(m_dwGTAId))
		{
			m_pVehicle->byteColor1 = (uint8_t)iColor1;
			m_pVehicle->byteColor2 = (uint8_t)iColor2;
		}
	}

	m_byteColor1 = (uint8_t)iColor1;
	m_byteColor2 = (uint8_t)iColor2;
	m_bColorChanged = true;
	DebugLog("v4 end");
}

void CVehicle::SetHealth(float fHealth)
{
	lastfunc("v5");
	DebugLog("v5 start");
	if(m_pVehicle)
	{
		m_pVehicle->fHealth = fHealth;
		//if(fHealth == 1000)
		//{
		//	ScriptCommand(&repair_car,m_dwGTAId);	
		//}
	}
	DebugLog("v5 end");
}

float CVehicle::GetHealth()
{
	lastfunc("v6");
	if(m_pVehicle) return m_pVehicle->fHealth;
	else return 0.0f;
}

// 0.3.7
void CVehicle::SetInvulnerable(bool bInv)
{
	lastfunc("v7");
	if(!m_pVehicle) return;
	if(!GamePool_Vehicle_GetAt(m_dwGTAId)) return;
	if(m_pVehicle->entity.vtable == g_libGTASA+0x5C7358) return;

	if(bInv) 
	{
		ScriptCommand(&set_car_immunities, m_dwGTAId, 1,1,1,1,1);
		ScriptCommand(&toggle_car_tires_vulnerable, m_dwGTAId, 0);
		m_bIsInvulnerable = true;
	} 
	else 
	{ 
		ScriptCommand(&set_car_immunities, m_dwGTAId, 0,0,0,0,0);
		ScriptCommand(&toggle_car_tires_vulnerable, m_dwGTAId, 1);
		m_bIsInvulnerable = false;
	}
}

// 0.3.7
bool CVehicle::IsDriverLocalPlayer()
{
	lastfunc("v8");
	DebugLog("v8 started");
	if(m_pVehicle)
	{
		if((PED_TYPE*)m_pVehicle->pDriver == GamePool_FindPlayerPed())
			return true;
	}

	return false;
}

// 0.3.7
bool CVehicle::HasSunk()
{
	lastfunc("v9");
	if(!m_pVehicle) return false;
	return ScriptCommand(&has_car_sunk, m_dwGTAId);
}

void CVehicle::RemoveEveryoneFromVehicle()
{
	lastfunc("v10");
	if(!m_pVehicle) return;
	if(!GamePool_Vehicle_GetAt(m_dwGTAId)) return;

	float fPosX = m_pVehicle->entity.mat->pos.X;
	float fPosY = m_pVehicle->entity.mat->pos.Y;
	float fPosZ = m_pVehicle->entity.mat->pos.Z;

	int iPlayerID = 0;
	if(m_pVehicle->pDriver)
	{
		iPlayerID = GamePool_Ped_GetIndex( m_pVehicle->pDriver );
		ScriptCommand(&remove_actor_from_car_and_put_at, iPlayerID, fPosX, fPosY, fPosZ + 2.0f);
	}

	for(int i = 0; i<7; i++)
	{
		if(m_pVehicle->pPassengers[i] != nullptr)
		{
			iPlayerID = GamePool_Ped_GetIndex( m_pVehicle->pPassengers[i] );
			ScriptCommand(&remove_actor_from_car_and_put_at, iPlayerID, fPosX, fPosY, fPosZ + 2.0f);
		}
	}
}

// 0.3.7
bool CVehicle::IsOccupied()
{
	lastfunc("v11");
	if(m_pVehicle)
	{
		if(m_pVehicle->pDriver) return true;
		if(m_pVehicle->pPassengers[0]) return true;
		if(m_pVehicle->pPassengers[1]) return true;
		if(m_pVehicle->pPassengers[2]) return true;
		if(m_pVehicle->pPassengers[3]) return true;
		if(m_pVehicle->pPassengers[4]) return true;
		if(m_pVehicle->pPassengers[5]) return true;
		if(m_pVehicle->pPassengers[6]) return true;
	}

	return false;
}

void CVehicle::ProcessMarkers()
{
	lastfunc("v12");
	if(!m_pVehicle) return;

	if(m_byteObjectiveVehicle)
	{
		if(!m_bSpecialMarkerEnabled)
		{
			if(m_dwMarkerID)
			{
				ScriptCommand(&disable_marker, m_dwMarkerID);
				m_dwMarkerID = 0;
			}

			ScriptCommand(&tie_marker_to_car, m_dwGTAId, 1, 2, &m_dwMarkerID);
			ScriptCommand(&set_marker_color, m_dwMarkerID, 1004);
			ScriptCommand(&show_on_radar, m_dwMarkerID, 2);
			m_bSpecialMarkerEnabled = true;
		}

		return;
	}

	if(m_byteObjectiveVehicle && m_bSpecialMarkerEnabled)
	{
		if(m_dwMarkerID)
		{
			ScriptCommand(&disable_marker, m_dwMarkerID);
			m_bSpecialMarkerEnabled = false;
			m_dwMarkerID = 0;
		}
	}

	if(GetDistanceFromLocalPlayerPed() < 200.0f && !IsOccupied())
	{
		if(!m_dwMarkerID)
		{
			// show
			ScriptCommand(&tie_marker_to_car, m_dwGTAId, 1, 2, &m_dwMarkerID);
			ScriptCommand(&set_marker_color, m_dwMarkerID, 1004);
		}
	}

	else if(IsOccupied() || GetDistanceFromLocalPlayerPed() >= 200.0f)
	{
		// remove
		if(m_dwMarkerID)
		{
			ScriptCommand(&disable_marker, m_dwMarkerID);
			m_dwMarkerID = 0;
		}
	}
}

void CVehicle::SetWheelPopped(uint8_t bytePopped)
{
	if (!m_pVehicle || !m_dwGTAId)
	{
		return;
	}

	if (!GamePool_Vehicle_GetAt(m_dwGTAId))
	{
		return;
	}

	if (m_pVehicle)
	{
		if (!bytePopped)
		{
			if (GetVehicleSubtype() == VEHICLE_SUBTYPE_CAR)
			{
				((void(*)(VEHICLE_TYPE*))(pack("0x004D5CA4") + 1))(m_pVehicle); // CAutomobile::Fix
			}

			if (GetVehicleSubtype() == VEHICLE_SUBTYPE_BIKE)
			{
				((void(*)(VEHICLE_TYPE*))(pack("0x004E9234") + 1))(m_pVehicle); // CBike::Fix
			}

			return;
		}
	}
}

void CVehicle::SetDoorState(int iState)
{
	lastfunc("v13");
	if(!m_pVehicle) {
		return;
	}
	
	if(iState) 
	{
		m_pVehicle->dwDoorsLocked = 2;
		m_bDoorsLocked = true;
	} 
	else 
	{
		m_pVehicle->dwDoorsLocked = 0;
		m_bDoorsLocked = false;
	}
}

void CVehicle::SetEngineState(bool bState) 
{
	lastfunc("v14");
	if(!GamePool_Vehicle_GetAt(m_dwGTAId)) 
	{
		return;
	}
	
	//ScriptCommand(&turn_car_engine, m_dwGTAId, (int)((bState) ? 1 : 0));
	//m_bIsEngineOn = bState;
	
	if (bState)
	{
		m_pVehicle->nFlags.bEngineOn = 1;
		m_pVehicle->nFlags.bEngineBroken = 0;
		m_bIsEngineOn = true;
	}
	else
	{
		m_pVehicle->nFlags.bEngineOn = 0;
		m_pVehicle->nFlags.bEngineBroken = 1;
		m_bIsEngineOn = false;
	}	
}

void CVehicle::SetLightState(bool bState) 
{
	lastfunc("v15");
	if(!GamePool_Vehicle_GetAt(m_dwGTAId)) 
	{
		return;
	}
	
	ScriptCommand(&force_car_lights, m_dwGTAId, (int)((bState) ? 2 : 1));
	m_bIsLightsOn = bState;
}

void CVehicle::SetBonnetState(int iState)
{
	lastfunc("v16");
	if(!m_pVehicle) return;
	if(!GamePool_Vehicle_GetAt(m_dwGTAId)) return;
	
	if(iState == 1)
	{
		ScriptCommand(&open_car_door_a_bit, m_dwGTAId, 0, 1.0);
	}
	else
	{
		ScriptCommand(&open_car_door_a_bit, m_dwGTAId, 0, 0.0);
	}
}

void CVehicle::SetBootState(int iState)
{
	lastfunc("v17");
	if(!m_pVehicle) return;
	if(!GamePool_Vehicle_GetAt(m_dwGTAId)) return;
	
	if(iState == 1)
	{
		ScriptCommand(&open_car_door_a_bit, m_dwGTAId, 1, 1.0);
	}
	else
	{
		ScriptCommand(&open_car_door_a_bit, m_dwGTAId, 1, 0.0);
	}
}

void CVehicle::UpdateDamageStatus(uint32_t dwPanelDamage, uint32_t dwDoorDamage, uint8_t byteLightDamage, uint8_t byteTireDamage)
{
	if (HasDamageModel())
	{
		SetPanelStatus(dwPanelDamage);
		SetDoorStatus(dwDoorDamage, false);

		SetLightStatus(eLights::LEFT_HEADLIGHT, byteLightDamage & 1);
		SetLightStatus(eLights::RIGHT_HEADLIGHT, (byteLightDamage >> 2) & 1);
		if ((byteLightDamage >> 6) & 1)
		{
			SetLightStatus(eLights::LEFT_TAIL_LIGHT, 1);
			SetLightStatus(eLights::RIGHT_TAIL_LIGHT, 1);
		}

		SetWheelStatus(eWheelPosition::REAR_RIGHT_WHEEL, byteTireDamage & 1);
		SetWheelStatus(eWheelPosition::FRONT_RIGHT_WHEEL, (byteTireDamage >> 1) & 1);
		SetWheelStatus(eWheelPosition::REAR_LEFT_WHEEL, (byteTireDamage >> 2) & 1);
		SetWheelStatus(eWheelPosition::FRONT_LEFT_WHEEL, (byteTireDamage >> 3) & 1);
	}
	else if (GetVehicleSubtype() == VEHICLE_SUBTYPE_BIKE)
	{
		SetBikeWheelStatus(1, byteTireDamage & 1);
		SetBikeWheelStatus(0, (byteTireDamage >> 1) & 1);
	}
}

void CVehicle::ProcessDamage()
{
	if (pNetGame)
	{
		VEHICLEID vehId = pNetGame->GetVehiclePool()->FindIDFromGtaPtr(m_pVehicle);
		if (vehId != INVALID_VEHICLE_ID)
		{
			if (HasDamageModel())
			{
				uint8_t byteTyreFlags, byteLightFlags;
				uint32_t dwDoorFlags, dwPanelFlags;

				GetDamageStatusEncoded(&byteTyreFlags, &byteLightFlags, &dwDoorFlags, &dwPanelFlags);
				if (byteTyreFlags != m_byteTyreStatus || byteLightFlags != m_byteLightStatus ||
					dwDoorFlags != m_dwDoorStatus || dwPanelFlags != m_dwPanelStatus)
				{
					m_byteLightStatus = byteLightFlags;
					m_byteTyreStatus = byteTyreFlags;
					m_dwDoorStatus = dwDoorFlags;
					m_dwPanelStatus = dwPanelFlags;

					RakNet::BitStream bsDamage;

					bsDamage.Write(vehId);
					bsDamage.Write(dwPanelFlags);
					bsDamage.Write(dwDoorFlags);
					bsDamage.Write(byteLightFlags);
					bsDamage.Write(byteTyreFlags);

					pNetGame->GetRakClient()->RPC(&RPC_DamageVehicle, &bsDamage, HIGH_PRIORITY, RELIABLE_SEQUENCED, 0, false, UNASSIGNED_NETWORK_ID, nullptr);
				}
			}
			else if (GetVehicleSubtype() == VEHICLE_SUBTYPE_BIKE)
			{
				uint8_t byteTyreFlags = GetBikeWheelStatus(1) | (GetBikeWheelStatus(0) << 1);
				if (m_byteTyreStatus != byteTyreFlags)
				{
					m_byteTyreStatus = byteTyreFlags;

					RakNet::BitStream bsDamage;
					bsDamage.Write(vehId);
					bsDamage.Write((uint32_t)0);
					bsDamage.Write((uint32_t)0);
					bsDamage.Write((uint8_t)0);
					bsDamage.Write(byteTyreFlags);

					pNetGame->GetRakClient()->RPC(&RPC_DamageVehicle, &bsDamage, HIGH_PRIORITY, RELIABLE_SEQUENCED, 0, false, UNASSIGNED_NETWORK_ID, nullptr);
				}
			}
		}
	}
}

uint8_t CVehicle::GetDoorStatus(eDoors bDoor)
{
	if (m_pVehicle && bDoor < MAX_DOORS)
	{
		DAMAGE_MANAGER_INTERFACE* pDamageManager = (DAMAGE_MANAGER_INTERFACE*)((uintptr_t)m_pVehicle + 1456);
		if (pDamageManager) return pDamageManager->Door[bDoor];
	}
	return 0;
}

uint8_t CVehicle::GetLightStatus(uint8_t bLight)
{
	if (m_pVehicle && bLight < MAX_LIGHTS)
	{
		uintptr_t* pDamageManager = (uintptr_t*)((uintptr_t)m_pVehicle + 1456);
		return ((uint8_t(*)(uintptr_t, uint8_t))(g_libGTASA + 0x4F93A0 + 1))(((uintptr_t)m_pVehicle + 1456), bLight);
	}
	return 0;
}

uint8_t CVehicle::GetPanelStatus(uint8_t bPanel)
{
	if (m_pVehicle && bPanel < MAX_PANELS)
	{
		uintptr_t* pDamageManager = (uintptr_t*)((uintptr_t)m_pVehicle + 1456);
		return ((uint8_t(*)(uintptr_t, uint8_t))(g_libGTASA + 0x4F93D8 + 1))(((uintptr_t)m_pVehicle + 1456), bPanel);
	}
	return 0;
}

void CVehicle::GetDamageStatusEncoded(uint8_t* byteTyreFlags, uint8_t* byteLightFlags, uint32_t* dwDoorFlags, uint32_t* dwPanelFlags)
{
	if (byteTyreFlags) *byteTyreFlags = GetWheelStatus(eWheelPosition::REAR_RIGHT_WHEEL) | (GetWheelStatus(eWheelPosition::FRONT_RIGHT_WHEEL) << 1)
		| (GetWheelStatus(eWheelPosition::REAR_LEFT_WHEEL) << 2) | (GetWheelStatus(eWheelPosition::FRONT_LEFT_WHEEL) << 3);

	if (byteLightFlags) *byteLightFlags = GetLightStatus(eLights::LEFT_HEADLIGHT) | (GetLightStatus(eLights::RIGHT_HEADLIGHT) << 2);
	if (GetLightStatus(eLights::LEFT_TAIL_LIGHT) && GetLightStatus(eLights::RIGHT_TAIL_LIGHT))
		*byteLightFlags |= (1 << 6);

	if (dwDoorFlags) *dwDoorFlags = GetDoorStatus(eDoors::BONNET) | (GetDoorStatus(eDoors::BOOT) << 8) |
		(GetDoorStatus(eDoors::FRONT_LEFT_DOOR) << 16) | (GetDoorStatus(eDoors::FRONT_RIGHT_DOOR) << 24);

	if (dwPanelFlags) *dwPanelFlags = GetPanelStatus(ePanels::FRONT_LEFT_PANEL) | (GetPanelStatus(ePanels::FRONT_RIGHT_PANEL) << 4)
		| (GetPanelStatus(ePanels::REAR_LEFT_PANEL) << 8) | (GetPanelStatus(ePanels::REAR_RIGHT_PANEL) << 12)
		| (GetPanelStatus(ePanels::WINDSCREEN_PANEL) << 16) | (GetPanelStatus(ePanels::FRONT_BUMPER) << 20)
		| (GetPanelStatus(ePanels::REAR_BUMPER) << 24);
}

bool CVehicle::HasDamageModel()
{
	if (GetVehicleSubtype() == VEHICLE_SUBTYPE_CAR)
		return true;
	return false;
}

uint8_t CVehicle::GetWheelStatus(eWheelPosition bWheel)
{
	if (m_pVehicle && bWheel < MAX_WHEELS)
	{
		return ((uint8_t(*)(uintptr_t, uint8_t))(g_libGTASA + 0x4F9400 + 1))(((uintptr_t)m_pVehicle + 1456), bWheel);
	}
	return 0;
}

void CVehicle::SetWheelStatus(eWheelPosition bWheel, uint8_t bTireStatus)
{
	if (m_pVehicle && bWheel < MAX_WHEELS)
	{
		uintptr_t* pDamageManager = (uintptr_t*)((uintptr_t)m_pVehicle + 1456);
		((uint8_t(*)(uintptr_t, uint8_t, uint8_t))(g_libGTASA + 0x4F93F0 + 1))(((uintptr_t)m_pVehicle + 1456), bWheel, bTireStatus);
	}
}

void CVehicle::SetPanelStatus(uint8_t bPanel, uint8_t bPanelStatus)
{
	if (m_pVehicle && bPanel < MAX_PANELS && bPanelStatus <= 3)
	{
		if (GetPanelStatus(bPanel) != bPanelStatus)
		{
			uintptr_t* pDamageManager = (uintptr_t*)((uintptr_t)m_pVehicle + 1456);
			((uint8_t(*)(uintptr_t, uint8_t, uint8_t))(g_libGTASA + 0x4F93B8 + 1))(((uintptr_t)m_pVehicle + 1456), bPanel, bPanelStatus);

			if (bPanelStatus == DT_PANEL_INTACT)
			{
				// Grab the car node index for the given panel
				static int s_iCarNodeIndexes[7] = { 0x0F, 0x0E, 0x00 /*?*/, 0x00 /*?*/, 0x12, 0x0C, 0x0D };
				int iCarNodeIndex = s_iCarNodeIndexes[bPanel];

				// CAutomobile::FixPanel
				((uint8_t(*)(uintptr_t, uint32_t, uint32_t))(g_libGTASA + 0x4DD238 + 1))((uintptr_t)m_pVehicle, iCarNodeIndex, static_cast<uint32_t>(bPanel));
			}
			else
			{
				((uint8_t(*)(uintptr_t, uint32_t, bool))(g_libGTASA + 0x4DB024 + 1))((uintptr_t)m_pVehicle, static_cast<uint32_t>(bPanel), false);
			}
		}
	}
}

void CVehicle::SetPanelStatus(uint32_t ulPanelStatus)
{
	if (m_pVehicle)
	{
		for (uint8_t uiIndex = 0; uiIndex < MAX_PANELS; uiIndex++)
		{
			SetPanelStatus(uiIndex, static_cast<uint8_t>(ulPanelStatus));
			ulPanelStatus >>= 4;
		}
	}
}

void CVehicle::SetDoorStatus(uint32_t dwDoorStatus, bool spawnFlyingComponen)
{
	if (m_pVehicle)
	{
		for (uint8_t uiIndex = 0; uiIndex < MAX_DOORS; uiIndex++)
		{
			SetDoorStatus(static_cast<eDoors>(uiIndex), static_cast<uint8_t>(dwDoorStatus), spawnFlyingComponen);
			dwDoorStatus >>= 8;
		}
	}
}

void CVehicle::SetDoorStatus(eDoors bDoor, uint8_t bDoorStatus, bool spawnFlyingComponen)
{
	if (m_pVehicle && bDoor < MAX_DOORS)
	{
		if (GetDoorStatus(bDoor) != bDoorStatus)
		{
			uintptr_t* pDamageManager = (uintptr_t*)((uintptr_t)m_pVehicle + 1456);
			((uint8_t(*)(uintptr_t, uint8_t, uint8_t, bool))(g_libGTASA + 0x4F9410 + 1))(((uintptr_t)m_pVehicle + 1456), bDoor, bDoorStatus, spawnFlyingComponen);

			if (bDoorStatus == DT_DOOR_INTACT || bDoorStatus == DT_DOOR_SWINGING_FREE)
			{
				// Grab the car node index for the given door id
				static int s_iCarNodeIndexes[6] = { 0x10, 0x11, 0x0A, 0x08, 0x0B, 0x09 };
				int iCarNodeIndex = s_iCarNodeIndexes[bDoor];

				// CAutomobile::FixDoor
				((uint8_t(*)(uintptr_t, uint32_t, uint32_t))(g_libGTASA + 0x4DD13C + 1))((uintptr_t)m_pVehicle, iCarNodeIndex, static_cast<uint32_t>(bDoor));
			}
			else
			{
				bool bQuiet = !spawnFlyingComponen;
				((uint8_t(*)(uintptr_t, uint32_t, bool))(g_libGTASA + 0x4DB174 + 1))((uintptr_t)m_pVehicle, static_cast<uint32_t>(bDoor), bQuiet);
			}
		}
	}
}

void CVehicle::SetLightStatus(uint8_t bLight, uint8_t bLightStatus)
{
	if (m_pVehicle && bLight < MAX_LIGHTS)
	{
		uintptr_t* pDamageManager = (uintptr_t*)((uintptr_t)m_pVehicle + 1456);
		((uint8_t(*)(uintptr_t, uint8_t, uint8_t))(g_libGTASA + 0x4F9380 + 1))(((uintptr_t)m_pVehicle + 1456), bLight, bLightStatus);
	}
}

void CVehicle::SetBikeWheelStatus(uint8_t bWheel, uint8_t bTireStatus)
{
	if (m_pVehicle && bWheel < 2)
	{
		if (bWheel == 0)
		{
			*(uint8_t*)((uintptr_t)m_pVehicle + 1644) = bTireStatus;
		}
		else
		{
			*(uint8_t*)((uintptr_t)m_pVehicle + 1645) = bTireStatus;
		}
	}
}

uint8_t CVehicle::GetBikeWheelStatus(uint8_t bWheel)
{
	if (m_pVehicle && bWheel < 2)
	{
		if (bWheel == 0)
		{
			return *(uint8_t*)((uintptr_t)m_pVehicle + 1644);
		}
		else
		{
			return *(uint8_t*)((uintptr_t)m_pVehicle + 1645);
		}
	}
	return 0;
}

unsigned int CVehicle::GetVehicleSubtype()
{
	lastfunc("v18");
	if(m_pVehicle)
	{
		if(m_pVehicle->entity.vtable == g_libGTASA+0x5CC9F0)
		{
			return VEHICLE_SUBTYPE_CAR;
		}
		else if(m_pVehicle->entity.vtable == g_libGTASA+0x5CCD48)
		{
			return VEHICLE_SUBTYPE_BOAT;
		}
		else if(m_pVehicle->entity.vtable == g_libGTASA+0x5CCB18)
		{
			return VEHICLE_SUBTYPE_BIKE;
		}
		else if(m_pVehicle->entity.vtable == g_libGTASA+0x5CD0B0)
		{
			return VEHICLE_SUBTYPE_PLANE;
		}
		else if(m_pVehicle->entity.vtable == g_libGTASA+0x5CCE60)
		{
			return VEHICLE_SUBTYPE_HELI;
		}
		else if(m_pVehicle->entity.vtable == g_libGTASA+0x5CCC30)
		{
			return VEHICLE_SUBTYPE_PUSHBIKE;
		}
		else if(m_pVehicle->entity.vtable == g_libGTASA+0x5CD428)
		{
			return VEHICLE_SUBTYPE_TRAIN;
		}
	}

	return 0;
}

void CVehicle::SetSirenOn(uint8_t byteState)
{
	if(!m_pVehicle) return;
	
	if(byteState == 1)
	{
		m_pVehicle->nFlags.bSirenOrAlarm = 1;
	}
	else
	{
		m_pVehicle->nFlags.bSirenOrAlarm = 0;
	}
}

uint8_t CVehicle::IsSirenOn()
{
	return (m_pVehicle->nFlags.bSirenOrAlarm == 1);
	return 0;
}

void CVehicle::AttachTrailer()
{
	if (m_pTrailer)
	{
		ScriptCommand(&put_trailer_on_cab, m_pTrailer->m_dwGTAId, m_dwGTAId);
	}
}

//-----------------------------------------------------------

void CVehicle::DetachTrailer()
{
	if (m_pTrailer)
	{
		ScriptCommand(&detach_trailer_from_cab, m_pTrailer->m_dwGTAId, m_dwGTAId);
	}
}

//-----------------------------------------------------------

void CVehicle::SetTrailer(CVehicle* pTrailer)
{
	m_pTrailer = pTrailer;
}

//-----------------------------------------------------------

CVehicle* CVehicle::GetTrailer()
{
	if (!m_pVehicle) return NULL;

	// Try to find associated trailer
	uint32_t dwTrailerGTAPtr = m_pVehicle->dwTrailer;

	if (pNetGame && dwTrailerGTAPtr) 
	{
		CVehiclePool* pVehiclePool = pNetGame->GetVehiclePool();
		VEHICLEID TrailerID = (VEHICLEID)pVehiclePool->FindIDFromGtaPtr((VEHICLE_TYPE*)dwTrailerGTAPtr);
		if (TrailerID < MAX_VEHICLES && pVehiclePool->GetSlotState(TrailerID)) {
			return pVehiclePool->GetAt(TrailerID);
		}
	}

	return NULL;
}

uint8_t* GetCollisionDataFromModel(int nModelIndex)
{
	return 0;
}

void* GetSuspensionLinesFromModel(int nModelIndex, int& numWheels)
{
	return 0;
}

//void CVehicle::SetHandlingData(std::vector<SHandlingData>& vHandlingData)
//{

//}

void CVehicle::ResetVehicleHandling()
{
	
}

void CVehicle::CopyGlobalSuspensionLinesToPrivate()
{

}