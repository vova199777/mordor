#include "main.h"
#include "game.h"
#include "net/netgame.h"
#include "util/armhook.h"

#include "chatwindow.h"

#include <jni.h>

#include "seatcar.h"

#include "../util/CJavaWrapper.h"

extern CGame *pGame;
extern CNetGame *pNetGame;

extern CChatWindow *pChatWindow;

extern CSeatCar *pSeatCar;

PAD_KEYS LocalPlayerKeys;
PAD_KEYS RemotePlayerKeys[PLAYER_PED_SLOTS];

uint8_t byteInternalPlayer = 0;
uintptr_t dwCurPlayerActor = 0;
uintptr_t dwCurWeaponProcessingPlayer = 0;
uint8_t byteCurPlayer = 0;
uint8_t byteCurDriver = 0;
bool bLocalTargeting = false;
float localStatsTypesFloat[82];

uint16_t wSavedCameraMode2 = 0;

int *CTouchInterface_m_pWidgets = 0;

uint16_t (*CPad__GetPedWalkLeftRight)(uintptr_t thiz);
uint16_t CPad__GetPedWalkLeftRight_hook(uintptr_t thiz)
{	
	uintptr_t dwRetAddr = 0;
	__asm__ volatile ("mov %0, lr" : "=r" (dwRetAddr));
	dwRetAddr -= g_libGTASA;	
	
	///if(pChatWindow) pChatWindow->AddDebugMessage("dwret 0x%X", dwRetAddr);
	//return 250.0f;
	
	//if(pChatWindow) pChatWindow->AddDebugMessage("tim %d", *(int*)(g_libGTASA + 0x8C9BDC));

	if(dwCurPlayerActor && (byteCurPlayer != 0))
	{
		// Remote player
		uint16_t dwResult = RemotePlayerKeys[byteCurPlayer].wKeyLR;
		if((dwResult == 0xFF80 || dwResult == 0x80) &&  
			RemotePlayerKeys[byteCurPlayer].bKeys[ePadKeys::KEY_WALK])
		{
			dwResult = 0x40;
		}
		return dwResult;
	}
	else
	{
		// Local player
		LocalPlayerKeys.wKeyLR = CPad__GetPedWalkLeftRight(thiz);
		return LocalPlayerKeys.wKeyLR;
	}
	
	///0x457C72 + 1 //CPlayerPed::ControlButtonSprint ����� ������
	///0x4BED08 + 1 //CTaskSimplePlayerOnFoot::PlayerControlZelda ����� ������
	///0x4BE638 + 1 //CTaskSimplePlayerOnFoot::PlayerControlDucked ����� ��� (� ������� ��� ��� �� �����)
	///0x4BE394 + 1 //CTaskSimplePlayerOnFoot::PlayerControlZeldaWeapon ����� ������ � ������������	
	
	//LocalPlayerKeys.bKeys[ePadKeys::KEY_HANDBRAKE]
}

uint16_t (*CPad__GetPedWalkUpDown)(uintptr_t thiz);
uint16_t CPad__GetPedWalkUpDown_hook(uintptr_t thiz)
{
	if(dwCurPlayerActor && (byteCurPlayer != 0))
	{
		// Remote player
		uint16_t dwResult = RemotePlayerKeys[byteCurPlayer].wKeyUD;
		if((dwResult == 0xFF80 || dwResult == 0x80) &&  
			RemotePlayerKeys[byteCurPlayer].bKeys[ePadKeys::KEY_WALK])
		{
			dwResult = 0x40;
		}
		return dwResult;
	}
	else
	{
		// Local player
		LocalPlayerKeys.wKeyUD = CPad__GetPedWalkUpDown(thiz);
		return LocalPlayerKeys.wKeyUD;
	}
}

uint32_t (*CPad__JumpJustDown)(uintptr_t thiz);
uint32_t CPad__JumpJustDown_hook(uintptr_t thiz)
{
	if(dwCurPlayerActor && (byteCurPlayer != 0))
	{
		if(!RemotePlayerKeys[byteCurPlayer].bIgnoreJump &&
			RemotePlayerKeys[byteCurPlayer].bKeys[ePadKeys::KEY_JUMP] &&
			!RemotePlayerKeys[byteCurPlayer].bKeys[ePadKeys::KEY_HANDBRAKE])
		{
			RemotePlayerKeys[byteCurPlayer].bIgnoreJump = true;
			return RemotePlayerKeys[byteCurPlayer].bKeys[ePadKeys::KEY_JUMP];
		}

		return 0;
	}
	else
	{
		LocalPlayerKeys.bKeys[ePadKeys::KEY_JUMP] = CPad__JumpJustDown(thiz);
		return LocalPlayerKeys.bKeys[ePadKeys::KEY_JUMP];
	}
}

uint32_t (*CPad__GetJump)(uintptr_t thiz);
uint32_t CPad__GetJump_hook(uintptr_t thiz)
{
	if(dwCurPlayerActor && (byteCurPlayer != 0))
	{
		if(RemotePlayerKeys[byteCurPlayer].bIgnoreJump) return 0;
		return RemotePlayerKeys[byteCurPlayer].bKeys[ePadKeys::KEY_JUMP];
	}
	else
	{
		LocalPlayerKeys.bKeys[ePadKeys::KEY_JUMP] = CPad__JumpJustDown(thiz);
		return LocalPlayerKeys.bKeys[ePadKeys::KEY_JUMP];
	}
}

uint32_t (*CPad__GetAutoClimb)(uintptr_t thiz);
uint32_t CPad__GetAutoClimb_hook(uintptr_t thiz)
{
	if(dwCurPlayerActor && (byteCurPlayer != 0))
	{
		return RemotePlayerKeys[byteCurPlayer].bKeys[ePadKeys::KEY_JUMP];
	}
	else
	{
		LocalPlayerKeys.bKeys[ePadKeys::KEY_JUMP] = CPad__GetAutoClimb(thiz);
		return LocalPlayerKeys.bKeys[ePadKeys::KEY_JUMP];
	}
}

uint32_t (*CPad__GetAbortClimb)(uintptr_t thiz);
uint32_t CPad__GetAbortClimb_hook(uintptr_t thiz)
{
	if(dwCurPlayerActor && (byteCurPlayer != 0))
	{
		return RemotePlayerKeys[byteCurPlayer].bKeys[ePadKeys::KEY_SECONDARY_ATTACK];
	}
	else
	{
		LocalPlayerKeys.bKeys[ePadKeys::KEY_SECONDARY_ATTACK] = CPad__GetAutoClimb(thiz);
		return LocalPlayerKeys.bKeys[ePadKeys::KEY_SECONDARY_ATTACK];
	}
}

uint32_t (*CPad__DiveJustDown)();
uint32_t CPad__DiveJustDown_hook()
{
	if(dwCurPlayerActor && (byteCurPlayer != 0))
	{
		// remote player
		return RemotePlayerKeys[byteCurPlayer].bKeys[ePadKeys::KEY_FIRE];
	}
	else
	{
		LocalPlayerKeys.bKeys[ePadKeys::KEY_FIRE] = CPad__DiveJustDown();
		return LocalPlayerKeys.bKeys[ePadKeys::KEY_FIRE];
	}
}

uint32_t (*CPad__SwimJumpJustDown)(uintptr_t thiz);
uint32_t CPad__SwimJumpJustDown_hook(uintptr_t thiz)
{
	if(dwCurPlayerActor && (byteCurPlayer != 0))
	{
		return RemotePlayerKeys[byteCurPlayer].bKeys[ePadKeys::KEY_JUMP];
	}
	else
	{
		LocalPlayerKeys.bKeys[ePadKeys::KEY_JUMP] = CPad__SwimJumpJustDown(thiz);
		return LocalPlayerKeys.bKeys[ePadKeys::KEY_JUMP];
	}
}

uint32_t (*CPad__DuckJustDown)(uintptr_t thiz, int unk);
uint32_t CPad__DuckJustDown_hook(uintptr_t thiz, int unk)
{
	if(dwCurPlayerActor && (byteCurPlayer != 0))
	{
		return 0;
	}
	else
	{
		return CPad__DuckJustDown(thiz, unk);
	}
}

uint32_t (*CPad__MeleeAttackJustDown)(uintptr_t thiz);
uint32_t CPad__MeleeAttackJustDown_hook(uintptr_t thiz)
{
	/*
		0 - �� ����
		1 - ������� ���� (���)
		2 - ������� ���� (��� + F)
	*/

	//if(dwCurPlayerActor && (byteCurPlayer != 0))
	if(dwCurPlayerActor && (byteCurPlayer != 0))
	{
		if( RemotePlayerKeys[byteCurPlayer].bKeys[ePadKeys::KEY_HANDBRAKE] &&
			RemotePlayerKeys[byteCurPlayer].bKeys[ePadKeys::KEY_SECONDARY_ATTACK])
		{
			return 2;
		}

		return RemotePlayerKeys[byteCurPlayer].bKeys[ePadKeys::KEY_FIRE];
	}
	else
	{
		uint32_t dwResult = CPad__MeleeAttackJustDown(thiz);
		
		if((int)dwResult == 2)
		{
			LocalPlayerKeys.bKeys[ePadKeys::KEY_HANDBRAKE] = true;
			LocalPlayerKeys.bKeys[ePadKeys::KEY_SECONDARY_ATTACK] = true;
			return 2;
		}
		
		LocalPlayerKeys.bKeys[ePadKeys::KEY_FIRE] = dwResult;
		
		return dwResult;
	}
}

uint32_t (*CPad__GetBlock)(uintptr_t thiz);
uint32_t CPad__GetBlock_hook(uintptr_t thiz)
{
	if(dwCurPlayerActor && (byteCurPlayer != 0))
	{
		if( RemotePlayerKeys[byteCurPlayer].bKeys[ePadKeys::KEY_JUMP] &&
			RemotePlayerKeys[byteCurPlayer].bKeys[ePadKeys::KEY_HANDBRAKE])
			return 1;

		return 0;
	}
	else
	{
		return CPad__GetBlock(thiz);
	}
}

int16_t (*CPad__GetSteeringLeftRight)(uintptr_t thiz);
int16_t CPad__GetSteeringLeftRight_hook(uintptr_t thiz)
{
	if(byteCurDriver != 0)
	{
		// remote player
		return (int16_t)RemotePlayerKeys[byteCurDriver].wKeyLR;
	}
	else
	{
		// local player
		LocalPlayerKeys.wKeyLR = CPad__GetSteeringLeftRight(thiz);
		return LocalPlayerKeys.wKeyLR;
	}
}

uint16_t (*CPad__GetSteeringUpDown)(uintptr_t thiz);
uint16_t CPad__GetSteeringUpDown_hook(uintptr_t thiz)
{
	if(byteCurDriver != 0)
	{
		// remote player
		return RemotePlayerKeys[byteCurDriver].wKeyUD;
	}
	else
	{
		// local player
		LocalPlayerKeys.wKeyUD = CPad__GetSteeringUpDown(thiz);
		return LocalPlayerKeys.wKeyUD;
	}
}

uint32_t (*CPad__GetSprint)(uintptr_t thiz, uint32_t unk);
uint32_t CPad__GetSprint_hook(uintptr_t thiz, uint32_t unk)
{	
	if(dwCurPlayerActor && (byteCurPlayer != 0))
	{
		return RemotePlayerKeys[byteCurPlayer].bKeys[ePadKeys::KEY_SPRINT];
	}
	else
	{
		LocalPlayerKeys.bKeys[ePadKeys::KEY_SPRINT] = CPad__GetSprint(thiz, unk);
		return LocalPlayerKeys.bKeys[ePadKeys::KEY_SPRINT];
	}
}

uint16_t (*CPad__GetAccelerate)(uintptr_t thiz);
uint16_t CPad__GetAccelerate_hook(uintptr_t thiz)
{	
	if(byteCurDriver != 0)
	{
		// remote player
		return RemotePlayerKeys[byteCurDriver].bKeys[ePadKeys::KEY_SPRINT] ? 0xFF : 0x00;
	}
	else
	{		
		// local player
		uint16_t wAccelerate = CPad__GetAccelerate(thiz);
		LocalPlayerKeys.bKeys[ePadKeys::KEY_SPRINT] = wAccelerate;
		
		if(wAccelerate == 0xFF)
		{
			CPlayerPed* pPlayerPed = pGame->FindPlayerPed();
			if(pPlayerPed)
			{
				VEHICLE_TYPE* pGtaVehicle = pPlayerPed->GetGtaVehicle();
				if(pGtaVehicle)
				{
					if(pGtaVehicle->nFlags.bEngineOn == 0)
					{
						return 0;
					}
				}
			}
		}
		
		return wAccelerate;
	}
}

uint16_t (*CPad__GetBrake)(uintptr_t thiz);
uint16_t CPad__GetBrake_hook(uintptr_t thiz)
{
	if(byteCurDriver != 0)
	{
		// remote player
		return RemotePlayerKeys[byteCurDriver].bKeys[ePadKeys::KEY_JUMP] ? 0xFF : 0x00;
	}
	else
	{
		// local player
		uint16_t wBrake = CPad__GetBrake(thiz);
		LocalPlayerKeys.bKeys[ePadKeys::KEY_JUMP] = wBrake;
		
		if(wBrake == 0xFF)
		{
			CPlayerPed* pPlayerPed = pGame->FindPlayerPed();
			if(pPlayerPed)
			{
				VEHICLE_TYPE* pGtaVehicle = pPlayerPed->GetGtaVehicle();
				if(pGtaVehicle)
				{
					if(pGtaVehicle->nFlags.bEngineOn == 0)
					{
						return 0;
					}
				}
			}
		}		
		return wBrake;
	}
}

uint32_t (*CPad__GetHandBrake)(uintptr_t thiz);
uint32_t CPad__GetHandBrake_hook(uintptr_t thiz)
{
	if(byteCurDriver != 0)
	{
		// remote player
		return RemotePlayerKeys[byteCurDriver].bKeys[ePadKeys::KEY_HANDBRAKE] ? 0xFF : 0x00;
	}
	else
	{
		// local player
		uint32_t handBrake = CPad__GetHandBrake(thiz);
		LocalPlayerKeys.bKeys[ePadKeys::KEY_HANDBRAKE] = handBrake;
		return handBrake;
	}
}

uint32_t (*CPad__GetHorn)(uintptr_t thiz);
uint32_t CPad__GetHorn_hook(uintptr_t thiz)
{
	if(byteCurDriver != 0)
	{
		// remote player
		return RemotePlayerKeys[byteCurDriver].bKeys[ePadKeys::KEY_CROUCH];
	}
	else
	{
		// local player
		uint32_t horn = CPad__GetHorn(thiz);
		//Log("horn: %d", horn);
		LocalPlayerKeys.bKeys[ePadKeys::KEY_CROUCH] = CPad__GetHorn(thiz);
		return LocalPlayerKeys.bKeys[ePadKeys::KEY_CROUCH];
	}
}

uint32_t (*CPad__ExitVehicleJustDown)(uintptr_t thiz, int a2, uintptr_t* vehicle, int a4, VECTOR* vec);
uint32_t CPad__ExitVehicleJustDown_hook(uintptr_t thiz, int a2, uintptr_t* vehicle, int a4, VECTOR* vec)
{
	if(vehicle == 0) return 0;
	
	/*
	uintptr_t dwRetAddr = 0;
 	__asm__ volatile ("mov %0, lr" : "=r" (dwRetAddr));
 	dwRetAddr -= g_libGTASA;

	if(dwRetAddr == 0x4BE702 + 1)
	{
		if(!pNetGame) return 0;
		
		CVehiclePool *pVehiclePool = pNetGame->GetVehiclePool();

		VEHICLEID ClosetVehicleID = pVehiclePool->FindNearestToLocalPlayerPed();
		if(ClosetVehicleID < MAX_VEHICLES && pVehiclePool->GetSlotState(ClosetVehicleID))
		{
			CVehicle* pVehicle = pVehiclePool->GetAt(ClosetVehicleID);
			if(pVehicle->GetDistanceFromLocalPlayerPed() < 8.0f)
			{				
				//uint32_t v198 = *(uint32_t*)pVehicle + 0x14;
				//VECTOR* v199 = (VECTOR*)(v198 ? *(uint32_t*)v198 + 0x30 : *(uint32_t*)pVehicle + 0x4);		
				//CPad__ExitVehicleJustDown(thiz, 1, (uintptr_t*)pVehicle, 1, v199);
				//vehicle = (uintptr_t*)pVehicle;
				MATRIX4X4 matVehicle;
				pVehicle->GetMatrix(&matVehicle);

				VECTOR* GetVehPos;

				GetVehPos->X = matVehicle.pos.X;
				GetVehPos->Y = matVehicle.pos.Y;
				GetVehPos->Z = matVehicle.pos.Z;			
				
				if(pChatWindow) pChatWindow->AddDebugMessage("nModelIndex %d, X %0.2f | Y %0.2f | Z %0.2f", pVehicle->m_pVehicle->entity.nModelIndex, GetVehPos->X, GetVehPos->Y, GetVehPos->Z);
			}
		}
	}
		
	return CPad__ExitVehicleJustDown(thiz, a2, vehicle, a4, vec);
	*/
	
	//check if car is closed!
    /*if(pNetGame)
	{
		CVehiclePool *pVehiclePool = pNetGame->GetVehiclePool();
		CVehicle *pVehicle;
		VEHICLEID VehicleID = pVehiclePool->FindIDFromGtaPtr((VEHICLE_TYPE *)vehicle);
	 
		if(VehicleID != INVALID_VEHICLE_ID)
		{
			if(pVehiclePool->GetSlotState(VehicleID))
			{
				pVehicle = pVehiclePool->GetAt(VehicleID);
				if(pVehicle->m_bDoorsLocked)
				{
					CPlayerPool *pPlayerPool;
					CLocalPlayer *pLocalPlayer;
				
					pPlayerPool = pNetGame->GetPlayerPool();
					if(pPlayerPool)
					{
						pLocalPlayer = pPlayerPool->GetLocalPlayer();
						if(pLocalPlayer)
						{
							if(pLocalPlayer->GetPlayerPed())
							{
								if(!pLocalPlayer->GetPlayerPed()->IsInVehicle() && !pLocalPlayer->GetPlayerPed()->IsAPassenger())
								{
									return 0;
								}
							}
						}
					}
				}
			}
		}
	}*/
	
	CPlayerPool *pPlayerPool;
	CLocalPlayer *pLocalPlayer;
	CVehiclePool *pVehiclePool = pNetGame->GetVehiclePool();
	bool ExistVehicle = true;

	pPlayerPool = pNetGame->GetPlayerPool();
	if(pPlayerPool)
	{
		pLocalPlayer = pPlayerPool->GetLocalPlayer();
		if(pLocalPlayer)
		{
			if(pLocalPlayer->GetPlayerPed())
			{
				if(!pLocalPlayer->GetPlayerPed()->IsInVehicle() && !pLocalPlayer->GetPlayerPed()->IsAPassenger())
				{
					int exception_vehicles[] = {406,425,432,435,441,449,450,464,465,476,481,484,485,486,501,509,510,512,513,520,530,531,
												532,537,539,564,568,570,571,572,574,583,584,591,593,594,606,607,608,610,611};
												
					for(uint16_t i = 0; i < sizeof(exception_vehicles); i++)
					{
						if(exception_vehicles[i] == *((uint16_t*)vehicle + 0x11))
						{
							ExistVehicle = false;
						}
					}
					if(ExistVehicle)
					{
						if(pSeatCar) pSeatCar->Show(true);		
					}
				}
				else
				{
					if(pSeatCar) pSeatCar->Show(false);
				}
			}
		}
	}	

	return CPad__ExitVehicleJustDown(thiz, a2, vehicle, a4, vec);
}

void (*CPed__ProcessControl)(uintptr_t thiz);
void CPed__ProcessControl_hook(uintptr_t thiz)
{
	dwCurPlayerActor = thiz;
	byteCurPlayer = FindPlayerNumFromPedPtr(dwCurPlayerActor);

	if( dwCurPlayerActor && (byteCurPlayer != 0))
	{
		// REMOTE PLAYER

		// byteCameraMode
		uint8_t byteSavedCameraMode = *pbyteCameraMode;
		*pbyteCameraMode = GameGetPlayerCameraMode(byteCurPlayer);
		
		uint16_t wSavedCameraMode2 = *wCameraMode2;
		*wCameraMode2 = GameGetPlayerCameraMode(byteCurPlayer);
		if (*wCameraMode2 == 4)* wCameraMode2 = 0;		

		GameStoreLocalPlayerCameraExtZoom();
		GameSetRemotePlayerCameraExtZoom(byteCurPlayer);

		GameStoreLocalPlayerAim();
		GameSetRemotePlayerAim(byteCurPlayer);
		
		// CPed::UpdatePosition nulled from CPed::ProcessControl
		NOP("0x439B7A", 2);
		
		*(uint8_t*)(pack("0x8E864C")) = byteCurPlayer;
		
		// Update remote player stats
		CRemoteDataStorage* pData = CRemoteData::GetRemoteDataStorage((PED_TYPE*)thiz);
		if (pData)
		{
			// Store local stats
			memcpy(localStatsTypesFloat, (float*)(g_libGTASA + 0x8C41A0), sizeof(localStatsTypesFloat));

			// Set stats to remote player
			memcpy((float*)(g_libGTASA + 0x8C41A0), pData->GetStatsTypesFloat(), sizeof(localStatsTypesFloat));
		}			

		// call original
		CPed__ProcessControl(thiz);
		
		// restore
		WriteMemory("0x439B7A", (uintptr_t)"\xFA\xF7\x1D\xF8", 4);
		*(uint8_t*)(pack("0x8E864C")) = 0;

    	*pbyteCameraMode = byteSavedCameraMode;
    	GameSetLocalPlayerCameraExtZoom();
    	GameSetLocalPlayerAim();	
		*wCameraMode2 = wSavedCameraMode2;	

		if (pData)
		{
			// Restore local stats
			memcpy((float*)(g_libGTASA + 0x8C41A0), localStatsTypesFloat, sizeof(localStatsTypesFloat));
		}
	}
	else
	{
		// LOCAL PLAYER

		// Apply the original code to set ped rot from Cam
		WriteMemory("0x4BED92", (uintptr_t)"\x10\x60", 2);

		(*CPed__ProcessControl)(thiz);

		// Reapply the no ped rots from Cam patch
		WriteMemory("0x4BED92", (uintptr_t)"\x00\x46", 2);	
	}

	return;
}

void AllVehicles__ProcessControl_hook(uintptr_t thiz)
{
	VEHICLE_TYPE *pVehicle = (VEHICLE_TYPE*)thiz;
	uintptr_t this_vtable = pVehicle->entity.vtable;
	this_vtable -= g_libGTASA;

	uintptr_t call_addr = 0;
	
	switch(this_vtable)
	{
		// CAutomobile
		case 0x5CC9F0:
		call_addr = 0x4E314C;
		break;

		// CBoat
		case 0x5CCD48:
		call_addr = 0x4F7408;
		break;

		// CBike
		case 0x5CCB18:
		call_addr = 0x4EE790;
		break;

		// CPlane
		case 0x5CD0B0:
		call_addr = 0x5031E8;
		break;

		// CHeli
		case 0x5CCE60:
		call_addr = 0x4FE62C;
		break;

		// CBmx
		case 0x5CCC30:
		call_addr = 0x4F3CE8;
		break;

		// CMonsterTruck
		case 0x5CCF88:
		call_addr = 0x500A34;
		break;

		// CQuadBike
		case 0x5CD1D8:
		call_addr = 0x505840;
		break;

		// CTrain
		case 0x5CD428:
		call_addr = 0x50AB24;
		break;
	}	

	if(pVehicle && pVehicle->pDriver)
	{
		byteCurDriver = FindPlayerNumFromPedPtr((uintptr_t)pVehicle->pDriver);
	}
	
	//if(pChatWindow) pChatWindow->AddDebugMessage("car gas %f",*((float *)thiz + 0x128));

	if(pVehicle->pDriver && pVehicle->pDriver->dwPedType == 0 && pVehicle->pDriver != GamePool_FindPlayerPed() && *(uint8_t*)(g_libGTASA+0x8E864C) == 0) // CWorld::PlayerInFocus
	{
		*(uint8_t*)(pack("0x8E864C")) = 0; 

		pVehicle->pDriver->dwPedType = 4;
		//CAEVehicleAudioEntity::Service
		(( void (*)(uintptr_t))(pack("0x364B64")+1))(thiz+0x138);
		pVehicle->pDriver->dwPedType = 0;
	}
	else
	{
		(( void (*)(uintptr_t))(pack("0x364B64")+1))(thiz+0x138);
	}
	
	// zero - classic buttons, one - adapted buttons
	/*int GetTypeButtons = *(int*)(g_libGTASA+0x63E4A4);
	
	// bmx subclass
	if(call_addr == 0x4F3CE8)
	{
		//remote
		if(byteCurDriver != 0)
		{
			CPlayerPool *pPlayerPool;
			CLocalPlayer *pLocalPlayer;		
			pPlayerPool = pNetGame->GetPlayerPool();
			if(pPlayerPool)
			{
				pLocalPlayer = pPlayerPool->GetLocalPlayer();
				if(pLocalPlayer)
				{
					if(!pLocalPlayer->GetPlayerPed()->IsInVehicle())
					{
						CTouchInterface_m_pWidgets = (int*)(pack("0x657E48"));
						if(CTouchInterface_m_pWidgets[2] && GetTypeButtons == 0)
						{
							//delete button GAS (classic)
							(( int (*)(int))(pack("0x2710AC")+1))(2); //CTouchInterface::DeleteWidget
						}						
					}
				}
			}
		}
		else //local
		{
			CTouchInterface_m_pWidgets = (int*)(pack("0x657E48"));
			if(!CTouchInterface_m_pWidgets[2] && GetTypeButtons == 0)
			{
				(( void (*)(void))(pack("0x27143C")+1))(); //CTouchInterface::CreateAll
			}
		}	
	}
	else //auto, bike, plane subclass etc..
	{
		if(byteCurDriver == 0)
		{
			CTouchInterface_m_pWidgets = (int*)(pack("0x657E48"));
			if(!CTouchInterface_m_pWidgets[2] && GetTypeButtons == 0)
			{
				(( void (*)(void))(pack("0x27143C")+1))(); //CTouchInterface::CreateAll
			}
		}
	}*/
	
	// not working
	// check if change classic buttons to adapted, then restore all buttons
	/*if(GetTypeButtons == 1)
	{
		CTouchInterface_m_pWidgets = (int*)(pack("0x6F3794"));
		if(!CTouchInterface_m_pWidgets[2])
		{
			//CreateAllWidgets
			(( void (*)(void))(pack("0x2AE500")+1))();			
		}
	}*/
	
	// VEHTYPE::ProcessControl()
    return (( void (*)(VEHICLE_TYPE*))(g_libGTASA+call_addr+1))(pVehicle);
}

// sync Q / E in Heli
//194B00 ; _DWORD CPad::GetTurretLeft(CPad *this)
uint32_t (*CPad__GetTurretLeft)(uintptr_t *thiz);
uint32_t CPad__GetTurretLeft_hook(uintptr_t *thiz)
{
	if(byteCurDriver != 0)
	{
		// remote player
		return RemotePlayerKeys[byteCurDriver].bKeys[ePadKeys::KEY_LOOK_LEFT];
	}
	else
	{
		// local player
		uint32_t look_left = CPad__GetTurretLeft(thiz);
		LocalPlayerKeys.bKeys[ePadKeys::KEY_LOOK_LEFT] = look_left;
		return look_left;
	}
}

//3FA466 ; _DWORD CPad::GetTurretRight(CPad *__hidden this)
uint32_t (*CPad__GetTurretRight)(uintptr_t *thiz);
uint32_t CPad__GetTurretRight_hook(uintptr_t *thiz)
{
	if(byteCurDriver != 0)
	{
		// remote player
		return RemotePlayerKeys[byteCurDriver].bKeys[ePadKeys::KEY_LOOK_RIGHT];
	}
	else
	{
		// local player
		uint32_t look_right = CPad__GetTurretRight(thiz);
		LocalPlayerKeys.bKeys[ePadKeys::KEY_LOOK_LEFT] = look_right;
		return look_right;
	}	
}

// WEAPONS

bool (*CPad__GetEnterTargeting)(uintptr_t thiz);
bool CPad__GetEnterTargeting_hook(uintptr_t thiz)
{	
	//if (byteCurPlayer)
	//{
	//	return 0;
	//}
	//else
	//{
		//return CPad__GetEnterTargeting(thiz);
	//}
	
	uint8_t byteCurrentPlayer = byteCurPlayer;
	if(dwCurPlayerActor)
	{
		if(byteCurPlayer != 0)
			return RemotePlayerKeys[byteCurPlayer].bKeys[ePadKeys::KEY_HANDBRAKE];

		byteCurrentPlayer = 0;
	}

	uint8_t old = *pbyteCurrentPlayer;
	*pbyteCurrentPlayer = byteCurrentPlayer;

	uint32_t result = CPad__GetEnterTargeting(thiz);
	LocalPlayerKeys.bKeys[ePadKeys::KEY_HANDBRAKE] = result ? 1 : 0;

	*pbyteCurrentPlayer = old;

	return LocalPlayerKeys.bKeys[ePadKeys::KEY_HANDBRAKE];
}

uint32_t (*CPad__GetWeapon)(uintptr_t thiz, PED_TYPE* pPed);
uint32_t CPad__GetWeapon_hook(uintptr_t thiz, PED_TYPE *pPed)
{
	uintptr_t dwRetAddr = 0;
 	__asm__ volatile ("mov %0, lr" : "=r" (dwRetAddr));
 	dwRetAddr -= g_libGTASA;

	//fix rotating camera when player (in spec) shootable
	if(dwRetAddr == 0x4C26EE + 1)
	{
		if(pNetGame)
		{
			CPlayerPool *pPlayerPool;
			CLocalPlayer *pLocalPlayer;		
			pPlayerPool = pNetGame->GetPlayerPool();
			if(pPlayerPool)
			{
				pLocalPlayer = pPlayerPool->GetLocalPlayer();
				if(pLocalPlayer)
				{
					if(pLocalPlayer->m_byteSpectateType == SPECTATE_TYPE_PLAYER)
					{		
						return 0;
					}
				}
			}
		}
	}
	
	if(dwCurPlayerActor && (byteCurPlayer != 0))
	{
		/*if(pNetGame)
		{
			CPlayerPool* pPlayerPool = pNetGame->GetPlayerPool();

			if(pPlayerPool->GetSlotState(pNetGame->GetPlayerPool()->FindRemotePlayerIDFromGtaPtr(pPed)) == true)
			{
				CRemotePlayer* pPlayer = pPlayerPool->GetAt(pNetGame->GetPlayerPool()->FindRemotePlayerIDFromGtaPtr(pPed));

				if(pPlayer && pPlayer->IsActive())
				{
					CPlayerPed* pPlayerPed = pPlayer->GetPlayerPed();
					//if(pChatWindow) pChatWindow->AddDebugMessage("ID gun %d",pPlayerPed->GetCurrentWeapon());
					if(pPlayerPed->GetCurrentWeapon() > 0 && pPlayerPed->GetCurrentWeapon() < 44)
					{
						return RemotePlayerKeys[byteCurPlayer].bKeys[ePadKeys::KEY_FIRE];
					}
				}
			}
		}
		return 0;
		*/
		
		return RemotePlayerKeys[byteCurPlayer].bKeys[ePadKeys::KEY_FIRE];
	}
	else
	{	
		bLocalTargeting = true;	
		
		uint8_t old = *(uint8_t*)(g_libGTASA + 0x008E864C);
		*(uint8_t*)(g_libGTASA + 0x008E864C) = byteCurPlayer;
		
		LocalPlayerKeys.bKeys[ePadKeys::KEY_FIRE] = CPad__GetWeapon(thiz, pPed);	
		
		*(uint8_t*)(g_libGTASA + 0x008E864C) = old;
		
		return LocalPlayerKeys.bKeys[ePadKeys::KEY_FIRE];
	}
}

uint32_t (*CCamera_IsTargetingActive)(uintptr_t thiz);
uint32_t CCamera_IsTargetingActive_hook(uintptr_t thiz)
{

	uintptr_t dwRetAddr = 0;
 	__asm__ volatile ("mov %0, lr" : "=r" (dwRetAddr));
 	dwRetAddr -= g_libGTASA;

 	if(dwRetAddr == 0x3ADAD7) {
 		return CCamera_IsTargetingActive(thiz);
 	}

 	if(dwRetAddr == 0x387455) {
 		return CCamera_IsTargetingActive(thiz);
 	}

	if(dwCurPlayerActor && (byteCurPlayer != 0))
	{
		return RemotePlayerKeys[byteCurPlayer].bKeys[ePadKeys::KEY_HANDBRAKE] ? 1 : 0;
	}
	else
	{
		*(uint8_t*)(g_libGTASA+0x8E864C) = 0;
		
		uint8_t getweapon = 0;
		
		if(pNetGame)
		{
			CPlayerPool *pPlayerPool;
			CLocalPlayer *pLocalPlayer;		
			pPlayerPool = pNetGame->GetPlayerPool();
			if(pPlayerPool)
			{
				pLocalPlayer = pPlayerPool->GetLocalPlayer();
				if(pLocalPlayer)
				{
					if(pLocalPlayer->GetPlayerPed()->GetCurrentWeapon() > 0)
					{
						bLocalTargeting = true;
						getweapon = pLocalPlayer->GetPlayerPed()->GetCurrentWeapon();
					}
					else
					{
						bLocalTargeting = false;
					}
				}
			}
		}				
		
		if(getweapon == 0)
		{
			return 0;
		}
		
		LocalPlayerKeys.bKeys[ePadKeys::KEY_HANDBRAKE] = CCamera_IsTargetingActive(thiz);
		
		return LocalPlayerKeys.bKeys[ePadKeys::KEY_HANDBRAKE];
	}
}

uint16_t (*CPad__SprintJustDown)(uintptr_t thiz);
uint16_t CPad__SprintJustDown_hook(uintptr_t thiz)
{
	if(dwCurPlayerActor && (byteCurPlayer != 0))
	{
		return RemotePlayerKeys[byteCurPlayer].bKeys[ePadKeys::KEY_SPRINT];
	}
	else
	{
		LocalPlayerKeys.bKeys[ePadKeys::KEY_SPRINT] = CPad__SprintJustDown(thiz);
		return LocalPlayerKeys.bKeys[ePadKeys::KEY_SPRINT];
	}
}

// TaskUseGun_Hook
void CTaskSimpleUseGun__SetPedPosition_hook(uintptr_t thiz, PED_TYPE* pPed)
{
	//Log("CTaskSimpleUseGun__SetPedPosition");
	dwCurPlayerActor = (uintptr_t)pPed;
	byteCurPlayer = FindPlayerNumFromPedPtr((uintptr_t)pPed);

	//if(dwCurPlayerActor && (byteCurPlayer != 0))
	if( dwCurPlayerActor && (byteCurPlayer != 0))
	{
		// remote player

		// byteCameraMode
		uint8_t byteSavedCameraMode = *pbyteCameraMode;
		*pbyteCameraMode = GameGetPlayerCameraMode(byteCurPlayer);
		
	    uint16_t wSavedCameraMode2 = *wCameraMode2;
        *wCameraMode2 = GameGetPlayerCameraMode(byteCurPlayer);
        if (*wCameraMode2 == 4)* wCameraMode2 = 0;	

		GameStoreLocalPlayerCameraExtZoom();
		GameSetRemotePlayerCameraExtZoom(byteCurPlayer);

		GameStoreLocalPlayerAim();
		GameSetRemotePlayerAim(byteCurPlayer);

		// called bug when all widgets delete! Shit game, fuck devs!
		//*(uint8_t*)(g_libGTASA + 0x96B9C4) = byteCurPlayer;	
		*(uint8_t*)(pack("0x8E864C")) = byteCurPlayer;

		// CTaskSimpleUseGun::SetPedPosition()
    	(( void (*)(uintptr_t, PED_TYPE*))(pack("0x46D6AC")+1))(thiz, pPed);

		PLAYERID anus = pNetGame->GetPlayerPool()->FindRemotePlayerIDFromGtaPtr(pPed);
		if(anus)
		{
			CRemotePlayer *pRemotePlayer = pNetGame->GetPlayerPool()->GetAt(anus);
			if(pRemotePlayer)
			{
				CPlayerPed* ped = pRemotePlayer->GetPlayerPed();
				if(ped)
				{
					if(ped->GetWaitAnimationGunFlash() == true)
					{
						ped->SetWaitAnimationGunFlash(false);
						((void (*)(uintptr_t, PED_TYPE*, int))(g_libGTASA + 0x46D4E5))(thiz, pPed, 0);
					}
				}
			}			
		}

    	*pbyteCameraMode = byteSavedCameraMode;
    	GameSetLocalPlayerCameraExtZoom();
		*(uint8_t*)(pack("0x8E864C")) = 0;	
    	GameSetLocalPlayerAim();
		*wCameraMode2 = wSavedCameraMode2;
	}
	else
	{
		// local player

		// CTaskSimpleUseGun::SetPedPosition()
    	(( void (*)(uintptr_t, PED_TYPE*))(pack("0x46D6AC")+1))(thiz, pPed);
	}
}

uint32_t (*CPad__GetNitroFired)(uintptr_t thiz);
uint32_t CPad__GetNitroFired_hook(uintptr_t thiz)
{
	if(byteCurDriver != 0)
	{
		// remote player
		return RemotePlayerKeys[byteCurDriver].bKeys[ePadKeys::KEY_FIRE];
	}
	else
	{
		// local player
		LocalPlayerKeys.bKeys[ePadKeys::KEY_FIRE] = CPad__GetNitroFired(thiz);
		return LocalPlayerKeys.bKeys[ePadKeys::KEY_FIRE];
	}
}

// CTouchInterface::IsTouched(CTouchInterface::WidgetIDs, CVector2D *, int)
uint32_t (*CTouchInterface__IsTouched)(int a1, int a2, signed int a3);
uint32_t CTouchInterface__IsTouched_hook(int a1, int a2, signed int a3)
{
	//if widget melee attack
	if(a1 == 1 && a2 == 0 && a3 == 1)
	{
		if(bLocalTargeting)
		{
			return 0;
		}
		else
		{
			return CTouchInterface__IsTouched(a1,a2,a3);
		}
	}
	
	return CTouchInterface__IsTouched(a1,a2,a3);
}

// fix default position scope for fire
// it stay called crash...
uint32_t (*CPad__GetTarget)(uintptr_t thiz, int a2, int a3, int a4);
uint32_t CPad__GetTarget_hook(uintptr_t thiz, int a2, int a3, int a4)
{
	uintptr_t dwRetAddr = 0;
 	__asm__ volatile ("mov %0, lr" : "=r" (dwRetAddr));
 	dwRetAddr -= g_libGTASA;	
	
	if(dwRetAddr == 0x2DACAC + 1)
	{
		if(!CPad__GetTarget(thiz, a2, a3, a4))
		{
			//if(pChatWindow) pChatWindow->AddDebugMessage("CRASH EXCEPTION! 5");
			//Log("CRASH EXCEPTION! 5");
			//Log("thiz 0x%x, a2 %d, a3 %d, a4 %d", thiz, a2, a3, a4);
			return 0;				
		}
	}
	/*else //useless
	{
		if (dwCurPlayerActor && (byteCurPlayer != 0))
		{
			return RemotePlayerKeys[byteCurPlayer].bKeys[ePadKeys::KEY_HANDBRAKE];
		}	
	}*/
	
	if(!dwCurWeaponProcessingPlayer) return 0;
	return *(uint8_t*)(*(uint32_t*)(dwCurWeaponProcessingPlayer + 1088) + 52) & 0b00001000;
}

uintptr_t(*CTaskSimplePlayerOnFoot__ProcessPlayerWeapon)(uintptr_t thiz, uintptr_t player_ped);
uintptr_t CTaskSimplePlayerOnFoot__ProcessPlayerWeapon_hook(uintptr_t thiz, uintptr_t player_ped)
{
	/*dwCurWeaponProcessingPlayer = player_ped;	
	///return CTaskSimplePlayerOnFoot__ProcessPlayerWeapon(thiz, player_ped);
	*/
	/*uintptr_t result;
	if (dwCurPlayerActor && (byteCurPlayer != 0))
	{
		*pbyteCurrentPlayer = byteCurPlayer;
		result = CTaskSimplePlayerOnFoot__ProcessPlayerWeapon(thiz, dwCurPlayerActor);
		*pbyteCurrentPlayer = 0;
	}
	else
	{
		result = CTaskSimplePlayerOnFoot__ProcessPlayerWeapon(thiz, dwCurPlayerActor);
	}
	return result;	
	*/
	
	dwCurWeaponProcessingPlayer = player_ped;
	uintptr_t toRetn = CTaskSimplePlayerOnFoot__ProcessPlayerWeapon(thiz, player_ped);

	dwCurWeaponProcessingPlayer = 0;
	return toRetn;	
	
}

uintptr_t(*CPad__ShiftTargetLeftJustDown)(uintptr_t thiz);
uintptr_t CPad__ShiftTargetLeftJustDown_hook(uintptr_t thiz)
{
	int test = CPad__ShiftTargetLeftJustDown(thiz);
	if(pChatWindow) pChatWindow->AddDebugMessage("aaa %d", test);
	return test;
}

uintptr_t(*CPlayerPed__ControlButtonSprint)(CPlayerPed* PlayerPed, int a2);
uintptr_t CPlayerPed__ControlButtonSprint_hook(CPlayerPed* PlayerPed, int a2)
{
	//fix when bmx going not touched on button
	uintptr_t dwRetAddr = 0;
 	__asm__ volatile ("mov %0, lr" : "=r" (dwRetAddr));
 	dwRetAddr -= g_libGTASA;
	
	//if(pChatWindow) pChatWindow->AddDebugMessage("deb 0x%x", dwRetAddr);

	//for logic: if we OnFoot - return its function (used in CTaskSimplePlayerOnFoot::PlayerControlZelda)
	//else (for logic game) if we use bmx - return 0
 	if(dwRetAddr == 0x4BECE7) 
	{
		if(!pNetGame) return 0;

		CPlayerPool *pPlayerPool;
		CLocalPlayer *pLocalPlayer;		
		pPlayerPool = pNetGame->GetPlayerPool();
		if(pPlayerPool)
		{
			pLocalPlayer = pPlayerPool->GetLocalPlayer();
			if(pLocalPlayer)
			{
				if(!pLocalPlayer->GetPlayerPed()->IsInVehicle())
				{
					return CPlayerPed__ControlButtonSprint(PlayerPed, a2);
				}
			}
		}		
 	}
	else if(dwRetAddr == 0x4F4357) //if called from CBmx::ProcessAI()
	{
		return 0;
	}
	
	return CPlayerPed__ControlButtonSprint(PlayerPed, a2);
}

signed int(*CPad__GetCarGunUpDown)(uintptr_t* cPad, int a2, uintptr_t* a3, float a4, bool a5);
signed int CPad__GetCarGunUpDown_hook(uintptr_t* cPad, int a2, uintptr_t* a3, float a4, bool a5)
{
	uintptr_t dwRetAddr = 0;
 	__asm__ volatile ("mov %0, lr" : "=r" (dwRetAddr));
 	dwRetAddr -= g_libGTASA;
	
	uintptr_t* get_pad = (( uintptr_t* (*)(int))(pack("0x39C8D4")+1))(byteCurDriver);
	
	//if(pChatWindow) pChatWindow->AddDebugMessage("h 0x%X | l 0x%X", cPad, get_pad);
	
	//CAutomobile::HydraulicControl || Hydraulic | Up - Down
 	if(dwRetAddr == 0x4D8004 + 1)
	{
		//up -128 (0xFF80) / down 128 (0x80)
		if(byteCurDriver != 0)
		{
			// remote player
			if(RemotePlayerKeys[byteCurDriver].bKeys[ePadKeys::KEY_ANALOG_UP] == 1 && RemotePlayerKeys[byteCurDriver].bKeys[ePadKeys::KEY_ANALOG_DOWN] == 0)
			{
				return -128;
			}
			if(RemotePlayerKeys[byteCurDriver].bKeys[ePadKeys::KEY_ANALOG_UP] == 0 && RemotePlayerKeys[byteCurDriver].bKeys[ePadKeys::KEY_ANALOG_DOWN] == 1)
			{
				return 128;
			}
		}
		else
		{
			// local player
			int UpDown = CPad__GetCarGunUpDown(cPad, a2, a3, a4, a5);
			// if Up pressed
			if(UpDown == -128)
			{
				LocalPlayerKeys.bKeys[ePadKeys::KEY_ANALOG_UP] = 1;
				return -128;
			}
			// if Down pressed
			if(UpDown == 128)
			{
				LocalPlayerKeys.bKeys[ePadKeys::KEY_ANALOG_DOWN] = 1;
				return 128;
			}
		}
	}	
	// CAutomobile::TowTruckControl
	if(dwRetAddr == 0x4DF996 + 1)
	{
		//fix (off) rope button for 525 (towtruck)
		if(a2 == 1 && a5 == false && a4 == 20000)
		{
			return 0;
		}
	}
	
	return CPad__GetCarGunUpDown(cPad, a2, a3, a4, a5);
}

uintptr_t(*CPad__GetCarGunLeftRight)(uintptr_t* cPad, int a2, int a3);
uintptr_t CPad__GetCarGunLeftRight_hook(uintptr_t* cPad, int a2, int a3)
{
	uintptr_t dwRetAddr = 0;
 	__asm__ volatile ("mov %0, lr" : "=r" (dwRetAddr));
 	dwRetAddr -= g_libGTASA;

	//Hydraulic | Left - Right
 	if(dwRetAddr == 0x4D7FE4 + 1)
	{
		//left -128 (0xFF80) / right 128 (0x80)
		if(byteCurDriver != 0)
		{
			// remote player
			if(RemotePlayerKeys[byteCurDriver].bKeys[ePadKeys::KEY_ANALOG_LEFT] == 1 && RemotePlayerKeys[byteCurDriver].bKeys[ePadKeys::KEY_ANALOG_RIGHT] == 0)
			{
				return -128;
			}
			if(RemotePlayerKeys[byteCurDriver].bKeys[ePadKeys::KEY_ANALOG_LEFT] == 0 && RemotePlayerKeys[byteCurDriver].bKeys[ePadKeys::KEY_ANALOG_RIGHT] == 1)
			{
				return 128;
			}
		}
		else
		{
			// local player
			int LeftRight = CPad__GetCarGunLeftRight(cPad, a2, a3);
			// if Left pressed
			if(LeftRight == -128)
			{
				LocalPlayerKeys.bKeys[ePadKeys::KEY_ANALOG_LEFT] = 1;
				return -128;
			}
			// if Right pressed
			if(LeftRight == 128)
			{
				LocalPlayerKeys.bKeys[ePadKeys::KEY_ANALOG_RIGHT] = 1;
				return 128;
			}
		}		
	}
	
	return CPad__GetCarGunLeftRight(cPad, a2, a3);
}

int LocalGetStateHydraulic = 0;
uint32_t (*CAutomobile__HydraulicControl)(uintptr_t CAutomobile);
uint32_t CAutomobile__HydraulicControl_hook(uintptr_t CAutomobile)
{
	if(byteCurDriver != 0)
	{
		// remote player
		//skip...
	}
	else
	{
		// local player
		uintptr_t m_wMiscComponentAngle = *(uintptr_t*)(CAutomobile + 0x87C);
		LocalGetStateHydraulic = (int)m_wMiscComponentAngle;
	}	
	return CAutomobile__HydraulicControl(CAutomobile);
}

uint32_t m_dwHornJustDown = GetTickCount();
uint32_t (*CPad__HornJustDown)(uintptr_t thiz);
uint32_t CPad__HornJustDown_hook(uintptr_t thiz)
{	
	uintptr_t dwRetAddr = 0;
 	__asm__ volatile ("mov %0, lr" : "=r" (dwRetAddr));
 	dwRetAddr -= g_libGTASA;

	//Hydraulic | JUMP
 	if(dwRetAddr == 0x4D7802 + 1)
	{		
		if(byteCurDriver != 0)
		{
			// remote player
			return RemotePlayerKeys[byteCurDriver].bKeys[ePadKeys::KEY_CROUCH];
		}
		else
		{
			// local player
			bool horn = CPad__HornJustDown(thiz);
			if(horn == 1)
			{
				if(GetTickCount() - m_dwHornJustDown < 400 )
					return 0;
				
				m_dwHornJustDown = GetTickCount();
				if(LocalGetStateHydraulic > 499)
				{
					LocalPlayerKeys.bKeys[ePadKeys::KEY_CROUCH] = 1;
					return horn;
				}
				else if(LocalGetStateHydraulic <= 60)
				{
					LocalPlayerKeys.bKeys[ePadKeys::KEY_CROUCH] = 1;
					return horn;
				}
			}
		}
	}
	return CPad__HornJustDown(thiz);
}

// 39EFC4 ; float __fastcall CPad::AimWeaponLeftRight(CPad *this, CPed *, bool *)
float (*CPad__AimWeaponLeftRight)(uintptr_t* thiz, uintptr_t* a2, uintptr_t* a3);
float CPad__AimWeaponLeftRight_hook(uintptr_t* thiz, uintptr_t* a2, uintptr_t* a3)
{
	// remote player
	if( dwCurPlayerActor && (byteCurPlayer != 0))
	{
		//...
	}
	else
	{	
		float tmp = CPad__AimWeaponLeftRight(thiz,a2, a3);

		// -15 .. 250
		
		int GetWeaponID = 0;
		bool AimStated = false;
		
		if(pNetGame)
		{
			CPlayerPed* pPlayerPed = pGame->FindPlayerPed();
			if(pPlayerPed)
			{
				if(LocalPlayerKeys.bKeys[ePadKeys::KEY_HANDBRAKE])
				{
					if(pPlayerPed->GetCurrentWeapon() == 0)
					{
						AimStated = false;
					}
					else if(pPlayerPed->GetCurrentWeapon() >= 22 && pPlayerPed->GetCurrentWeapon() <= 38)
					{
						AimStated = true;
					}
				}
				else
				{
					AimStated = false;
				}
			}
			
			if(AimStated)
			{
				GetWeaponID = pPlayerPed->GetCurrentWeapon() - 21;
			}
			else
			{
				GetWeaponID = 0;
			}
		}
		
		if(tmp == 0)
			return tmp;
		
		if(tmp > 0)
			return tmp + sensx[GetWeaponID];
		else
			return tmp - sensx[GetWeaponID];
	}
}

int (*CPad__AimWeaponUpDown)(uintptr_t* thiz, uintptr_t* a2, uintptr_t* a3);
int CPad__AimWeaponUpDown_hook(uintptr_t* thiz, uintptr_t* a2, uintptr_t* a3)
{
	// remote player
	if( dwCurPlayerActor && (byteCurPlayer != 0))
	{
		//...
	}
	else
	{
		int tmp = CPad__AimWeaponUpDown(thiz,a2, a3);

		// -15 .. 250
		
		int GetWeaponID = 0;
		bool AimStated = false;
		
		if(pNetGame)
		{
			CPlayerPed* pPlayerPed = pGame->FindPlayerPed();
			if(pPlayerPed)
			{			
				if(LocalPlayerKeys.bKeys[ePadKeys::KEY_HANDBRAKE])
				{
					if(pPlayerPed->GetCurrentWeapon() == 0)
					{
						AimStated = false;
					}
					else if(pPlayerPed->GetCurrentWeapon() >= 22 && pPlayerPed->GetCurrentWeapon() <= 38)
					{
						AimStated = true;
					}
				}
				else
				{
					AimStated = false;
				}			
			}
			
			if(AimStated)
			{
				GetWeaponID = pPlayerPed->GetCurrentWeapon() - 21;
			}
			else
			{
				GetWeaponID = 0;
			}
		}
		
		if(tmp == 0)
			return tmp;
		
		if(tmp > 0)
			return tmp + sensy[GetWeaponID];
		else
			return tmp - sensy[GetWeaponID];
	}
}

int switchweapon = 0;
bool sendswitchid = false;

extern "C"
{
	JNIEXPORT void JNICALL Java_com_nvidia_dev_1one_NvEventQueueActivity_SwitchWeapon(JNIEnv* pEnv, jobject thiz, jboolean click)
	{
		if(click)
		{
			switchweapon = 1;
		}
		else
		{
			switchweapon = 2;
		}
	}	
}

//39DD30 ; int __fastcall CPad::CycleWeaponRightJustDown(CPad *this)
int (*CPad__CycleWeaponRightJustDown)(uintptr_t *thiz);
int CPad__CycleWeaponRightJustDown_hook(uintptr_t *thiz)
{	
	// remote player
	if( dwCurPlayerActor && (byteCurPlayer != 0))
	{
		//...
	}
	else
	{
		if(sendswitchid)
		{
			CPlayerPed* pPlayerPed = pGame->FindPlayerPed();
			if(pPlayerPed)
			{		
				if(g_pJavaWrapper)
				{
					g_pJavaWrapper->SendSwitchWeapon(pPlayerPed->GetCurrentWeapon());
					sendswitchid = false;
				}
			}
		}		
		
		if(switchweapon == 1)
		{
			switchweapon = 0;
			sendswitchid = true;
			return 1;
		}
	}
	return CPad__CycleWeaponRightJustDown(thiz);
}

//39DCC4 ; int __fastcall CPad::CycleWeaponLeftJustDown(CPad *this)
int (*CPad__CycleWeaponLeftJustDown)(uintptr_t *thiz);
int CPad__CycleWeaponLeftJustDown_hook(uintptr_t *thiz)
{	
	// remote player
	if( dwCurPlayerActor && (byteCurPlayer != 0))
	{
		//...
	}
	else
	{
		if(sendswitchid)
		{
			CPlayerPed* pPlayerPed = pGame->FindPlayerPed();
			if(pPlayerPed)
			{		
				if(g_pJavaWrapper)
				{
					g_pJavaWrapper->SendSwitchWeapon(pPlayerPed->GetCurrentWeapon());
					sendswitchid = false;
				}
			}
		}		
		
		if(switchweapon == 2)
		{
			switchweapon = 0;
			sendswitchid = true;
			return 1;
		}
	}
	return CPad__CycleWeaponLeftJustDown(thiz);
}

//maybe useless
// 371808 ; float __fastcall CCam::Process_M16_1stPerson(CCam *this, VECTOR arg0, int a3, int a4, int a5)
int (*CCam__Process_M16_1stPerson)(uintptr_t *thiz, float *arg0, int a3, int a4, int a5);
int CCam__Process_M16_1stPerson_hook(uintptr_t *thiz, float *arg0, int a3, int a4, int a5)
{	
	if( dwCurPlayerActor && (byteCurPlayer != 0))
	{
		

	}
	else
	{
		// LOCAL PLAYER
		CCam__Process_M16_1stPerson(thiz, arg0, a3, a4, a5);
	}

}

// its for stop shake cam for local player when remote player if firing from sniper or rifle
void (*CamShakeNoPos)(uintptr_t* thiz, float a2);
void CamShakeNoPos_hook(uintptr_t* thiz, float a2)
{
	uintptr_t dwRetAddr = 0;
 	__asm__ volatile ("mov %0, lr" : "=r" (dwRetAddr));
 	dwRetAddr -= g_libGTASA;	
	
	//from CWeapon::FireSniper
	if(dwRetAddr == 0x566976 + 1)
	{	
		return;
	}
	
	return CamShakeNoPos(thiz, a2);
}

//its for fix bug when remote player use SNIPER or RIFLE
//it called Camera mode for local player
void (*CCamera__SetNewPlayerWeaponMode)(uintptr_t* thiz, int16_t mode, int16_t minZoom, int16_t MaxZoom);
void CCamera__SetNewPlayerWeaponMode_hook(uintptr_t* thiz, int16_t mode, int16_t minZoom, int16_t MaxZoom)
{
	if( dwCurPlayerActor && (byteCurPlayer != 0))
	{
		if(mode == 7 or mode == 34) //MODE_SNIPER or MODE_M16_1STPERSON (rifle)
			return;
		else if(mode == 46) //MODE_CAMERA
			return;
		else
		{
			*(int16_t*)(pack("0x8B0808") + 0x7B4) = mode;
			*(int16_t*)(pack("0x8B0808") + 0x7BE) = MaxZoom;
			*(int16_t*)(pack("0x8B0808") + 0x7BC) = minZoom;
			*(float*)(pack("0x8B0808") + 0x7B8) = 0;
		}
	}
	else
	{
		*(int16_t*)(pack("0x8B0808") + 0x7B4) = mode;
		*(int16_t*)(pack("0x8B0808") + 0x7BE) = MaxZoom;
		*(int16_t*)(pack("0x8B0808") + 0x7BC) = minZoom;
		*(float*)(pack("0x8B0808") + 0x7B8) = 0;
	}	
}

extern bool screen;
// its working is player camera is 46 (weapon_camera + handbrake)
bool (*sub_562D20)(uintptr_t *thiz);
bool sub_562D20_hook(uintptr_t *thiz)
{
	if(pChatWindow) pChatWindow->AddDebugMessage("sub_562D20");

	screen = true;
	
	return sub_562D20(thiz);
}

int (*CWeapon__TakePhotograph)(uintptr_t *thiz, uintptr_t *a2, uintptr_t *a3);
int CWeapon__TakePhotograph_hook(uintptr_t *thiz, uintptr_t *a2, uintptr_t *a3)
{
	/*if(pChatWindow) pChatWindow->AddDebugMessage("CWeapon__TakePhotograph");
	///if ( (PED_TYPE*)a2 == GamePool_FindPlayerPed() )
	///{
		//char CWeapon::ms_bPhotographHasBeenTaken
		*(char*)(pack("0x9E4A09")) = 1;
		//char CWeapon::ms_bTakePhoto
		*(char*)(pack("0x9E4A08")) = 1;
	///}
	*/
	if( dwCurPlayerActor && (byteCurPlayer != 0))
	{
		return 0;
	}
	else
	{
		LocalPlayerKeys.bKeys[ePadKeys::KEY_FIRE] = 1;
		
		//screen = true;
		
		//we skip fxsystem (effect white screen)
		
		//if camera = CAMERA_MODE
		/*if(*(uint16_t*)(pack("0x8B0808") + 0x7B4) == 46)
		{
			screen = true;
			//sub_562D20(thiz);
			return 0;
		}
		else */return CWeapon__TakePhotograph(thiz, a2, a3);
	}
}

// 4B6604; int __fastcall CTaskSimpleClimb::TestForClimb(CTaskSimpleClimb *this, CPed *, CVector *, float *, unsigned __int8 *, bool)
int (*CTaskSimpleClimb__TestForClimb)(uintptr_t *thiz, uintptr_t *a2, uintptr_t *a3, float *a4, uint8_t *a5, bool a6);
int CTaskSimpleClimb__TestForClimb_hook(uintptr_t *thiz, uintptr_t *a2, uintptr_t *a3, float *a4, uint8_t *a5, bool a6)
{
	uintptr_t dwRetAddr = 0;
 	__asm__ volatile ("mov %0, lr" : "=r" (dwRetAddr));
 	dwRetAddr -= g_libGTASA;

	if(!climb)
	{
		return 0;
	}
	return CTaskSimpleClimb__TestForClimb(thiz, a2, a3, a4, a5, a6);
}

void HookCPad()
{
	memset(&LocalPlayerKeys, 0, sizeof(PAD_KEYS));
	
	// CPed::ProcessControl
	Hook("0x45A280", (uintptr_t)CPed__ProcessControl_hook, (uintptr_t*)&CPed__ProcessControl);
	
	//for settings AutoClimb - disable or enable
	Hook("0x4B6604", (uintptr_t)CTaskSimpleClimb__TestForClimb_hook, (uintptr_t*)&CTaskSimpleClimb__TestForClimb);
	
	Hook("0x39EFC4", (uintptr_t)CPad__AimWeaponLeftRight_hook, (uintptr_t*)&CPad__AimWeaponLeftRight);
	Hook("0x39F100", (uintptr_t)CPad__AimWeaponUpDown_hook, (uintptr_t*)&CPad__AimWeaponUpDown);
	
	//send key_fire for CAMERA
	Hook("0x5635F8", (uintptr_t)CWeapon__TakePhotograph_hook, (uintptr_t*)&CWeapon__TakePhotograph);
	
	//Hook("0x562D20", (uintptr_t)sub_562D20_hook, (uintptr_t*)&sub_562D20);
	
	//sync for SNIPER
	//later for sync CAMERA
	///Hook("0x371808", (uintptr_t)CCam__Process_M16_1stPerson_hook, (uintptr_t*)&CCam__Process_M16_1stPerson);
	
	//its for sync SNIPER
	Hook("0x36E708", (uintptr_t)CamShakeNoPos_hook, (uintptr_t*)&CamShakeNoPos);
	
	// its for syns SNIPER etc
	Hook("0x3743A8", (uintptr_t)CCamera__SetNewPlayerWeaponMode_hook, (uintptr_t*)&CCamera__SetNewPlayerWeaponMode);
	
	// switch weapon for hud
	Hook("0x39DD30", (uintptr_t)CPad__CycleWeaponRightJustDown_hook, (uintptr_t*)&CPad__CycleWeaponRightJustDown);
	Hook("0x39DCC4", (uintptr_t)CPad__CycleWeaponLeftJustDown_hook, (uintptr_t*)&CPad__CycleWeaponLeftJustDown);
	
	//fix bmx
	Hook("0x457B60", (uintptr_t)CPlayerPed__ControlButtonSprint_hook, (uintptr_t*)&CPlayerPed__ControlButtonSprint);
	
	///Hook("0x45441C", (uintptr_t)CPlayerPed__GetPadFromPlayer_hook, (uintptr_t*)&CPlayerPed__GetPadFromPlayer);
	
	//fix button arrow up (towtruck)
	//sync hydraulic for lowrider
	Hook("0x39CD00", (uintptr_t)CPad__GetCarGunUpDown_hook, (uintptr_t*)&CPad__GetCarGunUpDown);
	Hook("0x39CEE4", (uintptr_t)CPad__GetCarGunLeftRight_hook, (uintptr_t*)&CPad__GetCarGunLeftRight);
	Hook("0x4D759C", (uintptr_t)CAutomobile__HydraulicControl_hook, (uintptr_t*)&CAutomobile__HydraulicControl);
	Hook("0x39D4F8", (uintptr_t)CPad__HornJustDown_hook, (uintptr_t*)&CPad__HornJustDown);
	
	//fix default aim with fire (from 2.0)
	Hook("0x4C1748", (uintptr_t)CTaskSimplePlayerOnFoot__ProcessPlayerWeapon_hook, (uintptr_t*)&CTaskSimplePlayerOnFoot__ProcessPlayerWeapon);
	
	///Hook("0x39E64C", (uintptr_t)CPad__ShiftTargetLeftJustDown_hook, (uintptr_t*)&CPad__ShiftTargetLeftJustDown);
	
	InstallMethodHook("0x5CCA1C", (uintptr_t)AllVehicles__ProcessControl_hook); // CAutomobile::ProcessControl
	InstallMethodHook("0x5CCD74", (uintptr_t)AllVehicles__ProcessControl_hook); // CBoat::ProcessControl
	InstallMethodHook("0x5CCB44", (uintptr_t)AllVehicles__ProcessControl_hook); // CBike::ProcessControl
	InstallMethodHook("0x5CD0DC", (uintptr_t)AllVehicles__ProcessControl_hook); // CPlane::ProcessControl
	InstallMethodHook("0x5CCE8C", (uintptr_t)AllVehicles__ProcessControl_hook); // CHeli::ProcessControl
	InstallMethodHook("0x5CCC5C", (uintptr_t)AllVehicles__ProcessControl_hook); // CBmx::ProcessControl
	InstallMethodHook("0x5CCFB4", (uintptr_t)AllVehicles__ProcessControl_hook); // CMonsterTruck::ProcessControl
	InstallMethodHook("0x5CD204", (uintptr_t)AllVehicles__ProcessControl_hook); // CQuadBike::ProcessControl
	InstallMethodHook("0x5CD454", (uintptr_t)AllVehicles__ProcessControl_hook); // CTrain::ProcessControl
	
	// TaskUseGun
	InstallMethodHook("0x5C8610", (uintptr_t)CTaskSimpleUseGun__SetPedPosition_hook);
	
	//sync Q / E in heli
	Hook("0x39D344", (uintptr_t)CPad__GetTurretLeft_hook, (uintptr_t*)&CPad__GetTurretLeft);
	Hook("0x39D368", (uintptr_t)CPad__GetTurretRight_hook, (uintptr_t*)&CPad__GetTurretRight);

	// lr/ud (onfoot)
	Hook("0x39D08C", (uintptr_t)CPad__GetPedWalkLeftRight_hook, (uintptr_t*)&CPad__GetPedWalkLeftRight);
	Hook("0x39D110", (uintptr_t)CPad__GetPedWalkUpDown_hook, (uintptr_t*)&CPad__GetPedWalkUpDown);

	// sprint/jump stuff
	Hook("0x39EAA4", (uintptr_t)CPad__GetSprint_hook, (uintptr_t*)&CPad__GetSprint);
	Hook("0x39E9B8", (uintptr_t)CPad__JumpJustDown_hook, (uintptr_t*)&CPad__JumpJustDown);
	Hook("0x39E96C", (uintptr_t)CPad__GetJump_hook, (uintptr_t*)&CPad__GetJump);
	Hook("0x39E824", (uintptr_t)CPad__GetAutoClimb_hook, (uintptr_t*)&CPad__GetAutoClimb);
	Hook("0x39E8C0", (uintptr_t)CPad__GetAbortClimb_hook, (uintptr_t*)&CPad__GetAbortClimb);

	// swimm
	Hook("0x39EA0C", (uintptr_t)CPad__DiveJustDown_hook, (uintptr_t*)&CPad__DiveJustDown);
	Hook("0x39EA4C", (uintptr_t)CPad__SwimJumpJustDown_hook, (uintptr_t*)&CPad__SwimJumpJustDown);

	Hook("0x39DD9C", (uintptr_t)CPad__MeleeAttackJustDown_hook, (uintptr_t*)&CPad__MeleeAttackJustDown);
	Hook("0x39E7B0", (uintptr_t)CPad__DuckJustDown_hook, (uintptr_t*)&CPad__DuckJustDown);
	Hook("0x39DB50", (uintptr_t)CPad__GetBlock_hook, (uintptr_t*)&CPad__GetBlock);

	// steering lr/ud (incar)
	Hook("0x39C9E4", (uintptr_t)CPad__GetSteeringLeftRight_hook, (uintptr_t*)&CPad__GetSteeringLeftRight);
	Hook("0x39CBF0", (uintptr_t)CPad__GetSteeringUpDown_hook, (uintptr_t*)&CPad__GetSteeringUpDown);

	Hook("0x39DB7C", (uintptr_t)CPad__GetAccelerate_hook, (uintptr_t*)&CPad__GetAccelerate);
	Hook("0x39D938", (uintptr_t)CPad__GetBrake_hook, (uintptr_t*)&CPad__GetBrake);
	Hook("0x39D754", (uintptr_t)CPad__GetHandBrake_hook, (uintptr_t*)&CPad__GetHandBrake);
	Hook("0x39D4C8", (uintptr_t)CPad__GetHorn_hook, (uintptr_t*)&CPad__GetHorn);
	Hook("0x39DA1C", (uintptr_t)CPad__ExitVehicleJustDown_hook, (uintptr_t*)&CPad__ExitVehicleJustDown);
	
	// WEAPON
	Hook("0x39E498", (uintptr_t)CPad__GetEnterTargeting_hook, (uintptr_t*)&CPad__GetEnterTargeting);
	Hook("0x39E038", (uintptr_t)CPad__GetWeapon_hook, (uintptr_t*)&CPad__GetWeapon);
	Hook("0x37440C", (uintptr_t)CCamera_IsTargetingActive_hook, (uintptr_t*)&CCamera_IsTargetingActive);
	Hook("0x39E418", (uintptr_t)CPad__GetTarget_hook, (uintptr_t*)&CPad__GetTarget);
	//Hook("0x569374", (uintptr_t)CWeapon__Fire_hook, (uintptr_t*)&CWeapon__Fire);

	
	Hook("0x39EB50", (uintptr_t)CPad__SprintJustDown_hook, (uintptr_t*)&CPad__SprintJustDown);
	
	Hook("0x39D54C", (uintptr_t)CPad__GetNitroFired_hook, (uintptr_t*)&CPad__GetNitroFired);
	
	Hook("0x26EF54", (uintptr_t)CTouchInterface__IsTouched_hook, (uintptr_t*)&CTouchInterface__IsTouched);
}