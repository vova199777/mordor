#pragma once

#include "vehicle.h"

typedef struct _ATTACHED_OBJECT
{
	int iModel;
	int iBoneID;
	VECTOR vecOffset;
	VECTOR vecRotation;
	VECTOR vecScale;
	uint32_t dwMaterialColor1;
	uint32_t dwMaterialColor2;
} ATTACHED_OBJECT;

class CObject : public CEntity
{
public:
	MATRIX4X4	m_matTarget;
	MATRIX4X4	m_matCurrent;
	uint8_t		m_byteMoving;
	float		m_fMoveSpeed;
	bool		m_bIsPlayerSurfing;
	CQuaternion m_quatTarget;
	CQuaternion m_quatStart;	
	
	VECTOR m_vecAttachedOffset;
	VECTOR m_vecAttachedRotation;
	uint16_t m_usAttachedVehicle;
	uint8_t m_bAttachedType;
	
	uint32_t 	m_dwMoveTick;
	bool		m_bNeedRotate;
	float		m_fDistanceToTargetPoint;	
	
	VECTOR 		m_vecRotationTarget;
	VECTOR		m_vecSubRotationTarget;	
	
	VECTOR 		m_vecRot;
	VECTOR		m_vecTargetRot;
	VECTOR		m_vecTargetRotTar;

	CObject(int iModel, float fPosX, float fPosY, float fPosZ, VECTOR vecRot, float fDrawDistance);
	~CObject();

	void Process(float fElapsedTime);
	float DistanceRemaining(MATRIX4X4 *matPos);
	float DistanceRemainingFix(MATRIX4X4 *matPos);
	void RotateMatrix(VECTOR vec);
	void GetRotation(float* pfX,float* pfY,float* pfZ);
	void ApplyMoveSpeed();

	void SetPos(float x, float y, float z);
	void MoveTo(float fX, float fY, float fZ, float fSpeed, float fRotX, float fRotY, float fRotZ);
	void StopMoving();

	void InstantRotate(float x, float y, float z);
	
	void AttachToVehicle(uint16_t usVehID, VECTOR* pVecOffset, VECTOR* pVecRot);
	void ProcessAttachToVehicle(CVehicle* pVehicle);
};