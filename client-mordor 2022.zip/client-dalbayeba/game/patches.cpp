#include "../main.h"
#include "../util/armhook.h"
#include "common.h"
#include "settings.h" 

#include "RW/RenderWare.h"

#include <sys/system_properties.h>

#include <dirent.h>


#include <unistd.h>
#include <math.h>
#include <ctype.h>
#include <string.h>
#include <map>


char* PLAYERS_REALLOC = nullptr;

CSettings *Settings = nullptr;

//==============================================
struct _ATOMIC_MODEL
{
    uintptr_t func_tbl;
    uint8_t data[56];
};
struct _ATOMIC_MODEL *ATOMIC_MODELS;
//==============================================

VehicleAudioPropertiesStruct VehicleAudioProperties[20000];

void readVehiclesAudioSettings() 
{

	char vehicleModel[50];
	int16_t pIndex = 0;

	FILE* pFile;

	char line[300];

	// Zero VehicleAudioProperties
	memset(VehicleAudioProperties, 0x00, sizeof(VehicleAudioProperties));

	VehicleAudioPropertiesStruct CurrentVehicleAudioProperties;

	memset(&CurrentVehicleAudioProperties, 0x0, sizeof(VehicleAudioPropertiesStruct));

	char buffer[0xFF];
	sprintf(buffer, "%sSAMP/vehicleAudioSettings.cfg", g_pszStorage);
	pFile = fopen(buffer, "r");
	if (!pFile)
	{
		Log("Cannot read vehicleAudioSettings.cfg");
		return;
	}
	else Log("vehicleAudioSettings.cfg is loaded!");

	// File exists
	while (fgets(line, sizeof(line), pFile))
	{
		if (strncmp(line, ";the end", 8) == 0)
			break;

		if (line[0] == ';')
			continue;

		sscanf(line, "%s %d %d %d %d %f %f %d %f %d %d %d %d %f",
			vehicleModel,
			&CurrentVehicleAudioProperties.VehicleType,
			&CurrentVehicleAudioProperties.EngineOnSound,
			&CurrentVehicleAudioProperties.EngineOffSound,
			&CurrentVehicleAudioProperties.field_4,
			&CurrentVehicleAudioProperties.field_5,
			&CurrentVehicleAudioProperties.field_6,
			&CurrentVehicleAudioProperties.HornTon,
			&CurrentVehicleAudioProperties.HornHigh,
			&CurrentVehicleAudioProperties.DoorSound,
			&CurrentVehicleAudioProperties.RadioNum,
			&CurrentVehicleAudioProperties.RadioType,
			&CurrentVehicleAudioProperties.field_14,
			&CurrentVehicleAudioProperties.field_16);

		int result = ((int (*)(const char* thiz, int16_t* a2))(g_libGTASA + 0x00336110 + 1))(vehicleModel, &pIndex);
		memcpy(&VehicleAudioProperties[pIndex-400], &CurrentVehicleAudioProperties, sizeof(VehicleAudioPropertiesStruct));
	}

	fclose(pFile);
}

int test_pointsArray[1000];
int test_pointersLibArray[1000];

void ApplyPatches_level0()
{
	// reallocate CWorld::Players[]
	//PLAYERS_REALLOC = new char[404*PLAYER_PED_SLOTS];
	///PLAYERS_REALLOC = (( char* (*)(int))(pack("0x179B40")))(404*MAX_PLAYERS);
	///UnFuck("0x5D021C");
	///*(char**)(g_libGTASA+0x5D021C) = PLAYERS_REALLOC;
	///Log("CWorld::Player new address = 0x%X", PLAYERS_REALLOC);
	
	PLAYERS_REALLOC = ((char* (*)(uint32_t))(pack("0x179B40")))(404 * 257 * sizeof(char));
	memset(PLAYERS_REALLOC, 0, 404 * 257);
	UnFuck("0x5D021C");
	*(char**)(g_libGTASA + 0x5D021C) = PLAYERS_REALLOC;	
	
	// 3 touch begin
	UnFuck("0x5D1E8C");
	memset(test_pointsArray, 0, 999 * sizeof(int));
	*(int**)(g_libGTASA + 0x5D1E8C) = &test_pointsArray[0];

	UnFuck("0x63D4F0");
	memset(test_pointersLibArray, 0, 999 * sizeof(int));
	*(int**)(g_libGTASA + 0x0063D4F0) = &test_pointersLibArray[0];

	WriteMemory("0x238232", (uintptr_t)"\x03\x20", 2);
	WriteMemory("0x25C522", (uintptr_t)"\x02\x2C", 2);
	// 3 touch end	

	// CdStreamInit(6);
	WriteMemory("0x3981EC", (uintptr_t)"\x06\x20", 2);
	
    // allocate Atomic models pool
    ATOMIC_MODELS = new _ATOMIC_MODEL[20000];
    for (int i = 0; i < 20000; i++)
    {
    // CBaseModelInfo::CBaseModelInfo
        ((void(*)(_ATOMIC_MODEL*))(pack("0x33559D")))(&ATOMIC_MODELS[i]);
        ATOMIC_MODELS[i].func_tbl = pack("0x5C6C68");
        memset(ATOMIC_MODELS[i].data, 0, sizeof(ATOMIC_MODELS->data));
    }	
	
	/*
	uintptr_t g_libSCAnd = FindLibrary(BOEV("libSCAnd.so"));
	
	int dest = g_libSCAnd + 0x1E16DC;
	int dest2 = g_libSCAnd + 0x1E1738;
	
	const char* viewmanager = BOEV("com/rockstargames/hal/andViewManager");
	const char* exitsc = BOEV("staticExitSocialClub");
	const char* ve = "()V";
	
	WriteMemoryOrig(dest, (uintptr_t)viewmanager, 37);
	WriteMemoryOrig(dest2, (uintptr_t)exitsc, 21);
	WriteMemoryOrig(g_libSCAnd + 0x1E080C, (uintptr_t)ve, 4);
	*/
}

void ApplyPatches()
{
	lastfunc("a1");
	Log("Installing patches..");
	
	// nop check CWorld::FindPlayerSlotWithPedPointer (fuck*** R*)
	// just left mov r4, r0 and ldr r1 [pc, shit]
	NOP("0x45A4C8", 11);
	NOP("0x45A4E0", 3);	
	
	//no steal object in home
	///its called error in CTaskComplexGoPickUpEntity::~CTaskComplexGoPickUpEntity && CEntity::CleanUpOldReference
	//UnFuck("0x3AC114");
	//WriteMemory("0x3AC114", (uintptr_t)"\xF7\x46", 2);
	///change it shit to..
	//NOP("0x3ADEEA", 62);

	Settings = new CSettings();
	
	//ToggleDebugFPS
	/*if(Settings->Get().DEBUGFPS == true)
	{
		*(uint8_t*)(pack("0x8ED875")) = 1;
	}
	else
	{
		*(uint8_t*)(pack("0x8ED875")) = 0;
	}*/
	
	uint8_t fps = 60;
	if (Settings)
	{
		fps = Settings->Get().fps;
	}
	WriteMemory("0x463FE8", (uintptr_t)& fps, 1);
	WriteMemory("0x56C1F6", (uintptr_t)& fps, 1);
	WriteMemory("0x56C126", (uintptr_t)& fps, 1);
	WriteMemory("0x95B074", (uintptr_t)& fps, 1);
	
	//fix stop joystick with 30 fps and more (60 / 90 / 120)
	//orig code
	//float fps_timeStep = fps / 428.5714f;
	//float timeStep = ((int)(100 * fps_timeStep)) / 100.0f;
	
	//packed code
	float fps_timeStep = fps / s2f(BOEV("428.5714"));
	float timeStep = ((int)(s2d(BOEV("100")) * fps_timeStep)) / s2f(BOEV("100.0"));
	
	UnFuck("0x46C03C");
	*(float*)(pack("0x46C03C")) = timeStep;
	
	// CWidgetRegionSteeringSelection::Draw
	WriteMemory("0x284BB8", (uintptr_t)"\xF7\x46", 2);
	
	//fix alpha channel
	//_rwOpenGLRasterCreate
	UnFuck("0x1859FC");
	WriteMemory("0x1859FC", (uintptr_t)"\x01\x22", 2); //hui znaet
	
	/*DIR *dir;
	struct dirent *ent;
	if ((dir = opendir ("/data/data/com.rockstargames.gtasa/lib/")) != NULL)
	{
		while ((ent = readdir (dir)) != NULL) 
		{
			Log ("%s", ent->d_name);
		}
		closedir (dir);
	}
	else
	{
		Log("error open");
	}*/
	
	//CFileLoader::LoadPickup
	WriteMemory("0x401BAC", (uintptr_t)"\xF7\x46", 2);
	
	// radar draw blips
    UnFuck("0x3DCA90");
    NOP("0x3DCA90", 2);
    UnFuck("0x3DD4A4");
    NOP("0x3DD4A4", 2);


	//����� �������� ��� �� �����������, �� ��� �������, ��� ���������� ����������� ������� ��� ��������
	//CAudioEngine::StartRadio(tVehicleAudioSettings *)
	//WriteMemory("0x3BD31C", (uintptr_t)"\xF7\x46", 2);
	
	//CAudioEngine::StartRadio(CAudioEngine *__hidden this, signed __int8, signed __int8)
	//WriteMemory("0x3BD2D0", (uintptr_t)"\xF7\x46", 2);
	
	//������ ����� ����
	
	//disabled radar
	//NOP(g_libGTASA+0x43A560, 4);

	//disabled ������� ������
	NOP("0x3D370C", 4);
	NOP("0x3D373A", 4);
	NOP("0x3D3768", 4);
	NOP("0x3D3792", 4);
	
	//zoom radar
	//UnFuck(g_libGTASA+0x43E3A8);
	//*(float*)(g_libGTASA+0x43E3A8) = 270;
	
	//rectangle radar
	UnFuck("0x3DED84");
	*(float*)(g_libGTASA+0x3DED84) = 0;
	
	//������������ ������ ���� �����
	//UnFuck("0x43E176");
	//NOP("0x43E176", 4);
	
 	// VehicleStruct increase (0x32C*0x50 = 0xFDC0)
    WriteMemory("0x405338", (uintptr_t)"\x4F\xF6\xC0\x50", 4);	// MOV  R0, #0xFDC0
    WriteMemory("0x405342", (uintptr_t)"\x50\x20", 2);			// MOVS R0, #0x50
    WriteMemory("0x405348", (uintptr_t)"\x50\x22", 2);			// MOVS R2, #0x50
    WriteMemory("0x405374", (uintptr_t)"\x50\x2B", 2);			// CMP  R3, #0x50
	
	//LightsCreate(RpWorldAddLight(v1, pDirect)) (delete light for objects)
	NOP("0x408AAA", 4);

	// CAudioEngine::StartLoadingTune
	NOP("0x56C150", 2);

	// DefaultPCSaveFileName
	char* DefaultPCSaveFileName = (char*)(pack("0x60EAE8"));
	memcpy((char*)DefaultPCSaveFileName, "GTASAMP", 8);

	// CHud::SetHelpMessage
	WriteMemory("0x3D4244", (uintptr_t)"\xF7\x46", 2);
	// CHud::SetHelpMessageStatUpdate
	WriteMemory("0x3D42A8", (uintptr_t)"\xF7\x46", 2);
	// CVehicleRecording::Load
	WriteMemory("0x2DC8E0", (uintptr_t)"\xF7\x46", 2);	
	
	//cwidgetbutton exit vehicle
	//WriteMemory(g_libGTASA+0x2B64CC, (uintptr_t)"\xF7\x46", 2);
	
	// nop calling CRealTimeShadowManager::ReturnRealTimeShadow from ~CPhysical
	NOP("0x3A019C", 2);
	
	//CRealTimeShadowManager::Update	
	WriteMemory("0x541AC4", (uintptr_t)"\xF7\x46", 2);	
	
	// Increase matrix count in CPlaceable::InitMatrixArray 
 	WriteMemory("0x3ABB0A", (uintptr_t)"\x4F\xF4\x7A\x61", 4); // MOV.W R1, #4000
	
	// -- Fix artifacts on the left corner of the screen
	*(float*)(g_libGTASA + 0x608558) = 200.0f;

}

void ApplyInGamePatches()
{
	lastfunc("a2");
	Log("Installing patches (ingame)..");	
	
	//new limit colors cars
	//uint8_t new_colors[1024];
	//*(uint8_t*)(g_libGTASA+0x931560) = *(uint8_t*)new_colors;
	
	//Log("car color %d %d %d",*(uint8_t*)(g_libGTASA+0x931560 + (221*4)),*(uint8_t*)(g_libGTASA+0x931560 + (221*4) + 1),*(uint8_t*)(g_libGTASA+0x931560 + (221*4) + 2));

	/* ������������� ����� */
	// CTheZones::ZonesVisited[100]
	memset((void*)(pack("0x8EA7B0")), 1, 100);
	// CTheZones::ZonesRevealed
	*(uint32_t*)(pack("0x8EA7A8")) = 100;

	// CTaskSimplePlayerOnFoot::PlayIdleAnimations 
	WriteMemory("0x4BDB18", (uintptr_t)"\x70\x47", 2);

	// CarCtl::GenerateRandomCars nulled from CGame::Process
	UnFuck("0x398A3A");
	NOP("0x398A3A", 2);

	// CTheCarGenerators::Process nulled from CGame::Process
	UnFuck("0x398A34");
	NOP("0x398A34", 2);

	// ��������� ��� MaxHealth
	UnFuck("0x3BAC68");
	*(float*)(pack("0x3BAC68")) = 176.0f;
	// ��������� ��� Armour
	UnFuck("0x27D884");
	*(float*)(pack("0x27D884")) = 176.0f;

	// CEntryExit::GenerateAmbientPeds nulled from CEntryExit::TransitionFinished
	UnFuck("0x2C2C22");
	NOP("0x2C2C22", 4);

	// potra4eno
	UnFuck("0x3AC8B2");
	NOP("0x3AC8B2", 2);

	// CPlayerPed::CPlayerPed task fix
	WriteMemory("0x458ED1", (uintptr_t)"\xE0", 1);
	
    // CCamera::CamShake from CExplosion::AddExplosion
    NOP("0x55EFB8", 2);
    NOP("0x55F8F8", 2);

    // CPed::RemoveWeaponWhenEnteringVehicle (GetPlayerInfoForThisPlayerPed)
    UnFuck("0x434D94");
    NOP("0x434D94", 6);

    // CBike::ProcessAI
    UnFuck("0x4EE200");
    *(uint8_t*)(g_libGTASA+0x4EE200) = 0x9B;

    // no vehicle audio processing
    UnFuck("0x4E31A6"); //CAutomobile::ProcessControl
    NOP("0x4E31A6", 2);
    UnFuck("0x4EE7D2"); //CBike::ProcessControl
    NOP("0x4EE7D2", 2);
    UnFuck("0x4F741E"); //CBoat::ProcessControl
    NOP("0x4F741E", 2);
    UnFuck("0x50AB4A"); //CTrain::ProcessControl
    NOP("0x50AB4A", 2);	
	
	//new patches
	//=============================================================

	
	//CAEGlobalWeaponAudioEntity::ServiceAmbientGunFire
	WriteMemory("0x3474E0", (uintptr_t)"\xF7\x46", 2);
	
	//CPlaceName::Process
	WriteMemory("0x3BF8B4", (uintptr_t)"\xF7\x46", 2);
	
	//CHud::DrawVehicleName
	WriteMemory("0x3D541C", (uintptr_t)"\xF7\x46", 2);
	
	//CPlane::DoPlaneGenerationAndRemoval
	WriteMemory("0x504DB8", (uintptr_t)"\xF7\x46", 2);
	
	// its called crash in CPed::SetCharCreatedBy
	//CPopulation::AddPed
	///WriteMemory("0x45F1A4", (uintptr_t)"\xF7\x46", 2);
	NOP("0x4612A0", 9);  // CPedIntelligence::SetPedDecisionMakerType from CPopulation::AddPedAtAttractor
	WriteMemory("0x45FC20", (uintptr_t)"\x4F\xF0\x00\x00\xF7\x46", 6); // CPopulation::AddToPopulation
	
	//CCarEnterExit::SetPedInCarDirect
	//WriteMemory("0x494FE4", (uintptr_t)"\xF7\x46", 2);
	
	//CPlayerPed::ProcessAnimGroups
	UnFuck("0x45477E");
	NOP("0x45477E", 5);
	
	//RwCameraEndUpdate	
	//UnFuck("0x39A642");
	//NOP("0x39A642", 2);
	
	//disable aim
    WriteMemory("0x438DB4", (uintptr_t)"\xF7\x46", 2);
	WriteMemory("0x4568B0", (uintptr_t)"\xF7\x46", 2);
	WriteMemory("0x4590E4", (uintptr_t)"\xF7\x46", 2);
	
	//disable CCheat::DoCheats(CCheat *__hidden this)
	WriteMemory("0x2BC24C", (uintptr_t)"\xF7\x46", 2);

	//camera_on_actor patch, tsk tsk R* (for Spectate Actor)
    UnFuck("0x2F7B68");
    *(uint8_t*)(pack("0x2F7B6B")) = 0xBE;
	
	// CWidgetPlayerInfo::DrawWanted
    WriteMemory("0x27D8D0", (uintptr_t)"\x4F\xF0\x00\x08", 4);

	// Interior_c::AddPickups
	//WriteMemory("0x3E17F0", (uintptr_t)"\xF7\x46", 2);
	
	// InteriorGroup_c::Exit
	//WriteMemory("0x3E42E0", (uintptr_t)"\xF7\x46", 2);
	
	// remove motion blur in high speed vehicle
	WriteMemory("0x53EC78", (uintptr_t)"\xF7\x46", 2);
	
	// Disable vehicle gifts
	// - Shotgun from police cars (596-599)
	// - $12 from taxi cars (420,438)
	// - 20 health from Ambulance (416)
	// - Armor from Enforcer (427)
	// - Golf Club from Caddy (457)
	// - Stat increment from Hotdog (588)
	//WriteMemory("0x584664", (uintptr_t)"\xA0\xF1\x00\x01", 4);
	//poka otlojim
	WriteMemory("0x50FEFE", (uintptr_t)"\x1B\x00", 2);
	
	// lock Golf gun
	UnFuck("0x5101A6");
	NOP("0x5101A6", 2);
	
	// lock shotgun gun
	UnFuck("0x51018A");
	NOP("0x51018A", 2);
	
	// lock ammo for shotgun gun
	UnFuck("0x5101B4");
	NOP("0x5101B4", 2);
	
	// delete line TRAFFIC MODE (Game settings)
	//UnFuck("0x2A4928");
	//NOP("0x2A4928", 2);	
	
	// delete line TARGETING MODE - FREE AIM/LOCK MODE (Game settings)
	//UnFuck("0x2A494E");
	//NOP("0x2A494E", 2);
	
	//TARGETING MODE - FREE AIM
	*(uint8_t*)(pack("0x63E444")) = 1;
	
	// delete line FRAME LIMITER (Game settings)
	//UnFuck("0x2A49C0");
	//NOP("0x2A49C0", 2);
	
	// delete line SIGN IN SOCIAL CLUB (Game settings)
	//UnFuck("0x2A49F2");
	//NOP("0x2A49F2", 2);
	
	// delete line SHADOWS (Display settings)
	//UnFuck("0x2A4B80");
	//NOP("0x2A4B80", 2);	
	
	// delete line SUBTITLES (Display settings)
	//UnFuck("0x2A4BD0");
	//NOP("0x2A4BD0", 2);		
	
	// Increase intensity of vehicle tail light corona (from MTA, but it exist in SAMP)
	//WriteMemory("0x591016", (uintptr_t)"\xF0\x23", 2);
	
	// Fix vehicle back lights both using light state 3 (SA bug)
	//WriteMemory("0x591272",(uintptr_t)"\x02\x21", 2);
}