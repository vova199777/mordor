#include "main.h"
#include "game.h"

CAMERA_AIM * pcaInternalAim = nullptr;
uint8_t *pbyteCameraMode = nullptr;
float *pfCameraExtZoom = nullptr;
float *pfAspectRatio = nullptr;
uint8_t *pbyteCurrentPlayer = nullptr;


CAMERA_AIM caLocalPlayerAim;
CAMERA_AIM caRemotePlayerAim[MAX_PLAYERS];

uint8_t byteCameraMode[MAX_PLAYERS];

float fCameraExtZoom[MAX_PLAYERS];
float fLocalCameraExtZoom;

float fCameraAspectRatio[MAX_PLAYERS];
float fLocalAspectRatio;

uint16_t* wCameraMode2 = nullptr;

void GameAimSyncInit()
{
	memset(&caLocalPlayerAim, 0, sizeof(CAMERA_AIM));
	memset(caRemotePlayerAim, 0, sizeof(CAMERA_AIM) * MAX_PLAYERS);
	memset(byteCameraMode, 4, MAX_PLAYERS);
	
	for(int i=0; i<MAX_PLAYERS; i++)
	{
		fCameraExtZoom[i] = 1.0f;
		fCameraAspectRatio[i] = 0.333333f;	
	}

	pcaInternalAim = (CAMERA_AIM*)(pack("0x8B0AE0"));
	pbyteCameraMode = (uint8_t*)(pack("0x8B0808") + 0x17E);
	pfAspectRatio = (float*)(pack("0x98525C"));
	pfCameraExtZoom = (float*)(pack("0x8B0808") + 0x1FC);
	
	wCameraMode2 = (uint16_t*)(pack("0x8B0808") + 0x7B4);

	pbyteCurrentPlayer = (uint8_t*)(pack("0x8E864C"));
}

CAMERA_AIM* GameGetInternalAim()
{
	return pcaInternalAim;
}

CAMERA_AIM* GameGetInternalAimFix()
{
	return (CAMERA_AIM*)(g_libGTASA + 0x008B0808 + 528 * *((unsigned char*)(g_libGTASA + 0x008B085F)) + 728);
}

uint8_t GameGetLocalPlayerCameraMode()
{
	lastfunc("am1");
	// TheCamera.m_aCams[0].m_wMode
	// CWeapon::FireSniper *((unsigned __int16 *)&TheCamera + 0x108 * (unsigned __int8)TheCamera_nActiveCam + 0xBF
	// TheCamera = 0x951FA8
	return *pbyteCameraMode;
}

float GameGetAspectRatio()
{
	lastfunc("am2");
	return *pfAspectRatio;
}

float GameGetLocalPlayerCameraExtZoom()
{
	lastfunc("am3");
	//return (*pfCameraExtZoom - 35.0f) * 0.028571429f;
	float value = ((*pfCameraExtZoom) - 35.0f) / 35.0f;	// normalize for 70.0 to 35.0
	return value;	
}

void GameStoreLocalPlayerCameraExtZoom()
{
	lastfunc("am4");
	fLocalCameraExtZoom = *pfCameraExtZoom;
	fLocalAspectRatio = *pfAspectRatio;
}

void GameSetRemotePlayerCameraExtZoom(uint8_t bytePlayerID)
{
	lastfunc("am5");
	*pfCameraExtZoom = fCameraExtZoom[bytePlayerID] * 35.0 + 35.0;
	*pfAspectRatio = fCameraAspectRatio[bytePlayerID] + 1.0;
}

uint8_t GameGetPlayerCameraMode(uint8_t bytePlayerID)
{
	lastfunc("am6");
	return byteCameraMode[bytePlayerID];
}

void GameStoreLocalPlayerAim()
{
	lastfunc("am7");
	memcpy(&caLocalPlayerAim, pcaInternalAim, sizeof(CAMERA_AIM));
}

void GameSetRemotePlayerAim(uint8_t bytePlayerID)
{
	lastfunc("am8");
	memcpy(pcaInternalAim, &caRemotePlayerAim[bytePlayerID], sizeof(CAMERA_AIM));
}

void GameSetLocalPlayerCameraExtZoom()
{
	lastfunc("am9");
	*pfCameraExtZoom = fLocalCameraExtZoom;
	*pfAspectRatio = fLocalAspectRatio;
}

void GameSetLocalPlayerAim()
{
	lastfunc("am10");
	memcpy(pcaInternalAim, &caLocalPlayerAim, sizeof(CAMERA_AIM));
}

void GameSetPlayerCameraMode(uint8_t byteMode, uint8_t bytePlayerNumber)
{
	lastfunc("am11");
	byteCameraMode[bytePlayerNumber] = byteMode;
}

void GameStoreRemotePlayerAim(uint8_t bytePlayerNumber, CAMERA_AIM* pAim)
{
	lastfunc("am12");
	memcpy(&caRemotePlayerAim[bytePlayerNumber], pAim, sizeof(CAMERA_AIM));
}

void GameSetPlayerCameraExtZoom(uint8_t bytePlayerID, float fExtZoom, float fAspectRatio)
{
	lastfunc("am13");
	fCameraExtZoom[bytePlayerID] = fExtZoom;
	fCameraAspectRatio[bytePlayerID] = fAspectRatio;
}

CAMERA_AIM * GameGetRemotePlayerAim(int iPlayer)
{
	return &caRemotePlayerAim[iPlayer];
}