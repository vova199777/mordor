#pragma once

class CBirdPed : public CEntity
{
public:
	CBirdPed(uint16_t usModel, PLAYERID player, bool pos, VECTOR vecPosition, float fRotation);
	~CBirdPed();

	void Destroy();
	void ForceTargetRotation(float fRotation);
	void ApplyAnimation(char* szAnimName, char* szAnimFile, float fDelta, int bLoop, int bLockX, int bLockY, int bFreeze, int uiTime);
	void SetHealth(float fHealth);

	PED_TYPE* m_pPed;
};