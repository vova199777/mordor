//это для создания птички на плече (левое или правое)
//создается пед, с него убирается коллизия и т.д.

#include "../main.h"
#include "game.h"
#include "../net/netgame.h"
#include "../util/armhook.h"
#include "common.h"

#include "birdped.h"

extern CGame* pGame;

CBirdPed::CBirdPed(uint16_t usModel, PLAYERID player, bool pos, VECTOR vecPosition, float fRotation)
{
	m_dwGTAId = 0;
	m_pPed = nullptr;
	m_pEntity = nullptr;

	if (!pGame->IsModelLoaded(usModel)) 
	{
		pGame->RequestModel(usModel);
		pGame->LoadRequestedModels();
	}

	if (!IsPedModel(usModel)) 
	{
		usModel = 0;
	}

	uint32_t actorGTAId = 0;
	ScriptCommand(&create_actor, 22, usModel, vecPosition.X, vecPosition.Y, vecPosition.Z, &actorGTAId);

	m_dwGTAId = actorGTAId;
	m_pPed = GamePool_Ped_GetAt(m_dwGTAId);
	m_pEntity = (ENTITY_TYPE*)m_pPed;

	ForceTargetRotation(fRotation);
	TeleportTo(vecPosition.X, vecPosition.Y, vecPosition.Z);

	SetHealth(100.0f);

	ScriptCommand(&lock_actor, m_dwGTAId, 1);

	ScriptCommand(&set_actor_immunities, m_dwGTAId, 1, 1, 1, 1, 1);
}

CBirdPed::~CBirdPed()
{
	Destroy();
}

extern bool IsValidPed(PED_TYPE* pPed);
void CBirdPed::Destroy()
{
	if (!m_pPed) return;
	if (!GamePool_Ped_GetAt(m_dwGTAId)) return;

	if (IsValidPed(m_pPed)) 
	{
		// CPed::entity.vtable + 0x4 destructor
		((void (*)(PED_TYPE*))(*(void**)(m_pPed->entity.vtable + 0x4)))(m_pPed);
	}

	m_pPed = nullptr;
	m_pEntity = nullptr;
	m_dwGTAId = 0;
}

void CBirdPed::ForceTargetRotation(float fRotation)
{
	if (!m_pPed) return;
	if (!GamePool_Ped_GetAt(m_dwGTAId)) return;

	if (!IsValidGamePed(m_pPed)) 
	{
		return;
	}

	m_pPed->fRotation1 = DegToRad(fRotation);
	m_pPed->fRotation2 = DegToRad(fRotation);

	ScriptCommand(&set_actor_z_angle, m_dwGTAId, fRotation);
}

void CBirdPed::ApplyAnimation(char* szAnimName, char* szAnimFile, float fDelta, int bLoop, int bLockX, int bLockY, int bFreeze, int uiTime)
{
	int iWaitAnimLoad = 0;

	if (!m_pPed) return;
	if (!GamePool_Ped_GetAt(m_dwGTAId)) return;

	if (!strcasecmp(szAnimFile, "SEX")) return;

	if (!pGame->IsAnimationLoaded(szAnimFile))
	{
		pGame->RequestAnimation(szAnimFile);
		while (!pGame->IsAnimationLoaded(szAnimFile))
		{
			usleep(1000);
			iWaitAnimLoad++;
			if (iWaitAnimLoad > 15) return;
		}
	}

	ScriptCommand(&apply_animation, m_dwGTAId, szAnimName, szAnimFile, fDelta, bLoop, bLockX, bLockY, bFreeze, uiTime);
}

void CBirdPed::SetHealth(float fHealth)
{
	if (!m_pPed) return;
	if (!GamePool_Ped_GetAt(m_dwGTAId)) return;

	if (!IsValidGamePed(m_pPed)) 
	{
		return;
	}

	m_pPed->fHealth = fHealth;
}
