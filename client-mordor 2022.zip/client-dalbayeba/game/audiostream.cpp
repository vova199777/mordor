#include "../main.h"
#include <dlfcn.h>
#define BASSDEF(f) (*f)	// define the BASS functions as pointers
#include "audiostream.h"
#include "game.h"
#include "entity.h"

#include "net/netgame.h"

#include "chatwindow.h"

HSTREAM hStream; //dd CAudioStream__hStream

extern CChatWindow *pChatWindow;
extern CNetGame *pNetGame;
extern CGame *pGame;

CAudioStream::CAudioStream()
{
	//initialization...
	GetRadioVolume = -1;

	g_libBASS = dlopen("libbass.so", RTLD_NOW | RTLD_GLOBAL);
	if(g_libBASS == NULL) 
	{
		Log("[libBASS] Error loading libbass.so");
		return;
	} 
	else 
	{
		Log("[libBASS] libbass.so loaded...");
	}
	
	#define LOADBASSFUNCTION(f) *((void**)&f)=dlsym(g_libBASS, BOEV(#f))
	LOADBASSFUNCTION(BASS_SetConfig);
	LOADBASSFUNCTION(BASS_GetConfig);
	LOADBASSFUNCTION(BASS_GetVersion);
	LOADBASSFUNCTION(BASS_ErrorGetCode);
	LOADBASSFUNCTION(BASS_Init);
	LOADBASSFUNCTION(BASS_SetVolume);
	LOADBASSFUNCTION(BASS_GetVolume);	
	LOADBASSFUNCTION(BASS_SetDevice);
	LOADBASSFUNCTION(BASS_GetDevice);
	LOADBASSFUNCTION(BASS_GetDeviceInfo);
	LOADBASSFUNCTION(BASS_Free);
	LOADBASSFUNCTION(BASS_GetInfo);
	LOADBASSFUNCTION(BASS_Update);
	LOADBASSFUNCTION(BASS_GetCPU);
	LOADBASSFUNCTION(BASS_Start);
	LOADBASSFUNCTION(BASS_Stop);
	LOADBASSFUNCTION(BASS_Pause);
	LOADBASSFUNCTION(BASS_PluginLoad);
	LOADBASSFUNCTION(BASS_PluginFree);
	LOADBASSFUNCTION(BASS_PluginGetInfo);
	LOADBASSFUNCTION(BASS_Set3DFactors);
	LOADBASSFUNCTION(BASS_Get3DFactors);
	LOADBASSFUNCTION(BASS_Set3DPosition);
	LOADBASSFUNCTION(BASS_Get3DPosition);
	LOADBASSFUNCTION(BASS_Apply3D);
	LOADBASSFUNCTION(BASS_MusicLoad);
	LOADBASSFUNCTION(BASS_MusicFree);
	LOADBASSFUNCTION(BASS_SampleLoad);
	LOADBASSFUNCTION(BASS_SampleCreate);
	LOADBASSFUNCTION(BASS_SampleFree);
	LOADBASSFUNCTION(BASS_SampleGetInfo);
	LOADBASSFUNCTION(BASS_SampleSetInfo);
	LOADBASSFUNCTION(BASS_SampleGetChannel);
	LOADBASSFUNCTION(BASS_SampleStop);
	LOADBASSFUNCTION(BASS_StreamCreate);
	LOADBASSFUNCTION(BASS_StreamCreateFile);
	LOADBASSFUNCTION(BASS_StreamCreateURL);
	LOADBASSFUNCTION(BASS_StreamCreateFileUser);
	LOADBASSFUNCTION(BASS_StreamFree);
	LOADBASSFUNCTION(BASS_StreamGetFilePosition);
	LOADBASSFUNCTION(BASS_RecordInit);
	LOADBASSFUNCTION(BASS_RecordSetDevice);
	LOADBASSFUNCTION(BASS_RecordFree);
	LOADBASSFUNCTION(BASS_RecordGetInfo);
	LOADBASSFUNCTION(BASS_RecordGetInputName);
	LOADBASSFUNCTION(BASS_RecordSetInput);
	LOADBASSFUNCTION(BASS_RecordGetInput);
	LOADBASSFUNCTION(BASS_RecordStart);
	LOADBASSFUNCTION(BASS_ChannelBytes2Seconds);
	LOADBASSFUNCTION(BASS_ChannelSeconds2Bytes);
	LOADBASSFUNCTION(BASS_ChannelGetDevice);
	LOADBASSFUNCTION(BASS_ChannelSetDevice);
	LOADBASSFUNCTION(BASS_ChannelIsActive);
	LOADBASSFUNCTION(BASS_ChannelGetInfo);
	LOADBASSFUNCTION(BASS_ChannelGetTags);
	LOADBASSFUNCTION(BASS_ChannelPlay);
	LOADBASSFUNCTION(BASS_ChannelStop);
	LOADBASSFUNCTION(BASS_ChannelPause);
	LOADBASSFUNCTION(BASS_ChannelIsSliding);
	LOADBASSFUNCTION(BASS_ChannelSet3DAttributes);
	LOADBASSFUNCTION(BASS_ChannelGet3DAttributes);
	LOADBASSFUNCTION(BASS_ChannelSet3DPosition);
	LOADBASSFUNCTION(BASS_ChannelGet3DPosition);
	LOADBASSFUNCTION(BASS_ChannelGetLength);
	LOADBASSFUNCTION(BASS_ChannelSetPosition);
	LOADBASSFUNCTION(BASS_ChannelGetPosition);
	LOADBASSFUNCTION(BASS_ChannelGetLevel);
	LOADBASSFUNCTION(BASS_ChannelGetData);
	LOADBASSFUNCTION(BASS_ChannelSetSync);
	LOADBASSFUNCTION(BASS_ChannelRemoveSync);
	LOADBASSFUNCTION(BASS_ChannelSetDSP);
	LOADBASSFUNCTION(BASS_ChannelRemoveDSP);
	LOADBASSFUNCTION(BASS_ChannelSetLink);
	LOADBASSFUNCTION(BASS_ChannelRemoveLink);
	LOADBASSFUNCTION(BASS_ChannelSetFX);
	LOADBASSFUNCTION(BASS_ChannelRemoveFX);
	LOADBASSFUNCTION(BASS_FXSetParameters);
	LOADBASSFUNCTION(BASS_FXGetParameters);	
	
	Log("[libBASS] loading settings..");	
	
	Reset(); //attempt to initialize BASS
}

CAudioStream::~CAudioStream() 
{
	//nothing..
}

void CAudioStream::ControlGameRadio()
{
	//in process..
	/*  if ( *(_BYTE *)this )
	  {
		result = CAudioStream__bIsPlaying;
		if ( CAudioStream__bIsPlaying )
		{
		  v2 = *(_DWORD *)CGame__pGame;
		  CAudio__StartRadio(-1);
		  v3 = *(_DWORD *)CGame__pGame;
		  result = v506F70(0xB6BC90, 0, 0);
		}
	  }
	  return result;
	*/  
}

void CAudioStream::DrawInfo()
{
	//in process..
	//information about audio: name, time..
}

char GetUrl[256] = "";

//потоковая функция
void* InitMusic(void *m)
{
	hStream = BASS_StreamCreateURL(GetUrl, 0, 0, NULL, 0);
	
	if(hStream)
		BASS_ChannelPlay(hStream, false);
	else Log("ChannelPlay not start. Error %d",BASS_ErrorGetCode());
	
	//завершаем поток
	pthread_exit(0);
}

//void CAudioStream::Play(char *url, int pos, int a4, int a5, int radius, bool b3d)
void CAudioStream::Play(char *url,bool draw)
{
	lastfunc("as1");
	//in process..
	
	/*Stop(true);
	if(hStream)
	{
		BASS_ChannelStop(hStream);
		hStream = 0;
	}
	if ( GetRadioVolume	> 0 )
	{
		memset(szUrl, 0, 256);
		szUrl[256] = 0;
		strncpy(szUrl, url, 256);
		memset(szInfo, 0, 256);
		szInfo[256] = 0;
		memset(szIcyName, 0, 256);
		szIcyName[256] = 0;
		memset(szIcyUrl, 0, 256);
		szIcyUrl[256] = 0;
		//LODWORD(CAudioStream__position) = pos;
		//LODWORD(dword_1012E698) = a4;
		//LODWORD(dword_1012E69C) = a5;
		//CAudioStream__fRadius = radius;
		//CAudioStream__bIs3d = b3d;
		//if ( !CConfig__GetIntValue("audiomsgoff") )
		//	sub_100678F0(*(int *)CChat__pChat, "Audio stream: %s", CAudioStream__szUrl);
		bNeedsToDestroy = 0;
		//_beginthread((int)CAudioStream__Process, 0, 0);
		Process();
		return 1;
	}
	else
	{
		return 0;
	}*/
	
	Stop(true);
	if ( hStream )
	{
		BASS_ChannelStop(hStream);
		hStream = 0;
	}
	
	if(draw)
	{
		//if(pChatWindow) pChatWindow->AddDebugMessage(BOEV("{88AA62}Audio stream: %s"),url);
	}


	if(pNetGame)
	{
		CVehiclePool *pVehiclePool = pNetGame->GetVehiclePool();
		CPlayerPed *pPlayerPed = pGame->FindPlayerPed();
		
		if(pPlayerPed)
		{
			CVehicle *pVehicle = pVehiclePool->GetAt( pVehiclePool->FindIDFromGtaPtr(pPlayerPed->GetGtaVehicle()));
			if(pVehicle)
			{
				uint32_t AudioEngine = *(uint32_t*)(pack("0x8AD3F0")); // AudioEngine
				// CAudioEngine::StopRadio((int)&AudioEngine, 0, 0);
				(( int (*)(int,int,int))(pack("0x368704")+1))((int)AudioEngine,0,0); //CAudioEngine::StopRadio(tVehicleAudioSettings *, unsigned char)
			}
		}
	}
	
	sprintf(GetUrl, "%s",url);
	
	pthread_t threadm;
	pthread_create(&threadm, 0, InitMusic, 0);
}

void CAudioStream::Process()
{
	lastfunc("as2");
	//in process..
	bool result;

	/*const char *v4; // esi@3
	int v5; // edx@13
	int v6; // ecx@13
	HWND v7; // esi@14
	int v8; // ecx@16
	double v9; // st7@16
	int v10; // edx@16
	int v11; // ecx@16
	int v12; // ecx@20
	unsigned __int64 v13; // rax@20
	int v14; // ecx@20
	int result; // eax@23
	int v16; // [sp+60h] [bp-Ch]@12
	void (__stdcall *v17)(int, int, int, int); // [sp+64h] [bp-8h]@11
	int v18; // [sp+68h] [bp-4h]@1*/
	
	//v18 = a1;
	/*bIsPlaying = 1;
	if ( hStream )
	{
		BASS_ChannelStop(hStream);
		hStream = 0;
	}
	//CAudioStream__hStream = BASS_StreamCreateURL(CAudioStream__szUrl, 0, 9699328, 0, 0, a3, a4, v18);
	hStream = BASS_StreamCreateURL(szUrl, 0, 0, NULL, 0);
	BASS_ChannelPlay(hStream, false);
	memset(szIcyName, 0, 256);
	szIcyName[256] = 0;
	memset(szIcyUrl, 0, 256);
	szIcyUrl[256] = 0;*/
	/*v4 = (const char *)BASS_ChannelGetTags(CAudioStream__hStream, 4);
	if ( v4 || (v4 = (const char *)BASS_ChannelGetTags(CAudioStream__hStream, 3)) != 0 )
	{
		for ( ; *v4; v4 += strlen(v4) + 1 )
		{
		if ( !_strnicmp(v4, "icy-name:", 9u) )
			_snprintf(CAudioStream__szIcyName, 0x100u, "%s", v4 + 9);
		if ( !_strnicmp(v4, "icy-url:", 8u) )
			_snprintf(CAudioStream__szIcyUrl, 0x100u, "%s", v4 + 8);
		}
	}
	CAudioStream__ConstructInfo();*/
	//v17 = CAudioStream__SyncProc;
	
	//BASS_ChannelSetSync(hStream, BASS_SYNC_META, 0, 0);
	//BASS_ChannelSetSync(hStream, BASS_SYNC_OGG_CHANGE, 0, 0);
	
	/*if ( !CAudioStream__bNeedsToDestroy )
	{
		v16 = a2;
		do
		{
			BASS_StreamGetFilePosition(CAudioStream__hStream, 4, v16, v17);
			if ( CGame__IsMenuVisible() || (v7 = vC97C1C, GetForegroundWindow() != v7) )
			{
				BASS_SetConfig(v6, v5, 5, 0);
			}
			else if ( CAudioStream__bIs3d )
			{
				v8 = *(_DWORD *)CGame__pGame;
				v9 = CAudio__GetRadioVolume() * 8000.0;
				if ( CGame__GetPlayerPed(CGame__pGame)
				&& (CEntity__GetDistanceToPoint(CAudioStream__position, dword_1012E698, dword_1012E69C),
					v9 < *(float *)&CAudioStream__fRadius) )
				{
				BASS_SetConfig(
					v11,
					(unsigned __int64)((1.0 - v9 / *(float *)&CAudioStream__fRadius) * (double)(signed int)(unsigned __int64)v9) >> 32,
					5,
					(unsigned __int64)((1.0 - v9 / *(float *)&CAudioStream__fRadius) * (double)(signed int)(unsigned __int64)v9));
				}
				else
				{
				BASS_SetConfig(v11, v10, 5, 0);
				}
			}
			else
			{
				v12 = *(_DWORD *)CGame__pGame;
				v13 = (unsigned __int64)(CAudio__GetRadioVolume() * 7000.0);
				BASS_SetConfig(v14, SHIDWORD(v13), BASS_CONFIG_GVOL_STREAM, v13);
			}
			Sleep(20u);
		}
		while ( !CAudioStream__bNeedsToDestroy );
	}*/
	//result = BASS_ChannelStop(hStream);
	//hStream = 0;
	//bIsPlaying = 0;
	//return result;
	
	if(hStream)
	{
		GetRadioVolume = *(uint8_t*)(pack("0x63E504"));
		if(GetRadioVolume > 0)
		{
			uint64_t loudsound = GetRadioVolume * 80;
			BASS_SetConfig(BASS_CONFIG_GVOL_STREAM, loudsound);
		}
		else if(GetRadioVolume == 0)
		{
			BASS_SetConfig(BASS_CONFIG_GVOL_STREAM, 0);
		}

		if(pNetGame)
		{
			CVehiclePool *pVehiclePool = pNetGame->GetVehiclePool();
			CPlayerPed *pPlayerPed = pGame->FindPlayerPed();
			
			if(pPlayerPed)
			{
				CVehicle *pVehicle = pVehiclePool->GetAt( pVehiclePool->FindIDFromGtaPtr(pPlayerPed->GetGtaVehicle()));
				if(pVehicle)
				{
					uint32_t AudioEngine = *(uint32_t*)(pack("0x8AD3F0")); // AudioEngine
					// CAudioEngine::StopRadio((int)&AudioEngine, 0, 0);
					(( int (*)(int,int,int))(pack("0x368704")+1))((int)AudioEngine,0,0); //CAudioEngine::StopRadio(tVehicleAudioSettings *, unsigned char)
				}
			}
		}		
	}
}

void CAudioStream::Reset()
{
	lastfunc("as3");
	//in process..
	
	/*hStream = 0;
	BASS_Free();
	//if ( BASS_Init(-1, 44100, 0, 0, 0) ) //maybe work, dont check
	if (BASS_Init(-1, 44100, BASS_DEVICE_3D, 0, NULL))	
	{
		//BASS_SetConfigPtr(16, (int)aSaMp0_3); //wtf?
		
		//v2 = *(_DWORD *)CGame__pGame;
		
		//v3 = (unsigned __int64)(CAudio__GetRadioVolume() * 7000.0);
		//BASS_SetConfig(v4, HIDWORD(v3), 5, v3);
		float GVOL_STREAM = GetRadioVolume * 100.0;
		BASS_SetConfig(BASS_CONFIG_GVOL_STREAM, GVOL_STREAM);
		BASS_SetConfig(BASS_CONFIG_NET_PLAYLIST, 1);
		BASS_SetConfig(BASS_CONFIG_NET_TIMEOUT, 10000); //ms
		//if ( !(unsigned __int8)CConfig__DoesExist("audioproxyoff") )
		//	CConfig__WriteIntValue((char *)CConfig__pConfig, "audioproxyoff", 0, 0);
		//if ( CConfig__GetIntValue("audioproxyoff") )
		//	BASS_SetConfigPtr(17, 0);
		//BASS_SetEAXParameters(-1, 0, 0xBF800000, 0xBF800000);
		//*v1 = 1;
		return 1;
	}
	else
	{
		return 0;
	}*/
	
	hStream = 0;
	//BASS_Free(); //this results in a jni error
	
	if (BASS_Init(-1, 44100, BASS_DEVICE_3D, 0, 0) != true) 
	{
		Log("[libBASS] libbass.so is not initialized, error: %i", BASS_ErrorGetCode());
	}
	else
	{
		Log("[libBASS] libbass.so successfully initialized");
	}	
	
	//BASS_SetConfigPtr(BASS_CONFIG_NET_AGENT, "SA-MP/0.3"); //dont work, i do not know
	
	//BASS_SetConfig(10, 3); //old config
	//BASS_SetConfig(5, 10000); //old config
	//float GVOL_STREAM = GetRadioVolume * 100.0;
	//BASS_SetConfig(BASS_CONFIG_GVOL_STREAM, GVOL_STREAM); //this should be used already in the game
	BASS_SetConfig(BASS_CONFIG_GVOL_STREAM, 5000);
	BASS_SetConfig(BASS_CONFIG_NET_PLAYLIST, 1);
	BASS_SetConfig(BASS_CONFIG_NET_TIMEOUT, 10000); //ms
}

void CAudioStream::Stop(bool a2)
{
	lastfunc("as4");
	//in process..
	/*int result;
	if ( *(_BYTE *)this && CAudioStream__bIsPlaying )
	{
		CAudioStream__bNeedsToDestroy = 1;
		if ( a2 )
		{
			while ( CAudioStream__bIsPlaying )
				Sleep(2u);
		}
		BASS_StreamFree(CAudioStream__hStream);
		CAudioStream__hStream = 0;
		result = 1;
	}
	else
	{
		result = 0;
	}
	return result;	
	*/
	
	/*if(bIsPlaying)
	{
		bNeedsToDestroy = 1;
		if(a2)
		{
			//cycle..
		}
		BASS_StreamFree(hStream);
		hStream = 0;
		return 1;
	}
	else
	{
		return 0;
	}*/
	//bIsPlaying = 0;
	
	if(pNetGame)
	{
		CVehiclePool *pVehiclePool = pNetGame->GetVehiclePool();
		CPlayerPed *pPlayerPed = pGame->FindPlayerPed();
		
		if(pPlayerPed)
		{
			CVehicle *pVehicle = pVehiclePool->GetAt( pVehiclePool->FindIDFromGtaPtr(pPlayerPed->GetGtaVehicle()));
			if(pVehicle)
			{
				uint32_t AudioEngine = *(uint32_t*)(pack("0x8AD3F0")); // AudioEngine
				uint32_t GetLastPlayRadio = *(uint32_t*)(pack("0x8AD3F0"));
				// 3BD2D0 ; _DWORD __fastcall CAudioEngine::StartRadio(CAudioEngine *__hidden this, signed __int8, signed __int8)
				// CAudioEngine::StartRadio((CAudioEngine *)&AudioEngine, dword_6E05BC, 0);
				(( int (*)(int,int,int))(pack("0x368C58")+1))((int)AudioEngine,GetLastPlayRadio,0);
				// 3BD360 ; _DWORD __fastcall CAudioEngine::RetuneRadio(CAudioEngine *__hidden this, signed __int8)
			}
		}
	}
	
	if(hStream)
	{
		BASS_StreamFree(hStream);
		hStream = 0;
	}
}
