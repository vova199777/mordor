#pragma once

#define MAX_BIRDS 1000
#define INVALID_ACTOR_ID 0xFFFF

class CBirdPool
{
private:
	bool m_bBirdSlotState[MAX_BIRDS];
	CBirdPed* m_pBird[MAX_BIRDS];

public:
	CBirdPool();
	~CBirdPool();

	bool Spawn(uint16_t BirdId, int iSkin, PLAYERID player, bool pos, VECTOR vecPos, float fRotation);
	bool Delete(uint16_t BirdId);
	void Process();

	bool IsValidBirdId(uint16_t BirdId) 
	{
		
		if (BirdId >= 0 && BirdId < MAX_BIRDS) 
		{
			return true;
		}
		return false;
	};

	bool GetSlotState(uint16_t BirdId) 
	{
		
		if (IsValidBirdId(BirdId)) 
		{
			return m_bBirdSlotState[BirdId];
		}
		return false;
	};

	CBirdPed* GetAt(uint16_t BirdId) 
	{
		
		if (!GetSlotState(BirdId)) 
		{
			return nullptr;
		}
		return m_pBird[BirdId];
	};
};