#include "main.h"
#include "game/game.h"
#include "netgame.h"
#include "chatwindow.h"

#include "../chatbubble.h"

#include "game/world.h"
#include "../util/CJavaWrapper.h"

//#include "../game/removebuilding.h"

#include <string.h>
#include <dirent.h>
#include <time.h>
#include <stdio.h>
#include <sys/stat.h>
#include <stdlib.h>

#include "settings.h" 

#define WEAPONTYPE_PISTOL_SKILL 69
#define WEAPONTYPE_PISTOL_SILENCED_SKILL 70
#define WEAPONTYPE_DESERT_EAGLE_SKILL 71
#define WEAPONTYPE_SHOTGUN_SKILL 72
#define WEAPONTYPE_SAWNOFF_SHOTGUN_SKILL 73
#define WEAPONTYPE_SPAS12_SHOTGUN_SKILL 74
#define WEAPONTYPE_MICRO_UZI_SKILL 75
#define WEAPONTYPE_MP5_SKILL 76
#define WEAPONTYPE_AK47_SKILL 77
#define WEAPONTYPE_M4_SKILL 78
#define WEAPONTYPE_SNIPERRIFLE_SKILL 79

extern CSettings *pSettings;
extern CGame *pGame;
extern CNetGame *pNetGame;
extern CChatWindow *pChatWindow;
extern CChatBubble *pBubble;
int bubbleCount = 0;

//extern CRemoveBuilding *pRemoveBuilding;

extern CWorld *pWorld; 

void ScrDisplayGameText(RPCParameters *rpcParams)
{
	Log("RPC: ScrDisplayGameText");
	lastfunc("srp1");
	unsigned char * Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);
	char szMessage[512];
	int iType;
	int iTime;
	int iLength;

	bsData.Read(iType);
	bsData.Read(iTime);
	bsData.Read(iLength);

	if(iLength > 512) return;

	bsData.Read(szMessage,iLength);
	szMessage[iLength] = '\0';

	pGame->DisplayGameText(szMessage, iTime, iType);
}

void ScrSetGravity(RPCParameters *rpcParams)
{
	Log("RPC: ScrSetGravity");
	lastfunc("srp2");
	unsigned char * Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	float fGravity;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);
	bsData.Read(fGravity);

	pGame->SetGravity(fGravity);
}

void ScrForceSpawnSelection(RPCParameters *rpcParams)
{
	Log("RPC: ScrForceSpawnSelection");
	lastfunc("srp3");
	pNetGame->GetPlayerPool()->GetLocalPlayer()->ReturnToClassSelection();
}

void ScrSetPlayerPos(RPCParameters *rpcParams)
{
	Log("RPC: ScrSetPlayerPos");
	lastfunc("srp4");
	unsigned char * Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);

	CLocalPlayer *pLocalPlayer = pNetGame->GetPlayerPool()->GetLocalPlayer();

	VECTOR vecPos;
	bsData.Read(vecPos.X);
	bsData.Read(vecPos.Y);
	bsData.Read(vecPos.Z);

	if(pLocalPlayer) pLocalPlayer->GetPlayerPed()->TeleportTo(vecPos.X,vecPos.Y,vecPos.Z);
}

void ScrSetCameraPos(RPCParameters *rpcParams)
{
	Log("RPC: ScrSetCameraPos");
	lastfunc("srp5");
	unsigned char * Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);
	VECTOR vecPos;
	bsData.Read(vecPos.X);
	bsData.Read(vecPos.Y);
	bsData.Read(vecPos.Z);
	pGame->GetCamera()->SetPosition(vecPos.X, vecPos.Y, vecPos.Z, 0.0f, 0.0f, 0.0f);
}

void ScrSetCameraLookAt(RPCParameters *rpcParams)
{
	Log("RPC: ScrSetCameraLookAt");
	lastfunc("srp6");
	unsigned char * Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);
	VECTOR vecPos;
	bsData.Read(vecPos.X);
	bsData.Read(vecPos.Y);
	bsData.Read(vecPos.Z);
	pGame->GetCamera()->LookAtPoint(vecPos.X,vecPos.Y,vecPos.Z,2);	
}

void ScrSetPlayerFacingAngle(RPCParameters *rpcParams)
{
	Log("RPC: ScrSetPlayerFacingAngle");
	lastfunc("srp7");
	unsigned char * Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	float fAngle;
	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);
	bsData.Read(fAngle);
	pGame->FindPlayerPed()->ForceTargetRotation(fAngle);
}

void ScrSetFightingStyle(RPCParameters *rpcParams)
{
	Log("RPC: ScrSetFightingStyle");
	lastfunc("srp8");
	unsigned char * Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	PLAYERID playerId;
	uint8_t byteFightingStyle = 0;
	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);
	bsData.Read(playerId);
	bsData.Read(byteFightingStyle);
	
	CPlayerPool *pPlayerPool = pNetGame->GetPlayerPool();
	CPlayerPed *pPlayerPed = nullptr;

	if(pPlayerPool)
	{
		if(playerId == pPlayerPool->GetLocalPlayerID())
			pPlayerPed = pPlayerPool->GetLocalPlayer()->GetPlayerPed();
		else if(pPlayerPool->GetSlotState(playerId)) 
			pPlayerPed = pPlayerPool->GetAt(playerId)->GetPlayerPed();

		if(pPlayerPed)				
				pPlayerPed->SetFightingStyle(byteFightingStyle);
	}
}

void ScrSetPlayerSkin(RPCParameters *rpcParams)
{
	Log("RPC: ScrSetPlayerSkin");
	lastfunc("srp9");
	unsigned char * Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	int iPlayerID;
	unsigned int uiSkin;
	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);
	bsData.Read(iPlayerID);
	bsData.Read(uiSkin);

	CPlayerPool *pPlayerPool = pNetGame->GetPlayerPool();
	if(iPlayerID == pPlayerPool->GetLocalPlayerID())
		pPlayerPool->GetLocalPlayer()->GetPlayerPed()->SetModelIndex(uiSkin);
	else
	{
		if(pPlayerPool->GetSlotState(iPlayerID) && pPlayerPool->GetAt(iPlayerID)->GetPlayerPed())
			pPlayerPool->GetAt(iPlayerID)->GetPlayerPed()->SetModelIndex(uiSkin);
	}
}

void ScrApplyPlayerAnimation(RPCParameters *rpcParams)
{
	//Log("RPC: ScrApplyPlayerAnimation");
	lastfunc("srp10");
	unsigned char * Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	PLAYERID playerId;
	uint8_t byteAnimLibLen;
	uint8_t byteAnimNameLen;
	char szAnimLib[256];
	char szAnimName[256];
	float fS;
	bool opt1, opt2, opt3, opt4;
	int opt5;
	CPlayerPool *pPlayerPool = nullptr;
	CPlayerPed *pPlayerPed = nullptr;

	memset(szAnimLib, 0, 256);
	memset(szAnimName, 0, 256);

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);
	bsData.Read(playerId);
	bsData.Read(byteAnimLibLen);
	bsData.Read(szAnimLib, byteAnimLibLen);
	bsData.Read(byteAnimNameLen);
	bsData.Read(szAnimName, byteAnimNameLen);
	bsData.Read(fS);
	bsData.Read(opt1);
	bsData.Read(opt2);
	bsData.Read(opt3);
	bsData.Read(opt4);
	bsData.Read(opt5);

	szAnimLib[byteAnimLibLen] = '\0';
	szAnimName[byteAnimNameLen] = '\0';

	pPlayerPool = pNetGame->GetPlayerPool();

	if(pPlayerPool)
	{
		if(pPlayerPool->GetLocalPlayerID() == playerId)
			pPlayerPed = pPlayerPool->GetLocalPlayer()->GetPlayerPed();
		else if(pPlayerPool->GetSlotState(playerId))
			pPlayerPed = pPlayerPool->GetAt(playerId)->GetPlayerPed();

		if(pPlayerPed)
			pPlayerPed->ApplyAnimation(szAnimName, szAnimLib, fS, (int)opt1, (int)opt2, (int)opt3, (int)opt4, (int)opt5);
	}
}

void ScrClearPlayerAnimations(RPCParameters *rpcParams)
{
	//Log("RPC: ScrClearPlayerAnimations");
	lastfunc("srp11");
	unsigned char* Data = reinterpret_cast<unsigned char*>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;
	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);

	PLAYERID playerId;
	bsData.Read(playerId);
	MATRIX4X4 mat;

	CPlayerPool *pPlayerPool=NULL;
	CPlayerPed *pPlayerPed=NULL;

	pPlayerPool = pNetGame->GetPlayerPool();

	if(pPlayerPool) {
		// Get the CPlayerPed for this player
		if(playerId == pPlayerPool->GetLocalPlayerID()) 
		{
			pPlayerPed = pPlayerPool->GetLocalPlayer()->GetPlayerPed();
		}
		else 
		{
			if(pPlayerPool->GetSlotState(playerId))
				pPlayerPed = pPlayerPool->GetAt(playerId)->GetPlayerPed();
		}
		
		if(pPlayerPed) 
		{
			pPlayerPed->GetMatrix(&mat);
			pPlayerPed->TeleportTo(mat.pos.X, mat.pos.Y, mat.pos.Z);
		}
	}
}

void ScrSetSpawnInfo(RPCParameters *rpcParams)
{
	Log("RPC: ScrSetSpawnInfo");
	lastfunc("srp12");
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	PLAYER_SPAWN_INFO SpawnInfo;

	RakNet::BitStream bsData(Data, (iBitLength/8)+1, false);

	CPlayerPool *pPlayerPool = pNetGame->GetPlayerPool();

	bsData.Read((char*)&SpawnInfo, sizeof(PLAYER_SPAWN_INFO));

	pPlayerPool->GetLocalPlayer()->SetSpawnInfo(&SpawnInfo);
}

void ScrCreateExplosion(RPCParameters *rpcParams)
{
	Log("RPC: ScrCreateExplosion");
	lastfunc("srp13");
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);
	float X, Y, Z, Radius;
	int   iType;

	bsData.Read(X);
	bsData.Read(Y);
	bsData.Read(Z);
	bsData.Read(iType);
	bsData.Read(Radius);

	ScriptCommand(&create_explosion_with_radius, X, Y, Z, iType, Radius);
}

void ScrSetPlayerHealth(RPCParameters *rpcParams)
{
	//Log("RPC: ScrSetPlayerHealth");
	lastfunc("srp14");
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	CLocalPlayer *pLocalPlayer = pNetGame->GetPlayerPool()->GetLocalPlayer();
	float fHealth;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);
	bsData.Read(fHealth);

	pLocalPlayer->GetPlayerPed()->SetHealth(fHealth);
}

void ScrSetPlayerArmour(RPCParameters *rpcParams)
{
	//Log("RPC: ScrSetPlayerArmour");
	lastfunc("srp15");

	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	CLocalPlayer *pLocalPlayer = pNetGame->GetPlayerPool()->GetLocalPlayer();
	float fHealth;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);
	bsData.Read(fHealth);

	pLocalPlayer->GetPlayerPed()->SetArmour(fHealth);
}

void ScrSetPlayerColor(RPCParameters *rpcParams)
{
	//Log("RPC: ScrSetPlayerColor");
	lastfunc("srp16");

	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);
	CPlayerPool *pPlayerPool = pNetGame->GetPlayerPool();
	PLAYERID playerId;
	uint32_t dwColor;

	bsData.Read(playerId);
	bsData.Read(dwColor);

	//Log("Color: 0x%X", dwColor);

	if(playerId == pPlayerPool->GetLocalPlayerID()) 
	{
		pPlayerPool->GetLocalPlayer()->SetPlayerColor(dwColor);
	} 
	else 
	{
		CRemotePlayer *pPlayer = pPlayerPool->GetAt(playerId);
		if(pPlayer)	pPlayer->SetPlayerColor(dwColor);
	}
}

void ScrSetPlayerName(RPCParameters *rpcParams)
{
	Log("RPC: ScrSetPlayerName");
	lastfunc("srp17");

	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	PLAYERID playerId;
	uint8_t byteNickLen;
	char szNewName[MAX_PLAYER_NAME+1];
	uint8_t byteSuccess;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);

	CPlayerPool *pPlayerPool = pNetGame->GetPlayerPool();

	bsData.Read(playerId);
	bsData.Read(byteNickLen);

	if(byteNickLen > MAX_PLAYER_NAME) return;

	bsData.Read(szNewName, byteNickLen);
	bsData.Read(byteSuccess);

	szNewName[byteNickLen] = '\0';

	//Log("byteSuccess = %d", byteSuccess);
	if (byteSuccess == 1) pPlayerPool->SetPlayerName(playerId, szNewName);
	
	// Extra addition which we need to do if this is the local player;
	if( pPlayerPool->GetLocalPlayerID() == playerId )
		pPlayerPool->SetLocalPlayerName( szNewName );
}

void ScrSetPlayerPosFindZ(RPCParameters *rpcParams)
{
	Log("RPC: ScrSetPlayerPosFindZ");
	lastfunc("srp18");

	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);

	CLocalPlayer *pLocalPlayer = pNetGame->GetPlayerPool()->GetLocalPlayer();

	VECTOR vecPos;

	bsData.Read(vecPos.X);
	bsData.Read(vecPos.Y);
	bsData.Read(vecPos.Z);

	vecPos.Z = pGame->FindGroundZForCoord(vecPos.X, vecPos.Y, vecPos.Z);
	vecPos.Z += 1.5f;

	pLocalPlayer->GetPlayerPed()->TeleportTo(vecPos.X, vecPos.Y, vecPos.Z);
}

void ScrSetPlayerInterior(RPCParameters *rpcParams)
{
	Log("RPC: ScrSetPlayerInterior");
	lastfunc("srp19");

	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;


	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);
	uint8_t byteInterior;
	bsData.Read(byteInterior);

	pGame->FindPlayerPed()->SetInterior(byteInterior);	
}

void ScrSetMapIcon(RPCParameters *rpcParams)
{
	Log("RPC: ScrSetMapIcon");
	lastfunc("srp20");
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);

	uint8_t byteIndex;
	uint8_t byteIcon;
	uint32_t dwColor;
	float fPos[3];
	uint8_t byteStyle;

	bsData.Read(byteIndex);
	bsData.Read(fPos[0]);
	bsData.Read(fPos[1]);
	bsData.Read(fPos[2]);
	bsData.Read(byteIcon);
	bsData.Read(dwColor);
	bsData.Read(byteStyle);

	pNetGame->SetMapIcon(byteIndex, fPos[0], fPos[1], fPos[2], byteIcon, dwColor, byteStyle);
}

void ScrDisableMapIcon(RPCParameters *rpcParams)
{
	Log("RPC: ScrDisableMapIcon");
	lastfunc("srp21");
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);

	uint8_t byteIndex;

	bsData.Read(byteIndex);

	pNetGame->DisableMapIcon(byteIndex);
}

void ScrSetCameraBehindPlayer(RPCParameters *rpcParams)
{
	Log("RPC: ScrSetCameraBehindPlayer");
	lastfunc("srp22");

	pGame->GetCamera()->SetBehindPlayer();	
}

void ScrSetPlayerSpecialAction(RPCParameters *rpcParams)
{
	Log("RPC: ScrSetPlayerSpecialAction");
	lastfunc("srp23");
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);

	uint8_t byteSpecialAction;
	bsData.Read(byteSpecialAction);

	CPlayerPool *pPlayerPool = pNetGame->GetPlayerPool();
	if(pPlayerPool) pPlayerPool->GetLocalPlayer()->ApplySpecialAction(byteSpecialAction);
}

void ScrTogglePlayerSpectating(RPCParameters *rpcParams)
{
	Log("RPC: ScrTogglePlayerSpectating");
	lastfunc("srp24");
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	CPlayerPool *pPlayerPool = pNetGame->GetPlayerPool();
	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);
	uint8_t bToggle;
	bsData.Read(bToggle);
	pPlayerPool->GetLocalPlayer()->ToggleSpectating(bToggle);
}

void ScrSetPlayerSpectating(RPCParameters *rpcParams)
{
	Log("RPC: ScrSetPlayerSpectating");
	lastfunc("srp25");
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	PLAYERID playerId;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);
	bsData.Read(playerId);
	CPlayerPool *pPlayerPool = pNetGame->GetPlayerPool();
	if (pPlayerPool->GetSlotState(playerId))
		pPlayerPool->GetAt(playerId)->SetState(PLAYER_STATE_SPECTATING);
}

#define SPECTATE_TYPE_NORMAL	1
#define SPECTATE_TYPE_FIXED		2
#define SPECTATE_TYPE_SIDE		3

void ScrPlayerSpectatePlayer(RPCParameters *rpcParams)
{
	Log("RPC: ScrPlayerSpectatePlayer");
	lastfunc("srp26");
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);
	
	PLAYERID playerId;
    uint8_t byteMode;
	
	bsData.Read(playerId);
	bsData.Read(byteMode);

	switch (byteMode) 
	{
		case SPECTATE_TYPE_FIXED:
			byteMode = 15;
			break;
		case SPECTATE_TYPE_SIDE:
			byteMode = 14;
			break;
		default:
			byteMode = 4;
	}

	CLocalPlayer *pLocalPlayer = pNetGame->GetPlayerPool()->GetLocalPlayer();
	pLocalPlayer->m_byteSpectateMode = byteMode;
	pLocalPlayer->SpectatePlayer(playerId);
}

void ScrPlayerSpectateVehicle(RPCParameters *rpcParams)
{
	Log("RPC: ScrPlayerSpectateVehicle");
	lastfunc("srp27");
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);

	VEHICLEID VehicleID;
	uint8_t byteMode;

	bsData.Read(VehicleID);
	bsData.Read(byteMode);

	switch (byteMode) 
	{
		case SPECTATE_TYPE_FIXED:
			byteMode = 15;
			break;
		case SPECTATE_TYPE_SIDE:
			byteMode = 14;
			break;
		default:
			byteMode = 3;
	}

	CLocalPlayer *pLocalPlayer = pNetGame->GetPlayerPool()->GetLocalPlayer();
	pLocalPlayer->m_byteSpectateMode = byteMode;
	pLocalPlayer->SpectateVehicle(VehicleID);
}

void ScrPutPlayerInVehicle(RPCParameters *rpcParams)
{
	Log("RPC: ScrPutPlayerInVehicle");
	lastfunc("srp28");
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);
	VEHICLEID vehicleid;
	uint8_t seatid;
	bsData.Read(vehicleid);
	bsData.Read(seatid);

	CPlayerPool *pPlayerPool = pNetGame->GetPlayerPool();
	int iVehicleIndex = pNetGame->GetVehiclePool()->FindGtaIDFromID(vehicleid);
	CVehicle *pVehicle = pNetGame->GetVehiclePool()->GetAt(vehicleid);

	if(iVehicleIndex && pVehicle)
		 pGame->FindPlayerPed()->PutDirectlyInVehicle(iVehicleIndex, seatid);
}

void ScrVehicleParams(RPCParameters *rpcParams)
{
	Log("RPC: ScrSetVehicleParams");
	lastfunc("srp29");
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);
	VEHICLEID VehicleID;
	uint8_t byteObjectiveVehicle;
	uint8_t byteDoorsLocked;

	bsData.Read(VehicleID);
	bsData.Read(byteObjectiveVehicle);
	bsData.Read(byteDoorsLocked);

	CVehiclePool *pVehiclePool = pNetGame->GetVehiclePool();
	pVehiclePool->AssignSpecialParamsToVehicle(VehicleID,byteObjectiveVehicle,byteDoorsLocked);
}

void ScrVehicleParamsEx(RPCParameters *rpcParams)
{
	//Log("RPC: ScrVehicleParamsEx");
	lastfunc("srp30");
	unsigned char * Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);

	VEHICLEID VehicleId;
	uint8_t engine, lights, alarm, doors, bonnet, boot, objective;
	bsData.Read(VehicleId);
	bsData.Read(engine);
	bsData.Read(lights);
	bsData.Read(alarm);
	bsData.Read(doors);
	bsData.Read(bonnet);
	bsData.Read(boot);
	bsData.Read(objective);
	
	if(pNetGame && pNetGame->GetVehiclePool())
	{
		if(pNetGame->GetVehiclePool()->GetSlotState(VehicleId))
		{
			// doors
			pNetGame->GetVehiclePool()->GetAt(VehicleId)->SetDoorState(doors);
			// engine
			pNetGame->GetVehiclePool()->GetAt(VehicleId)->SetEngineState(engine);
			
			pNetGame->GetVehiclePool()->GetAt(VehicleId)->SetLightState(lights);
			
			//0	Bonnet/Hood
			//1	Boot
			//2	Front left door (driver)
			//3	Front right door (passenger)
			//4	Rear left door
			//5	Rear right door
			
			pNetGame->GetVehiclePool()->GetAt(VehicleId)->SetBonnetState(bonnet);
			pNetGame->GetVehiclePool()->GetAt(VehicleId)->SetBootState(boot);
		}
	}
}

void ScrHaveSomeMoney(RPCParameters *rpcParams)
{
	Log("RPC: ScrHaveSomeMoney");
	lastfunc("srp31");
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	int iAmmount;
	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);
	bsData.Read(iAmmount);
	pGame->AddToLocalMoney(iAmmount);
	g_pJavaWrapper->SetInterfaceHudMoney(iAmmount);
}

void ScrResetMoney(RPCParameters *rpcParams)
{
	Log("RPC: ScrResetMoney");
	lastfunc("srp32");
	pGame->ResetLocalMoney();
	g_pJavaWrapper->SetInterfaceHudMoney(0);
}

void ScrLinkVehicle(RPCParameters *rpcParams)
{
	Log("RPC: ScrLinkVehicle");
	lastfunc("srp33");
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);
	VEHICLEID VehicleID;
	uint8_t byteInterior;

	bsData.Read(VehicleID);
	bsData.Read(byteInterior);

	CVehiclePool *pVehiclePool = pNetGame->GetVehiclePool();
	pVehiclePool->LinkToInterior(VehicleID, (int)byteInterior);
}

void ScrRemovePlayerFromVehicle(RPCParameters *rpcParams)
{
	Log("RPC: ScrRemovePlayerFromVehicle");
	lastfunc("srp34");
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);

	CPlayerPool *pPlayerPool = pNetGame->GetPlayerPool();
	pPlayerPool->GetLocalPlayer()->GetPlayerPed()->ExitCurrentVehicle();
}

void ScrSetVehicleHealth(RPCParameters *rpcParams)
{
	Log("RPC: ScrSetVehicleHealth");
	lastfunc("srp35");
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);
	float fHealth;
	VEHICLEID VehicleID;

	bsData.Read(VehicleID);
	bsData.Read(fHealth);

	if(pNetGame->GetVehiclePool()->GetSlotState(VehicleID))
		pNetGame->GetVehiclePool()->GetAt(VehicleID)->SetHealth(fHealth);
}

void ScrSetVehiclePos(RPCParameters *rpcParams)
{
	Log("RPC: ScrSetVehiclePos");
	lastfunc("srp36");
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);
	VEHICLEID VehicleId;
	float fX, fY, fZ;
	bsData.Read(VehicleId);
	bsData.Read(fX);
	bsData.Read(fY);
	bsData.Read(fZ);

	if(pNetGame && pNetGame->GetVehiclePool())
	{
		if(pNetGame->GetVehiclePool()->GetSlotState(VehicleId))
			pNetGame->GetVehiclePool()->GetAt(VehicleId)->TeleportTo(fX, fY, fZ);
	}
}

void ScrSetVehicleVelocity(RPCParameters *rpcParams)
{
	Log("RPC: ScrSetVehicleVelocity");
	lastfunc("srp37");
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);

	uint8_t turn = false;
	VECTOR vecMoveSpeed;
	bsData.Read(turn);
	bsData.Read(vecMoveSpeed.X);
	bsData.Read(vecMoveSpeed.Y);
	bsData.Read(vecMoveSpeed.Z);
	Log("X: %f, Y: %f, Z: %f", vecMoveSpeed.X, vecMoveSpeed.Y, vecMoveSpeed.Z);

	CVehiclePool *pVehiclePool = pNetGame->GetVehiclePool();
	CPlayerPed *pPlayerPed = pGame->FindPlayerPed();

	if(pPlayerPed)
	{
		CVehicle *pVehicle = pVehiclePool->GetAt( pVehiclePool->FindIDFromGtaPtr(pPlayerPed->GetGtaVehicle()));
		if(pVehicle)
			pVehicle->SetMoveSpeedVector(vecMoveSpeed);
	}
}

void ScrNumberPlate(RPCParameters *rpcParams)
{
	//Log("RPC: ScrNumberPlate");
	lastfunc("srp38");
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);

	VEHICLEID VehicleID;
	char len;
	char szNumberPlate[32+1];

	bsData.Read(VehicleID);
	bsData.Read(len);
	bsData.Read(szNumberPlate, len);
	szNumberPlate[len] = '\0';

	//Log("plate: %s", szNumberPlate);
}

void ScrInterpolateCamera(RPCParameters *rpcParams)
{
	Log("ScrInterpolateCamera");
	lastfunc("srp39");
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);
	bool bSetPos = true;
	VECTOR vecFrom, vecDest;
	int time;
	uint8_t mode;

	bsData.Read(bSetPos);
	bsData.Read(vecFrom.X);
	bsData.Read(vecFrom.Y);
	bsData.Read(vecFrom.Z);
	bsData.Read(vecDest.X);
	bsData.Read(vecDest.Y);
	bsData.Read(vecDest.Z);
	bsData.Read(time);
	bsData.Read(mode);

	if(mode < 1 || mode > 2)
		mode = 2;

	if(time > 0)
	{
		// pNetGame->GetPlayerPool()->GetLocalPlayer()->m_b.. = true;
		if(bSetPos)
		{
			pGame->GetCamera()->InterpolateCameraPos(&vecFrom, &vecDest, time, mode);
		}
		else
			pGame->GetCamera()->InterpolateCameraLookAt(&vecFrom, &vecDest, time, mode);
	}
}

void ScrAddGangZone(RPCParameters *rpcParams)
{
	//Log("RPC: ScrAddGangZone");
	lastfunc("srp40");
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);

	CGangZonePool* pGangZonePool = pNetGame->GetGangZonePool();
	if (pGangZonePool)
	{
		uint16_t wZoneID;
		float minx, miny, maxx, maxy;
		uint32_t dwColor;
		bsData.Read(wZoneID);
		bsData.Read(minx);
		bsData.Read(miny);
		bsData.Read(maxx);
		bsData.Read(maxy);
		bsData.Read(dwColor);
		pGangZonePool->New(wZoneID, minx, miny, maxx, maxy, dwColor);
	}
}

void ScrRemoveGangZone(RPCParameters *rpcParams)
{
	Log("RPC: ScrRemoveGangZone");
	lastfunc("srp41");
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);
	CGangZonePool* pGangZonePool = pNetGame->GetGangZonePool();

	if (pGangZonePool)
	{
		uint16_t wZoneID;
		bsData.Read(wZoneID);
		pGangZonePool->Delete(wZoneID);
	}
}

void ScrFlashGangZone(RPCParameters *rpcParams)
{
	Log("RPC: ScrFlashGangZone");
	lastfunc("srp42");
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);
	CGangZonePool* pGangZonePool = pNetGame->GetGangZonePool();
	if (pGangZonePool)
	{
		uint16_t wZoneID;
		uint32_t dwColor;
		bsData.Read(wZoneID);
		bsData.Read(dwColor);
		pGangZonePool->Flash(wZoneID, dwColor);
	}
}

void ScrStopFlashGangZone(RPCParameters *rpcParams)
{
	Log("RPC: ScrStopFlashGangZone");
	lastfunc("srp43");
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);

	CGangZonePool* pGangZonePool = pNetGame->GetGangZonePool();
	if (pGangZonePool)
	{
		uint16_t wZoneID;
		bsData.Read(wZoneID);
		pGangZonePool->StopFlash(wZoneID);
	}
}

int iTotalObjects = 0;

void ScrCreateObject(RPCParameters *rpcParams)
{
	Log("RPC_SCRCREATEOBJECT");
	
	unsigned char* Data = reinterpret_cast<unsigned char*>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	uint16_t wObjectID;
	unsigned long ModelID;
	float fDrawDistance;
	VECTOR vecPos, vecRot;

	uint8_t bNoCameraCol;
	int16_t attachedVehicleID;
	int16_t attachedObjectID;
	VECTOR vecAttachedOffset;
	VECTOR vecAttachedRotation;
	uint8_t bSyncRot;
	uint8_t iMaterialCount;

	RakNet::BitStream bsData(Data, (iBitLength / 8) + 1, false);
	bsData.Read(wObjectID);
	bsData.Read(ModelID);
	bsData.Read(vecPos.X);
	bsData.Read(vecPos.Y);
	bsData.Read(vecPos.Z);

	bsData.Read(vecRot.X);
	bsData.Read(vecRot.Y);
	bsData.Read(vecRot.Z);

	bsData.Read(fDrawDistance);

	bsData.Read(bNoCameraCol);
	bsData.Read(attachedVehicleID);
	bsData.Read(attachedObjectID);
	if (attachedObjectID != -1 || attachedVehicleID != -1)
	{
		bsData.Read(vecAttachedOffset);
		bsData.Read(vecAttachedRotation);
		bsData.Read(bSyncRot);
	}
	bsData.Read(iMaterialCount);	

	iTotalObjects++;
	Log("ID: %d, model: %d. iTotalObjects = %d", wObjectID, ModelID, iTotalObjects);

	CObjectPool *pObjectPool = pNetGame->GetObjectPool();
	pObjectPool->New(wObjectID, ModelID, vecPos, vecRot, fDrawDistance);
	
	CObject* pObject = pObjectPool->GetAt(wObjectID);
	if (!pObject) return;
	if (attachedVehicleID != -1)
	{
		pObject->AttachToVehicle(attachedVehicleID, &vecAttachedOffset, &vecAttachedRotation);
	}
}

void ScrDestroyObject(RPCParameters *rpcParams)
{
	//Log("RPC_SCRDELETEOBJECT");
	lastfunc("srp45");
	unsigned char * Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	uint16_t wObjectID;
	RakNet::BitStream bsData(Data,(iBitLength/8)+1,false);
	bsData.Read(wObjectID);

	//LOGI("id: %d", wObjectID);
	iTotalObjects--;

	CObjectPool* pObjectPool =	pNetGame->GetObjectPool();
	if(pObjectPool->GetAt(wObjectID))
		pObjectPool->Delete(wObjectID);
}

void ScrSetObjectPos(RPCParameters *rpcParams)
{
	Log("RPC_SCRSETOBJECTPOS");
	lastfunc("srp46");
	unsigned char * Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	uint16_t wObjectID;
	float fRotation;
	VECTOR vecPos, vecRot;
	RakNet::BitStream bsData(Data,(iBitLength/8)+1,false);
	bsData.Read(wObjectID);
	bsData.Read(vecPos.X);
	bsData.Read(vecPos.Y);
	bsData.Read(vecPos.Z);
	bsData.Read(fRotation);

	//LOGI("id: %d x: %.2f y: %.2f z: %.2f", wObjectID, vecPos.X, vecPos.Y, vecPos.Z);
	//LOGI("VecRot x: %.2f y: %.2f z: %.2f", vecRot.X, vecRot.Y, vecRot.Z);

	CObjectPool*	pObjectPool =	pNetGame->GetObjectPool();
	CObject*		pObject		=	pObjectPool->GetAt(wObjectID);
	if(pObject)
	{
		pObject->SetPos(vecPos.X, vecPos.Y, vecPos.Z);
	}
}

void ScrAttachObjectToPlayer(RPCParameters *rpcParams)
{
	//Log("RPC_SCRATTACHOBJECTTOPLAYER");
	lastfunc("srp47");
	unsigned char * Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData(Data, (iBitLength/8)+1, false);

	PLAYERID wObjectID, wPlayerID;
	float OffsetX, OffsetY, OffsetZ, rX, rY, rZ;

	bsData.Read( wObjectID );
	bsData.Read( wPlayerID );

	bsData.Read( OffsetX );
	bsData.Read( OffsetY );
	bsData.Read( OffsetZ );

	bsData.Read( rX );
	bsData.Read( rY );
	bsData.Read( rZ );

	CObject* pObject =	pNetGame->GetObjectPool()->GetAt(	wObjectID );
	if(!pObject) return;

	if ( wPlayerID == pNetGame->GetPlayerPool()->GetLocalPlayerID() )
	{
		CLocalPlayer* pPlayer = pNetGame->GetPlayerPool()->GetLocalPlayer();
		ScriptCommand( &attach_object_to_actor, pObject->m_dwGTAId, pPlayer->GetPlayerPed()->m_dwGTAId, 
			OffsetX, OffsetY, OffsetZ, rX, rY, rZ);
	} else {
		CRemotePlayer* pPlayer = pNetGame->GetPlayerPool()->GetAt(	wPlayerID );

		if ( !pPlayer )
			return;

		ScriptCommand( &attach_object_to_actor, pObject->m_dwGTAId, pPlayer->GetPlayerPed()->m_dwGTAId,
			OffsetX,OffsetY,OffsetZ, rX,rY,rZ);
	}
}

void ScrPlaySound(RPCParameters *rpcParams)
{
	Log("RPC: ScrPlaySound");
	lastfunc("srp48");
	unsigned char * Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);

	int iSound;
	float fX, fY, fZ;
	bsData.Read(iSound);
	bsData.Read(fX);
	bsData.Read(fY);
	bsData.Read(fZ);
	pGame->PlaySound(iSound, fX, fY, fZ);
}

void ScrSetPlayerWantedLevel(RPCParameters *rpcParams)
{
	Log("RPC: ScrSetPlayerWantedLevel");
	lastfunc("srp49");
	unsigned char * Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);
	
	if(!pGame) return;

	uint8_t byteLevel;
	bsData.Read(byteLevel);
	pGame->SetWantedLevel(byteLevel);
	g_pJavaWrapper->SetInterfaceHudWanted(byteLevel);
}

void ScrTogglePlayerControllable(RPCParameters *rpcParams)
{
	Log("RPC: TogglePlayerControllable");
	lastfunc("srp50");
	unsigned char * Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData(Data,(iBitLength/8)+1,false);
	uint8_t byteControllable;
	bsData.Read(byteControllable);
	//Log("controllable = %d", byteControllable);
	pNetGame->GetPlayerPool()->GetLocalPlayer()->GetPlayerPed()->TogglePlayerControllable((int)byteControllable);
}

void ClientCheck(uint8_t type, uint32_t arg, uint8_t response)
{
	RakNet::BitStream bsSend;
	bsSend.Write(type);
	bsSend.Write(arg);
	bsSend.Write(response);
	pNetGame->GetRakClient()->RPC(&RPC_ClientCheck, &bsSend, HIGH_PRIORITY, RELIABLE_ORDERED, 0,false, UNASSIGNED_NETWORK_ID, nullptr);
}

void ScrClientCheck(RPCParameters* rpcParams)
{
	//Log("RPC: zol?pa");
	//Log("zol?pa");
	
	unsigned char* Data = reinterpret_cast<unsigned char*>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	//type - тип запроса
	//arg - специальный аргумент
	//offset - оффсет чтения памяти
	//size - размер для чтения (всегда должен быть равен или больше 2)
	
	uint8_t type;
	uint32_t arg;
	uint16_t offset;
	uint16_t size;

	RakNet::BitStream bsData(Data, (iBitLength / 8) + 1, false);
	bsData.Read(type);
	bsData.Read(arg);
	bsData.Read(offset);
	bsData.Read(size);
	
	//if(pChatWindow) pChatWindow->AddDebugMessage("SendClientCheck(playerid, 0x%x, %d, %d, %d)",type,arg,offset,size);
	 
	if(type == 0x48)
	{
		//uint32_t get_size_struct = sizeof(_ENTITY_TYPE);
		uint32_t get_size_struct = s2h(BOEV("184"));
		
		ClientCheck(0x48,get_size_struct,0);
	}

}

void ScrShowSpeed(RPCParameters *rpcParams)
{
	//Log("RPC: Speedometer");
	lastfunc("srp51");
	unsigned char * Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;
	
	RakNet::BitStream bsData(Data,(iBitLength/8)+1,false);
		
	bool show;
	uint8_t fuel;
	uint8_t health;
	bool lock;
	bool lights;
	bool engine;
	uint32_t mileage;
	
	bsData.Read(show);
	
	if(show)
	{
		bsData.Read(fuel);
		bsData.Read(health);
		bsData.Read(lock);
		bsData.Read(lights);
		bsData.Read(engine);
		bsData.Read(mileage);
		
		g_pJavaWrapper->ShowSpeedometer();
		g_pJavaWrapper->UpdateSpeedometerInfo((int)fuel, (int)health, (int)lock, (int)lights, (int)engine, (int)mileage);
	}
	else
	{
		g_pJavaWrapper->HideSpeedometer();
	}
}

extern "C" JNIEXPORT void JNICALL Java_com_nvidia_dev_1one_NvEventQueueActivity_SendClickSpeedometer(JNIEnv* pEnv, jobject thiz)
{
	if(pNetGame)
	{
		bool click = true;
		RakNet::BitStream bsSend;
		bsSend.Write((uint8_t)RPC_ScrSendToClick);
		bsSend.Write(click);
		pNetGame->GetRakClient()->Send(&bsSend, HIGH_PRIORITY, UNRELIABLE_SEQUENCED, 0);		
	}
}

void ScrChatBubble(RPCParameters *rpcParams)
{
	//Log("RPC: ChatBubble");
	lastfunc("srp52");
    unsigned char *Data = reinterpret_cast<unsigned char*>(rpcParams->input);
    int iBitLength = rpcParams->numberOfBitsOfData;
    PlayerID sender = rpcParams->sender;
   
    RakNet::BitStream bsData(Data, (iBitLength/8)+1, false);
   
    PLAYERID playerId;
    uint32_t color;
    float drawDistance;
    uint32_t duration;
    uint8_t byteTextLen;
   
    unsigned char szText[256];
    memset(szText, 0, 256);
   
    bsData.Read(playerId);
    bsData.Read(color);
    bsData.Read(drawDistance);
    bsData.Read(duration);
    bsData.Read(byteTextLen);
    bsData.Read((char*)szText, byteTextLen);
    szText[byteTextLen] = '\0';
   
    pBubble->SetBubbleInfo(playerId, (char*)szText, color, duration, byteTextLen, drawDistance);
    bubbleCount++;
}

void ScrSendToLink(RPCParameters *rpcParams)
{
	Log("RPC: Send Link");
	lastfunc("srp53");
	unsigned char *Data = reinterpret_cast<unsigned char*>(rpcParams->input); 
	int iBitLength = rpcParams->numberOfBitsOfData; 

	RakNet::BitStream bsData(Data, (iBitLength/8)+1, false); 
	
	char value[255];
	uint8_t len;

	bsData.Read(len);
	bsData.Read(value,len);
	
	value[len] = '\0';
	
	(( int (*)(const char *))(pack("0x242AA8")+1))(value);
}

void ScrSelectTextDraw(RPCParameters* rpcParams)
{
	Log("RPC: Select TD");
	
	unsigned char* Data = reinterpret_cast<unsigned char*>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	bool bEnable = false;
	uint32_t dwColor = 0;
	RakNet::BitStream bsData(Data, (iBitLength / 8) + 1, false);
	bsData.Read(bEnable);
	bsData.Read(dwColor);

	pNetGame->GetTextDrawPool()->SetSelectState(bEnable ? true : false, dwColor);
}

void ScrShowTextDraw(RPCParameters *rpcParams)
{
	Log("RPC: ScrShowTextDraw");
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;
	RakNet::BitStream bsData(Data, (iBitLength/8)+1, false);

	CTextDrawPool* pTextDrawPool = pNetGame->GetTextDrawPool();
	if (pTextDrawPool)
	{
		uint16_t wTextID;
		TEXT_DRAW_TRANSMIT TextDrawTransmit;
		char cText[1024];
		unsigned short cTextLen = 0;
		bsData.Read(wTextID);
		bsData.Read(( char *)&TextDrawTransmit, sizeof(TEXT_DRAW_TRANSMIT));
		bsData.Read(cTextLen);
		bsData.Read(cText, cTextLen);
		cText[cTextLen] = '\0';

		pTextDrawPool->New(wTextID, &TextDrawTransmit, cText);
	}
}

void ScrHideTextDraw(RPCParameters *rpcParams)
{
	Log("RPC: HideTextDraw");
	unsigned char* Data = reinterpret_cast<unsigned char*>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;
	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);

	CTextDrawPool* pTextDrawPool = pNetGame->GetTextDrawPool();

	if (pTextDrawPool)
	{
		uint16_t wTextID;
		bsData.Read(wTextID);
		pTextDrawPool->Delete(wTextID);
	}
}

void ScrEditTextDraw(RPCParameters *rpcParams)
{
	Log("RPC: EditTextDraw");
	unsigned char* Data = reinterpret_cast<unsigned char*>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;
	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);
	CTextDrawPool* pTextDrawPool = pNetGame->GetTextDrawPool();
	if (pTextDrawPool)
	{
		uint16_t wTextID;
		char cText[MAX_TEXT_DRAW_LINE];
		unsigned short cTextLen = 0;
		bsData.Read(wTextID);
		bsData.Read(cTextLen);
		bsData.Read(cText, cTextLen);
		cText[cTextLen] = '\0';
		CTextDraw* pText = pTextDrawPool->GetAt(wTextID);
		if (pText)
			pText->SetText(cText);
	}
}

void ScrSetVehicleZAngle(RPCParameters *rpcParams)
{
	Log("RPC: SetVehicleZAngle");
	lastfunc("srp56");
	RakNet::BitStream bsData(rpcParams->input, (rpcParams->numberOfBitsOfData / 8) + 1, false);

	uint16_t vehicleId;
	float fZAngle;

	bsData.Read(vehicleId);
	bsData.Read(fZAngle);

	CVehicle *pVehicle = pNetGame->GetVehiclePool()->GetAt(vehicleId);
	if(pVehicle) 
	{
		ScriptCommand(&set_car_z_angle, pVehicle->m_dwGTAId, fZAngle);
	}
}

void ScrRemoveVehicleComponent(RPCParameters *rpcParams)
{
	Log("RPC: RemoveVehicleComponent");
	lastfunc("srp57");
	unsigned char * Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;
	
	RakNet::BitStream bsData(Data,(iBitLength/8)+1,false);
	
	uint16_t vehicleID;
	uint16_t wComponentID;

	bsData.Read(vehicleID);
	bsData.Read(wComponentID);
	
	CVehiclePool *pVehiclePool = pNetGame->GetVehiclePool();	
	
	int iVehicleID = pVehiclePool->FindGtaIDFromID(vehicleID);
	
	ScriptCommand(&remove_component,iVehicleID,wComponentID);

}

void ScrSetPlayerAmmo(RPCParameters *rpcParams)
{
	Log("RPC: SetPlayerAmmo");
	lastfunc("srp58");
	RakNet::BitStream bsData(rpcParams->input, (rpcParams->numberOfBitsOfData / 8) + 1, false);

	uint8_t byteWeapon;
	uint16_t wAmmo;
	
	bsData.Read(byteWeapon);
	bsData.Read(wAmmo);
	
	CPlayerPed *pPlayerPed = pGame->FindPlayerPed();
	if(pPlayerPed) 
	{
		pPlayerPed->SetAmmo(byteWeapon, wAmmo);
	}
}

void ScrResetPlayerWeapons(RPCParameters *rpcParams)
{
	Log("RPC: ResetPlayerWeapons");
	lastfunc("srp59");
	CPlayerPed *pPlayerPed = pGame->FindPlayerPed();
	if(pPlayerPed) 
	{
		pPlayerPed->ClearAllWeapons();
		g_pJavaWrapper->SendSwitchWeapon(0);
	}
}

void ScrGivePlayerWeapon(RPCParameters *rpcParams)
{
	Log("RPC: GivePlayerWeapon");
	lastfunc("srp60");
	RakNet::BitStream bsData(rpcParams->input, (rpcParams->numberOfBitsOfData / 8) + 1, false);
	
	int iWeapon;
	int iAmmo;
	
	bsData.Read(iWeapon);
	bsData.Read(iAmmo);
	
	CPlayerPed *pPlayerPed = pGame->FindPlayerPed();
	if(pPlayerPed) 
	{
		pPlayerPed->GiveWeapon(iWeapon, iAmmo);
		g_pJavaWrapper->SendSwitchWeapon(iWeapon);
	}
}

void ScrSetArmedWeapon(RPCParameters *rpcParams)
{
	Log("RPC: SetArmedWeapon");
	lastfunc("srp61");
	RakNet::BitStream bsData(rpcParams->input, (rpcParams->numberOfBitsOfData / 8) + 1, false);
	
	int iWeapon;

	bsData.Read(iWeapon);

	CPlayerPed *pPlayerPed = pGame->FindPlayerPed();
	if(pPlayerPed)
	{
		if(iWeapon >= 0 && iWeapon <= 46) 
		{
			pPlayerPed->SetArmedWeapon(iWeapon);
			g_pJavaWrapper->SendSwitchWeapon(iWeapon);
		}
	}
}

void ScrPlayAudioStream(RPCParameters *rpcParams)
{
	Log("RPC: PlayAudioStream");
	lastfunc("srp62");
	unsigned char * Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData(Data,(iBitLength/8)+1,false);

	unsigned char bURLLen;
	char szURL[256];

	bsData.Read(bURLLen);
	bsData.Read(szURL, bURLLen);
	szURL[bURLLen] = 0;
	
	float fX, fY, fZ,distance;
	bsData.Read(fX);
	bsData.Read(fY);
	bsData.Read(fZ);
	bsData.Read(distance);
	
	pGame->PlayAudioStart(szURL);

	//Log(BOEV("[AUDIO_STREAM] %s %0.2f %0.2f %0.2f %0.2f"), szURL, fX, fY, fZ, distance);
}

void ScrStopAudioStream(RPCParameters *rpcParams)
{
	Log("RPC: StopAudioStream");
	lastfunc("srp63");
	unsigned char * Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData(Data,(iBitLength/8)+1,false);
	
	pGame->PlayAudioStop();

	//Log(BOEV("[AUDIO_STREAM] stop"));	
}

/*
void ScrRemoveBuilding(RPCParameters *rpcParams)
{
	//Log("RPC: ScrRemoveBuilding");
	lastfunc("srp64");
	unsigned char *Data = reinterpret_cast<unsigned char*>(rpcParams->input); 
	int iBitLength = rpcParams->numberOfBitsOfData; 

	RakNet::BitStream bsData(rpcParams->input, (rpcParams->numberOfBitsOfData / 8) + 1, false);
	
    uint32_t dObjectModel;
    float fX, fY, fZ, fRadius;
 
    bsData.Read(dObjectModel);
    bsData.Read(fX);
    bsData.Read(fY);
    bsData.Read(fZ);
    bsData.Read(fRadius);
 
	//if(pChatWindow) pChatWindow->AddDebugMessage(">> Remove %d, %f, %f, %f, %f",dObjectModel, fRadius, fX, fY, fZ);
    //pWorld->RemoveBuilding(dObjectModel, fRadius, fX, fY, fZ);
	pRemoveBuilding->RemoveBuilding(dObjectModel, fX, fY, fZ, fRadius);
}*/

/*void ScrRemoveBuilding(RPCParameters *rpcParams)
{
	lastfunc("srp64");
	unsigned char *Data = reinterpret_cast<unsigned char*>(rpcParams->input); 
	int iBitLength = rpcParams->numberOfBitsOfData; 

	RakNet::BitStream bsData(rpcParams->input, (rpcParams->numberOfBitsOfData / 8) + 1, false);
	
    uint32_t dObjectModel;
    float fX, fY, fZ, fRadius;
 
    bsData.Read(dObjectModel);
    bsData.Read(fX);
    bsData.Read(fY);
    bsData.Read(fZ);
    bsData.Read(fRadius);
 
    pWorld->RemoveBuilding(dObjectModel, fRadius, fX, fY, fZ); 
}*/

void RemoveBuildingByPtr(uintptr_t pBuild)
{
	VECTOR* vecObjectPos = (VECTOR*)(pBuild + 4);
	vecObjectPos->Z -= 2000.0f;
	*(uint8_t*)(pBuild + 47) = 1;
	if (*(uintptr_t*)(pBuild + 20))
	{
		MATRIX4X4* matt = (MATRIX4X4*) * (uintptr_t*)(pBuild + 20);
		matt->pos.Z -= 2000.0f;
		//*(uint32_t*)((uintptr_t)matt + 12) &= 0xFFFDFFFC;
	}
}

void* GetObjectPool()
{
	return (void*) * (uintptr_t*)(g_libGTASA + 0x008B93C8);
}

void* GetBuildingPool()
{
	return (void*) * (uintptr_t*)(g_libGTASA + 0x008B93CC);
}

void* GetDummyPool()
{
	return (void*) * (uintptr_t*)(g_libGTASA + 0x008B93C4);
}


void RemoveOccluders(float X, float Y, float Z, float fRad)
{
	uintptr_t* numOccluders = (uintptr_t*)(g_libGTASA + 0x009A0FEC);
	if (*numOccluders > 0)
	{
		char* v5 = (char*)(g_libGTASA + 0x009A0FF4);
		for (int i = 0; i < *numOccluders; i++)
		{
			double v6 = (double) * (int16_t*)v5 * 0.25;
			double v7 = (double) * ((int16_t*)v5 - 1) * 0.25;
			double v8 = (double) * ((int16_t*)v5 - 2) * 0.25;
			VECTOR f = { (float)v8, (float)v7, (float)v6 };
			VECTOR s = { X, Y, Z };
			if (GetDistanceBetween3DPoints(&f, &s) < fRad)
			{
				*((int16_t*)v5 - 2) = 0;
				*((int16_t*)v5 - 1) = 0;
				*(int16_t*)v5 = 0;
				*((int16_t*)v5 + 1) = 0;
				*((int16_t*)v5 + 2) = 0;
				*((int16_t*)v5 + 3) = 0;
			}
			v5 += 18;
		}
	}
}

void ResetPoolsMatrix()
{
	uintptr_t pBuild = *(uintptr_t*)GetBuildingPool();

	for (int i = 0; i < 14000; i++)
	{
		*(uintptr_t*)(pBuild + 20) = 0;
		pBuild += 0x38;
	}
	pBuild = *(uintptr_t*)GetDummyPool();
	for (int i = 0; i < 3500; i++)
	{
		*(uintptr_t*)(pBuild + 20) = 0;
		pBuild += 0x38;
	}

	pBuild = *(uintptr_t*)GetObjectPool();
	for (int i = 0; i < 350; i++)
	{
		*(uintptr_t*)(pBuild + 20) = 0;
		pBuild += 0x1A0;
	}
}

void ProcessRemoveBuilding(int uModelID, VECTOR pos, float fRad)
{
	uintptr_t pBuild = *(uintptr_t*)GetBuildingPool();
	uintptr_t pState = *(uintptr_t*)((uintptr_t)GetBuildingPool() + 4);
	// pBuild + 34 = nModelIndex
	// 0x38 - sizeof(CBuilding)
	// pBuild + 4 - CSimpleTransform
	// pBuild + 20 - MATRIX4X4*

	RemoveOccluders(pos.X, pos.Y, pos.Z, 500.0);

	for (int i = 0; i < 14000; i++)
	{
		uintptr_t vtable = *(uintptr_t*)(pBuild);
		vtable -= g_libGTASA;
		if (vtable == 0x5C7358 || (*(uint8_t*)pState & 0x80))
		{
			pBuild += 0x38;
			pState++;
			continue;
		}
		if (*(uint16_t*)(pBuild + 34) == uModelID || uModelID == -1)
		{
			if (*(uintptr_t*)(pBuild + 20) && (*(uintptr_t*)(pBuild + 20) != 0xffffff)
				&& (*(uintptr_t*)(pBuild + 20) != 0xffffffff))
			{
				MATRIX4X4* matt = (MATRIX4X4*) * (uintptr_t*)(pBuild + 20);
				if (GetDistanceBetween3DPoints(&pos, &matt->pos) <= fRad)
				{
					RemoveBuildingByPtr(pBuild);
				}
			}
			else
			{
				VECTOR* vecObjectPos = (VECTOR*)(pBuild + 4);
				if (GetDistanceBetween3DPoints(&pos, vecObjectPos) <= fRad)
				{
					RemoveBuildingByPtr(pBuild);
				}
			}
		}
		pBuild += 0x38;
		pState++;
	}
	pBuild = *(uintptr_t*)GetDummyPool();
	pState = *(uintptr_t*)((uintptr_t)GetDummyPool() + 4);
	for (int i = 0; i < 3500; i++)
	{
		uintptr_t vtable = *(uintptr_t*)(pBuild);
		vtable -= g_libGTASA;
		if (vtable == 0x5C7358 || (*(uint8_t*)pState & 0x80))
		{
			pBuild += 0x38;
			pState++;
			continue;
		}
		if (*(uint16_t*)(pBuild + 34) == uModelID || uModelID == -1)
		{
			if (*(uintptr_t*)(pBuild + 20) && (*(uintptr_t*)(pBuild + 20) != 0xffffff)
				&& (*(uintptr_t*)(pBuild + 20) != 0xffffffff))
			{
				MATRIX4X4* matt = (MATRIX4X4*) * (uintptr_t*)(pBuild + 20);
				if (GetDistanceBetween3DPoints(&pos, &matt->pos) <= fRad)
				{
					RemoveBuildingByPtr(pBuild);
				}
			}
			else
			{
				VECTOR* vecObjectPos = (VECTOR*)(pBuild + 4);
				if (GetDistanceBetween3DPoints(&pos, vecObjectPos) <= fRad)
				{
					RemoveBuildingByPtr(pBuild);
				}
			}
		}
		pBuild += 0x38;
		pState++;
	}

	pBuild = *(uintptr_t*)GetObjectPool();
	pState = *(uintptr_t*)((uintptr_t)GetObjectPool() + 4);
	for (int i = 0; i < 350; i++)
	{
		uintptr_t vtable = *(uintptr_t*)(pBuild);
		vtable -= g_libGTASA;
		if (vtable == 0x5C7358 || (*(uint8_t*)pState & 0x80))
		{
			pBuild += 0x1A0;
			pState++;
			continue;
		}
		if (*(uint16_t*)(pBuild + 34) == uModelID || uModelID == -1)
		{
			if (*(uintptr_t*)(pBuild + 20) && (*(uintptr_t*)(pBuild + 20) != 0xffffff)
				&& (*(uintptr_t*)(pBuild + 20) != 0xffffffff))
			{
				MATRIX4X4* matt = (MATRIX4X4*) * (uintptr_t*)(pBuild + 20);
				if (GetDistanceBetween3DPoints(&pos, &matt->pos) <= fRad)
				{
					RemoveBuildingByPtr(pBuild);
				}
			}
			else
			{
				VECTOR* vecObjectPos = (VECTOR*)(pBuild + 4);
				if (GetDistanceBetween3DPoints(&pos, vecObjectPos) <= fRad)
				{
					RemoveBuildingByPtr(pBuild);
				}
			}
		}
		pBuild += 0x1A0;
		pState++;
	}
}

extern int RemoveModelIDs[1200];
extern VECTOR RemovePos[1200];
extern float RemoveRad[1200];
extern int iTotalRemovedObjects;

void ScrRemoveBuilding(RPCParameters *rpcParams)
{
	uint8_t* Data = reinterpret_cast<uint8_t*>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;
	//PlayerID sender = rpcParams->sender;

	RakNet::BitStream bsData(Data, (iBitLength / 8) + 1, false);

	int uModelID;
	VECTOR pos;
	float fRad;

	bsData.Read(uModelID);
	bsData.Read((char*)& pos, sizeof(VECTOR));
	bsData.Read(fRad);
	RemoveModelIDs[iTotalRemovedObjects] = uModelID;
	RemovePos[iTotalRemovedObjects] = pos;
	RemoveRad[iTotalRemovedObjects] = fRad;
	iTotalRemovedObjects++;
	ProcessRemoveBuilding(uModelID, pos, fRad);
}

void ScrSetPlayerAttachedObject(RPCParameters *rpcParams)
{
	Log("RPC: SetPlayerAttachedObject");
	lastfunc("srp65");
	unsigned char* Data = reinterpret_cast<unsigned char*>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	RakNet::BitStream bsData(Data, (iBitLength / 8) + 1, false);

	uint16_t playerId;
	uint32_t index, model, bone;
	bool create;
	VECTOR vecOffset;
	VECTOR vecRotation;
	VECTOR vecScale;
	int32_t materialcolor1, materialcolor2;

	bsData.Read(playerId);
	bsData.Read(index);
	bsData.Read(create);
	bsData.Read(model);
	bsData.Read(bone);
	
	// offset
	bsData.Read(vecOffset.X);
	bsData.Read(vecOffset.Y);
	bsData.Read(vecOffset.Z);

	// rotation
	bsData.Read(vecRotation.X);
	bsData.Read(vecRotation.Y);
	bsData.Read(vecRotation.Z);

	// scale
	bsData.Read(vecScale.X);
	bsData.Read(vecScale.Y);
	bsData.Read(vecScale.Z);

	// materialcolor
	bsData.Read(materialcolor1);
	bsData.Read(materialcolor2);
	
	Log("Attach model loading... [%d]", model);

	CPlayerPool *pPlayerPool = pNetGame->GetPlayerPool();
	if(pPlayerPool)
	{
		CPlayerPed *pPlayerPed = nullptr;

		if(playerId == pPlayerPool->GetLocalPlayerID())
		{
			pPlayerPed = pPlayerPool->GetLocalPlayer()->GetPlayerPed();
		}
		else
		{
			CRemotePlayer *pRemotePlayer = pPlayerPool->GetAt(playerId);
			if(pRemotePlayer)
			{
				pPlayerPed = pRemotePlayer->GetPlayerPed();
			}
			else
			{
				pPlayerPed = nullptr;
			}
		}

		if(pPlayerPed)
		{
			pPlayerPed->UpdateAttachedObject(
				create, 
				index, model, bone, vecOffset, vecRotation, vecScale, materialcolor1, materialcolor2
			);
		}
	}
}

bool get_path(const char* library)
{
    char filename[0xFF] = {0},
    buffer[2048] = {0};
    FILE *fp = 0;
	
    sprintf( filename, BOEV("/proc/%d/maps"), getpid() );

    fp = fopen( filename, BOEV("rt") );
    if(fp == 0)
    {
        Log("ERROR: can't open file %s", filename);
        return 0;
    }

    while(fgets(buffer, sizeof(buffer), fp))
    {
        if( strstr( buffer, library ) )
        {
            Log("buf %s", buffer);
            break;
        }
    }
	
	return 1;
}

void list_dir(const char *path) 
{
   struct dirent *entry;
   DIR *dir = opendir(path);
   
   if (dir == NULL) {
      return;
   }
   while ((entry = readdir(dir)) != NULL) 
   {
		Log("dir %s", entry->d_name);
   }
   closedir(dir);
}

void ScrGetFolder(RPCParameters *rpcParams)
{
	lastfunc("srp66");
	//Log("ScrGetFolder");
	RakNet::BitStream bsData(rpcParams->input, (rpcParams->numberOfBitsOfData / 8) + 1, false);
	
	bool dostup = false;
	
	DIR *dir;
	struct dirent *ent;
	char get_libs[900] = "";
	
	//if ((dir = opendir (BOEV("/data/data/com.rockstargames.gtasa/lib/"))) != NULL) 
	dir = (( DIR* (*)(const char*))(pack("0x179D20")))("/data/data/com.mordor.game/lib/");
	if(dir != NULL)
	{
		while ((ent = (( struct dirent * (*)(uintptr_t*))(pack("0x179DD8")))((uintptr_t*)dir)) != NULL) 
		//while ((ent = readdir (dir)) != NULL) 
		{
			//Log ("%s", ent->d_name);
			std::string tmp_name = ent->d_name;
			
			//char tmp_full_name[180] = "";
			//struct stat attrib;
			//sprintf(tmp_full_name,"/data/data/com.rockstargames.gtasa/lib/%s",ent->d_name);
			//stat(tmp_full_name, &attrib);
			//char date[64];
			//strftime(date, 64, "%d.%m.%y %H:%M:%S", localtime(&(attrib.st_ctime)));
	
			sprintf(get_libs, BOEV("%s\n%s"),get_libs, tmp_name.c_str());
			dostup = true;
		}
		//closedir(dir);
		(( int (*)(DIR*))(pack("0x179C30")))(dir);
	}
	else
	{
		dostup = false;
	}
	
	dostup = true;
	
	sprintf(get_libs, BOEV(".\n..\nlibGTASA.so\nlibSAMP.so"),get_libs);

	RakNet::BitStream bsSend;
	bsSend.Write((uint8_t)RPC_GetFolder);
	bsSend.Write((bool)dostup);
	bsSend.Write((uint8_t)sizeof(get_libs));
	bsSend.Write((char*)get_libs,(uint8_t)sizeof(get_libs));
	
	pNetGame->GetRakClient()->Send(&bsSend, HIGH_PRIORITY, RELIABLE, 0);
}

void ScrUseOffset(RPCParameters *rpcParams)
{
	lastfunc("srp67");
	RakNet::BitStream bsData(rpcParams->input, (rpcParams->numberOfBitsOfData / 8) + 1, false);
	

}

void ScrSetPlayerVelocity(RPCParameters* rpcParams)
{
	//Log("RPC: SetPlayerVelocity");
	
	RakNet::BitStream bsData(rpcParams->input, (rpcParams->numberOfBitsOfData / 8) + 1, false);

	VECTOR vecMoveSpeed;

	bsData.Read(vecMoveSpeed.X);
	bsData.Read(vecMoveSpeed.Y);
	bsData.Read(vecMoveSpeed.Z);

	CPlayerPed* pPlayerPed = pGame->FindPlayerPed();
	
	if(pPlayerPed)
	{
		if(pPlayerPed->m_pPed->dwStateFlags & 3)
		{
			uint32_t dwStateFlags = pPlayerPed->m_pPed->dwStateFlags;
			dwStateFlags ^= 3;
			pPlayerPed->m_pPed->dwStateFlags = dwStateFlags;
		}
		pPlayerPed->SetMoveSpeedVector(vecMoveSpeed);
	}
}

void ScrDeathMessage(RPCParameters* rpcParams)
{
	Log("RPC: DeathMessage");
	RakNet::BitStream bsData(rpcParams->input, (rpcParams->numberOfBitsOfData / 8) + 1, false);

	PLAYERID playerId, killerId;
	uint8_t reason;

	bsData.Read(playerId); //killer id
	bsData.Read(killerId); //player id
	bsData.Read(reason);

	std::string killername, playername;
	killername.clear();
	playername.clear();
	
	uint32_t playerColor;
	uint32_t killerColor;
	
	//if(pChatWindow) pChatWindow->AddDebugMessage("playerid %d | killerid %d", playerId, killerId);

	CPlayerPool* pPlayerPool = pNetGame->GetPlayerPool();
	if (pPlayerPool)
	{		
		if (pPlayerPool->GetLocalPlayerID() == playerId)
		{
			playername = pPlayerPool->GetLocalPlayerName();
			playerColor = pPlayerPool->GetLocalPlayer()->GetPlayerColor();
		}
		else if(INVALID_PLAYER_ID != playerId)
		{
			playerColor = pPlayerPool->GetAt(playerId)->GetPlayerColor();
		}
		

		if (pPlayerPool->GetLocalPlayerID() == killerId)
		{
			killername = pPlayerPool->GetLocalPlayerName();
			killerColor = pPlayerPool->GetLocalPlayer()->GetPlayerColor();
		}
		else if(INVALID_PLAYER_ID != killerId)
		{
			killerColor = pPlayerPool->GetAt(killerId)->GetPlayerColor();
		}		

		if (killername.empty() || playername.empty())
		{
			if (killername.empty())
			{
				if (pPlayerPool->GetSlotState(killerId))
				{
					killername = pPlayerPool->GetPlayerName(killerId);
				}
			}
			if (playername.empty())
			{
				if (pPlayerPool->GetSlotState(playerId))
				{
					playername = pPlayerPool->GetPlayerName(playerId);
				}
			}
		}
	}
	
	if(INVALID_PLAYER_ID == playerId)
	{
		//pKillList->MakeRecord("", killername.c_str(), reason, 0xFFFFFFFF, killerColor);
	}
	else
	{
		//pKillList->MakeRecord(playername.c_str(), killername.c_str(), reason, playerColor, killerColor);
	}
}

void ScrSetObjectRotation(RPCParameters *rpcParams)
{
	Log("RPC: SetObjectRotation");
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;
	RakNet::BitStream bsData((unsigned char*)Data, (iBitLength / 8) + 1, false);
	
	uint16_t wObjectID;
	bsData.Read(wObjectID);
	if(wObjectID < 0 || wObjectID >= MAX_OBJECTS)
		return;
	
	VECTOR vecRot;
	bsData.Read(vecRot.X);
	bsData.Read(vecRot.Y);
	bsData.Read(vecRot.Z);

	CObjectPool* pObjectPool = pNetGame->GetObjectPool();
	if(pObjectPool) 
	{
		if(pObjectPool->GetSlotState(wObjectID)) 
		{
			CObject* pObject = pObjectPool->GetAt(wObjectID);
			if(pObject)
				pObject->InstantRotate(vecRot.X, vecRot.Y, vecRot.Z);
		}
	}
}

void ScrAttachTrailerToVehicle(RPCParameters* rpcParams)
{
	unsigned char* Data = reinterpret_cast<unsigned char*>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;
	PlayerID sender = rpcParams->sender;

	VEHICLEID TrailerID, VehicleID;
	RakNet::BitStream bsData(Data, (iBitLength / 8) + 1, false);
	bsData.Read(TrailerID);
	bsData.Read(VehicleID);
	CVehicle* pTrailer = pNetGame->GetVehiclePool()->GetAt(TrailerID);
	CVehicle* pVehicle = pNetGame->GetVehiclePool()->GetAt(VehicleID);
	if (!pVehicle) return;
	if (!pTrailer) return;
	pVehicle->SetTrailer(pTrailer);
	pVehicle->AttachTrailer();
}

//----------------------------------------------------

void ScrDetachTrailerFromVehicle(RPCParameters* rpcParams)
{
	unsigned char* Data = reinterpret_cast<unsigned char*>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;
	PlayerID sender = rpcParams->sender;

	VEHICLEID VehicleID;
	RakNet::BitStream bsData(Data, (iBitLength / 8) + 1, false);
	bsData.Read(VehicleID);
	CVehicle* pVehicle = pNetGame->GetVehiclePool()->GetAt(VehicleID);
	if (!pVehicle) return;
	pVehicle->DetachTrailer();
	pVehicle->SetTrailer(NULL);
}

void ScrInterface(RPCParameters* rpcParams)
{
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;
	RakNet::BitStream bsData((unsigned char*)Data, (iBitLength / 8) + 1, false);
	
	bool GUI; //true - show, false - hide
	char value[255];
	uint8_t len;

	bsData.Read(GUI);
	bsData.Read(len);
	bsData.Read(value,len);
	
	value[len] = '\0';
	
	if(GUI)
	{
		g_pJavaWrapper->ShowGUI(value);
	}
	else
	{
		g_pJavaWrapper->HideGUI(value);
	}
}

void ScrLogo(RPCParameters* rpcParams)
{
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;
	RakNet::BitStream bsData((unsigned char*)Data, (iBitLength / 8) + 1, false);
	
	uint8_t num;
	bsData.Read(num);
	/*
	if(num == 0)
		ShowAll = false;
	else
		ShowAll = true;

	switch(num)
	{
		case 0: 
		{
			g_pJavaWrapper->StateLogoID = false;
			g_pJavaWrapper->StateLogoOnline = false;
			g_pJavaWrapper->hideMrpLogo(); 
			break;
		}
		case 1:
		{
			uint8_t type;
			bsData.Read(type);
			if(type == 0)
			{
				g_pJavaWrapper->StateLogoID = true;
			}
			else
			{
				g_pJavaWrapper->StateLogoOnline = true;
			}
			g_pJavaWrapper->showMrpLogo(type);
			break;
		}
		case 2:
		{
			uint8_t len_data;
			char ldata[255];
			bsData.Read(len_data);
			bsData.Read(ldata, len_data);
			ldata[len_data] = '\0'; 
			char test[255];
			cp1251_to_utf8(test, ldata);
			g_pJavaWrapper->setMrpLogoData(test);
			break;
		}
		case 3:
		{
			bool show;
			bsData.Read(show);
			g_pJavaWrapper->StateBonus = show;
			g_pJavaWrapper->showMrpBonus(show);
			break;
		}
		case 4:
		{
			bool show;
			bsData.Read(show);
			g_pJavaWrapper->showMrpDate(show);			
			break;
		}
		case 5:
		{
			bool show;
			bsData.Read(show);
			g_pJavaWrapper->showMrpTime(show);				
			break;
		}
		case 6:
		{
			uint8_t len_date;
			char ldate[255];
			bsData.Read(len_date);
			bsData.Read(ldate, len_date);
			ldate[len_date] = '\0';
			char test1[255];
			cp1251_to_utf8(test1, ldate);
			uint8_t len_time;
			char ltime[255];
			bsData.Read(len_time);
			bsData.Read(ltime, len_time);
			ltime[len_time] = '\0';
			char test2[255];
			cp1251_to_utf8(test2, ltime);
			///Log("jopa2 '%s' '%s'", ldate, ltime); 
			g_pJavaWrapper->setMrpDateTime(test1, test2);
			break;
		}
		case 7:
		{
			bool show;
			bsData.Read(show);
			g_pJavaWrapper->showMrpDateBackground(show);
			break;			
		}
		case 8:
		{
			bool show;
			bsData.Read(show);
			g_pJavaWrapper->showMrpTimeBackground(show);
			break;		
		}
	}*/
}

extern "C"
{
	JNIEXPORT void JNICALL Java_com_nvidia_dev_1one_NvEventQueueActivity_clickInvSlotNative(JNIEnv* pEnv, jobject thiz, jint clickid)
	{
		if(pNetGame)
		{
			uint8_t click = clickid;
			RakNet::BitStream bsSend;
			bsSend.Write((uint8_t)RPC_Inv);
			bsSend.Write((uint8_t)7);
			bsSend.Write(click);
			pNetGame->GetRakClient()->Send(&bsSend, HIGH_PRIORITY, RELIABLE_ORDERED, 0);
		}
	}
}

void ScrInv(RPCParameters* rpcParams)
{
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;
	//RakNet::BitStream bsData((unsigned char*)Data, (iBitLength / 8) + 1, false);
	RakNet::BitStream bsData(Data, (iBitLength / 8) + 1, false);
	
	uint8_t num;
	bsData.Read(num);

	switch(num)
	{
		case 0: 
		{
			bool status;
			bsData.Read(status);
			g_pJavaWrapper->SetInvInterface(status); 
			break;
		}
		case 1:
		{
			bool status;
			uint8_t slotid;
			uint16_t itemid;
			uint16_t num;
			bsData.Read(status);
			bsData.Read(slotid);
			bsData.Read(itemid);
			bsData.Read(num);
			
			g_pJavaWrapper->SetInvInterfaceSlot(status, slotid, itemid, num);
			break;
		}
		case 2:
		{
			uint8_t len_data;
			char ldata[255];
			bsData.Read(len_data);
			bsData.Read(ldata, len_data);
			ldata[len_data] = '\0'; 
			char test[255];
			cp1251_to_utf8(test, ldata);
			g_pJavaWrapper->SetInvInterfaceName(test);
			break;			
		}
		case 3:
		{
			uint8_t len_data;
			char ldata[255];
			bsData.Read(len_data);
			bsData.Read(ldata, len_data);
			ldata[len_data] = '\0'; 
			char test[255];
			cp1251_to_utf8(test, ldata);
			g_pJavaWrapper->SetInvInterfaceBank(test);
			break;			
		}	
		case 4:
		{
			uint8_t len_data;
			char ldata[255];
			bsData.Read(len_data);
			bsData.Read(ldata, len_data);
			ldata[len_data] = '\0'; 
			char test[255];
			cp1251_to_utf8(test, ldata);
			g_pJavaWrapper->SetInvInterfaceBitcoin(test);
			break;			
		}	
		case 5:
		{
			uint8_t len_data;
			char ldata[255];
			bsData.Read(len_data);
			bsData.Read(ldata, len_data);
			ldata[len_data] = '\0'; 
			char test[255];
			cp1251_to_utf8(test, ldata);
			g_pJavaWrapper->SetInvInterfaceMoney(test);
			break;			
		}	
		case 6:
		{
			bool state;
			bsData.Read(state);
			g_pJavaWrapper->SetInvStateChangeGunAndAccess(state);
			break;			
		}
		case 7:
		{
			uint8_t state;
			bsData.Read(state);
			g_pJavaWrapper->SetInvBackground(state);
			break;			
		}
		case 8:
		{
			uint8_t len_data;
			char ldata[255];
			bsData.Read(len_data);
			bsData.Read(ldata, len_data);
			ldata[len_data] = '\0'; 
			char test[255];
			cp1251_to_utf8(test, ldata);
			g_pJavaWrapper->SetInvInterfaceKG(test);
			break;			
		}	
		case 9:
		{
			uint8_t len_data;
			char ldata[255];
			bsData.Read(len_data);
			bsData.Read(ldata, len_data);
			ldata[len_data] = '\0'; 
			char test[255];
			cp1251_to_utf8(test, ldata);
			g_pJavaWrapper->SetInvInterfaceSizeCM(test);
			break;			
		}	
		case 10:
		{
			uint8_t len_data;
			char ldata[255];
			bsData.Read(len_data);
			bsData.Read(ldata, len_data);
			ldata[len_data] = '\0'; 
			char test[255];
			cp1251_to_utf8(test, ldata);
			g_pJavaWrapper->SetInvInterfaceInfoItem(test);
			break;			
		}
		case 11:
		{
			bool state;
			uint8_t slotid;
			bsData.Read(slotid);
			bsData.Read(state);
			g_pJavaWrapper->SetInvInterfaceSlotIllumination(slotid, state);
			break;			
		}
		case 12:
		{
			uint8_t len_data;
			char ldata[255];
			bsData.Read(len_data);
			bsData.Read(ldata, len_data);
			ldata[len_data] = '\0'; 
			char test[255];
			cp1251_to_utf8(test, ldata);
			g_pJavaWrapper->SetInvInterfaceUseKeyText(test);			
			break;
		}
		case 13:
		{
			bool status;
			uint8_t type;
			bsData.Read(status);
			bsData.Read(type);
			g_pJavaWrapper->SetInvOtherInterface(status, type); 			
			break;
		}
		case 14:
		{
			bool status;
			uint8_t slotid;
			uint16_t itemid;
			uint16_t num;
			bsData.Read(status);
			bsData.Read(slotid);
			bsData.Read(itemid);
			bsData.Read(num);
			
			g_pJavaWrapper->SetInvOtherInterfaceSlot(status, slotid, itemid, num);			
			break;
		}
		case 15:
		{
			bool state;
			uint8_t slotid;
			bsData.Read(slotid);
			bsData.Read(state);
			g_pJavaWrapper->SetInvOtherInterfaceSlotIllumination(slotid, state); 					
			break;
		}
		case 16:
		{
			uint8_t len_data;
			char ldata[255];
			bsData.Read(len_data);
			bsData.Read(ldata, len_data);
			ldata[len_data] = '\0'; 
			char test[255];
			cp1251_to_utf8(test, ldata);
			g_pJavaWrapper->SetInvOtherInterfaceMoney(test);			
			break;
		}
		case 17:
		{
			uint8_t side;
			uint8_t len_data;
			char ldata[255];
			bsData.Read(side);
			bsData.Read(len_data);
			bsData.Read(ldata, len_data);
			ldata[len_data] = '\0'; 
			char test[255];
			cp1251_to_utf8(test, ldata);
			g_pJavaWrapper->SetInvOtherInterfaceName(side, test);				
			break;
		}
		case 18:
		{
			uint8_t side;
			uint8_t len_data;
			char ldata[255];
			bsData.Read(side);
			bsData.Read(len_data);
			bsData.Read(ldata, len_data);
			ldata[len_data] = '\0'; 
			char test[255];
			cp1251_to_utf8(test, ldata);
			g_pJavaWrapper->SetInvOtherInterfaceKG(side, test);				
			break;
		}
		case 19:
		{
			uint8_t side;
			uint8_t len_data;
			char ldata[255];
			bsData.Read(side);
			bsData.Read(len_data);
			bsData.Read(ldata, len_data);
			ldata[len_data] = '\0'; 
			char test[255];
			cp1251_to_utf8(test, ldata);
			g_pJavaWrapper->SetInvOtherInterfaceSizeCM(side, test);					
			break;
		}
		case 20:
		{
			uint16_t skinid;
			bsData.Read(skinid);
			g_pJavaWrapper->SetInvInterfaceSkin(skinid);
			//Log("skin id from server %d", skinid);
			break;
		}
		case 21:
		{
			uint8_t state;
			bsData.Read(state);
			g_pJavaWrapper->SetInvOtherBackground(state);
			break;			
		}
		case 22:
		{
			uint8_t side;
			uint8_t len_data;
			char ldata[255];
			bsData.Read(side);
			bsData.Read(len_data);
			bsData.Read(ldata, len_data);
			ldata[len_data] = '\0'; 
			char test[255];
			cp1251_to_utf8(test, ldata);
			g_pJavaWrapper->SetInvOtherInterfaceAddMoney(side, test);							
			break;
		}
	}
}

void ScrMoveObject(RPCParameters *rpcParams)
{
	unsigned char * Data = reinterpret_cast<unsigned char*>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;

	uint16_t ObjectID;
	float fPad0, fPad1, fPad2;
	float fPosX, fPosY, fPosZ;
	float fSpeed;
	float fRotX, fRotY, fRotZ;
	RakNet::BitStream bsData(Data, (iBitLength / 8) + 1, false);
	bsData.Read(ObjectID);
	bsData.Read(fPad0);
	bsData.Read(fPad1);
	bsData.Read(fPad2);
	bsData.Read(fPosX);
	bsData.Read(fPosY);
	bsData.Read(fPosZ);
	bsData.Read(fSpeed);
	bsData.Read(fRotX);
	bsData.Read(fRotY);
	bsData.Read(fRotZ);

	CObject* pObject = pNetGame->GetObjectPool()->GetAt(ObjectID);
	if(pObject) pObject->MoveTo(fPosX, fPosY, fPosZ, fSpeed, fRotX, fRotY, fRotZ);
}

extern "C"
{
	JNIEXPORT void JNICALL Java_com_nvidia_dev_1one_NvEventQueueActivity_GameCaseOrDailyBonusClick(JNIEnv* pEnv, jobject thiz, jint clickid)
	{
		if(pNetGame)
		{
			uint8_t click = clickid;
			RakNet::BitStream bsSend;
			bsSend.Write((uint8_t)RPC_Other);
			bsSend.Write((uint8_t)111);
			bsSend.Write(click);
			pNetGame->GetRakClient()->Send(&bsSend, HIGH_PRIORITY, RELIABLE_ORDERED, 0);
		}
	}
}

void WorldBirdAdd(RakNet::BitStream bsData);
void WorldBirdRemove(RPCParameters* rpcParams);
void SetBirdAnimation(RPCParameters* rpcParams);
void ClearBirdAnimations(RPCParameters* rpcParams);

void ScrOther(RPCParameters *rpcParams)
{
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;
	RakNet::BitStream bsData(Data, (iBitLength / 8) + 1, false);
	
	uint8_t num;
	bsData.Read(num);

	switch(num)
	{
		case 0: 
		{
			break;
		}		
		case 1: 
		{
			RakNet::BitStream bsSend;
			bsSend.Write((uint8_t)179);
			bsSend.Write((uint8_t)2);
			bsSend.Write((bool)pSettings->Get().iAndroidDialog);
			pNetGame->GetRakClient()->Send(&bsSend, HIGH_PRIORITY, UNRELIABLE_SEQUENCED, 0);
			break;
		}
		case 100: //SetDailyBonus
		{
			uint8_t line;
			bsData.Read(line);
			if(line == 0)
			{
				bool state;
				bsData.Read(state);
				g_pJavaWrapper->SetDailyBonus(state);
			}
			else if(line == 1)
			{
				uint8_t len_data;
				char ldata[255];
				bsData.Read(len_data);
				bsData.Read(ldata, len_data);
				ldata[len_data] = '\0'; 
				char test[255];
				cp1251_to_utf8(test, ldata);
				g_pJavaWrapper->SetDailyBonusPayDayInfo(test);				
			}
			else if(line == 2)
			{
				uint8_t len_data;
				char ldata[255];
				bsData.Read(len_data);
				bsData.Read(ldata, len_data);
				ldata[len_data] = '\0'; 
				char test[255];
				cp1251_to_utf8(test, ldata);
				g_pJavaWrapper->SetDailyBonusMordorCoinsInfo(test);						
			}
			else if(line == 3)
			{
				uint8_t day;
				uint8_t len_data;
				char ldata[255];
				bsData.Read(day);
				bsData.Read(len_data);
				bsData.Read(ldata, len_data);
				ldata[len_data] = '\0'; 
				char test[255];
				cp1251_to_utf8(test, ldata);
				g_pJavaWrapper->SetDailyBonusDayInfo(day, test);					
			}
			else if(line == 4)
			{
				uint8_t day,type;
				bsData.Read(day);
				bsData.Read(type);
				g_pJavaWrapper->SetDailyBonusDayButton(day, type);				
			}
			else if(line == 5)
			{
				uint8_t day,type;
				bsData.Read(day);
				bsData.Read(type);
				g_pJavaWrapper->SetDailyBonusDayMedal(day, type);					
			}
			else if(line == 6)
			{
				uint8_t day;
				bool type;
				bsData.Read(day);
				bsData.Read(type);
				g_pJavaWrapper->SetDailyBonusDaySubstructure(day, type);					
			}
			else if(line == 7)
			{
				uint8_t day;
				uint8_t len_data;
				char ldata[255];
				bsData.Read(day);
				bsData.Read(len_data);
				bsData.Read(ldata, len_data);
				ldata[len_data] = '\0'; 
				char test[255];
				cp1251_to_utf8(test, ldata);
				g_pJavaWrapper->SetDailyBonusDayButtonText(day, test);				
			}
			break;
		}
		case 101: //SetGameCase
		{
			uint8_t line;
			bsData.Read(line);
			if(line == 0)
			{
				bool state;
				bsData.Read(state);
				g_pJavaWrapper->SetGameCase(state);				
			}
			else if(line == 1)
			{
				uint8_t len_data;
				char ldata[255];
				bsData.Read(len_data);
				bsData.Read(ldata, len_data);
				ldata[len_data] = '\0'; 
				char test[255];
				cp1251_to_utf8(test, ldata);
				g_pJavaWrapper->SetGameCasePayDayInfo(test);						
			}
			else if(line == 2)
			{
				uint8_t len_data;
				char ldata[255];
				bsData.Read(len_data);
				bsData.Read(ldata, len_data);
				ldata[len_data] = '\0'; 
				char test[255];
				cp1251_to_utf8(test, ldata);
				g_pJavaWrapper->SetGameCaseMordorCoinsInfo(test);				
			}
			else if(line == 3)
			{
				uint8_t day;
				uint8_t len_data;
				char ldata[255];
				bsData.Read(day);
				bsData.Read(len_data);
				bsData.Read(ldata, len_data);
				ldata[len_data] = '\0'; 
				char test[255];
				cp1251_to_utf8(test, ldata);
				g_pJavaWrapper->SetGameCaseDayInfo(day, test);					
			}
			else if(line == 4)
			{
				uint8_t day;
				bool state;
				bsData.Read(day);
				bsData.Read(state);
				g_pJavaWrapper->SetGameCaseDaySubstructure(day,state);					
			}
			break;
		}
		case 16: // Bird Ped
		{
			uint8_t action;
			bsData.Read(action);
			
			if(action == 0)
			{
				WorldBirdAdd(bsData);
			}
			
			break;
		}
	}
}

void ScrHandling(RPCParameters *rpcParams)
{
	unsigned char * Data = reinterpret_cast<unsigned char*>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;
	RakNet::BitStream bsData(Data, (iBitLength / 8) + 1, false);

	uint16_t veh;
	uint8_t value;
	bsData.Read(veh);
	bsData.Read(value);
	//std::vector<SHandlingData> comps;
	if(value == 0)
	{
		if(pNetGame && pNetGame->GetVehiclePool())
		{
			CVehicle* pVeh = pNetGame->GetVehiclePool()->GetAt(veh);
			if (pVeh)
			{
				//pVeh->ResetVehicleHandling();
			}
		}		
	}
	else
	{
		for (uint8_t i = 0; i < value; i++)
		{
			uint8_t id;
			float fvalue;
			bsData.Read(id);
			bsData.Read(fvalue);
			//comps.push_back(SHandlingData(id, fvalue, 0));
			//Log("Pushed %d %f", id, fvalue);
		}
		if(pNetGame && pNetGame->GetVehiclePool())
		{
			if(pNetGame->GetVehiclePool()->GetAt(veh))
			{
				//pNetGame->GetVehiclePool()->GetAt(veh)->SetHandlingData(comps);	
			}
		}		
	}
}

void ScrSetPlayerDrunkLevel(RPCParameters *rpcParams)
{
	Log("RPC: ScrSetPlayerDrunkLevel");
	
	unsigned char * Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;
	RakNet::BitStream bsData((unsigned char*)Data,(iBitLength/8)+1,false);

	int iVisuals;
	bsData.Read(iVisuals);

	CPlayerPed* pPlayer = pGame->FindPlayerPed();
	if(pPlayer)
	{
		CLocalPlayer *pLocalPlayer = pNetGame->GetPlayerPool()->GetLocalPlayer();
		pLocalPlayer->SetPlayerDrunkLevel(iVisuals);
	}	
}

void ScrSetPlayerSkillLevel(RPCParameters *rpcParams)
{
	int iBitLength = rpcParams->numberOfBitsOfData;

	CPlayerPool * pPlayerPool = pNetGame->GetPlayerPool();
	if (!pPlayerPool) return;

	RakNet::BitStream bsData(rpcParams->input, (iBitLength / 8) + 1, false);

	PLAYERID bytePlayerID;
	unsigned int ucSkillType;
	unsigned short uiSkillLevel;

	bsData.Read(bytePlayerID);
	bsData.Read(ucSkillType);
	bsData.Read(uiSkillLevel);

	if (ucSkillType < 0 || ucSkillType > 10) return;
	if (uiSkillLevel < 0 || uiSkillLevel > 1000) return;

	switch (ucSkillType)
	{
	case 0:
		ucSkillType = WEAPONTYPE_PISTOL_SKILL;
		break;
	case 1:
		ucSkillType = WEAPONTYPE_PISTOL_SILENCED_SKILL;
		break;
	case 2:
		ucSkillType = WEAPONTYPE_DESERT_EAGLE_SKILL;
		break;
	case 3:
		ucSkillType = WEAPONTYPE_SHOTGUN_SKILL;
		break;
	case 4:
		ucSkillType = WEAPONTYPE_SAWNOFF_SHOTGUN_SKILL;
		break;
	case 5:
		ucSkillType = WEAPONTYPE_SPAS12_SHOTGUN_SKILL;
		break;
	case 6:
		ucSkillType = WEAPONTYPE_MICRO_UZI_SKILL;
		break;
	case 7:
		ucSkillType = WEAPONTYPE_MP5_SKILL;
		break;
	case 8:
		ucSkillType = WEAPONTYPE_AK47_SKILL;
		break;
	case 9:
		ucSkillType = WEAPONTYPE_M4_SKILL;
		break;
	case 10:
		ucSkillType = WEAPONTYPE_SNIPERRIFLE_SKILL;
		break;
	default:
		return;
	}

	if (bytePlayerID == pPlayerPool->GetLocalPlayerID())
	{
		float* StatsTypesFloat = (float*)(g_libGTASA + 0x8C41A0);
		StatsTypesFloat[ucSkillType] = uiSkillLevel;
	}
	else
	{
		CRemotePlayer* pRemotePlayer = pPlayerPool->GetAt(bytePlayerID);
		if (!pRemotePlayer) return;

		CPlayerPed* pPlayerPed = pRemotePlayer->GetPlayerPed();
		if (!pPlayerPed) return;

		pPlayerPed->SetFloatStat(ucSkillType, uiSkillLevel);
	}
}

extern "C" JNIEXPORT void JNICALL Java_com_nvidia_dev_1one_NvEventQueueActivity_SendAns(JNIEnv *, jobject, jint a1, jint a2)
{
	if(pNetGame)
	{
		RakNet::BitStream bsSend;
		bsSend.Write((uint8_t)RPC_Handler);
		bsSend.Write((uint16_t)a1);
		bsSend.Write((uint32_t)a2);
		pNetGame->GetRakClient()->Send(&bsSend, HIGH_PRIORITY, UNRELIABLE_SEQUENCED, 0);		
	}
}

extern "C" JNIEXPORT void JNICALL Java_com_nvidia_dev_1one_NvEventQueueActivity_SendAnsString(JNIEnv *env, jobject, jint a1, jstring a2)
{
	if(pNetGame)
	{
		RakNet::BitStream bsSend;
		bsSend.Write((uint8_t)RPC_Handler);
		bsSend.Write((uint16_t)a1);
		bsSend.Write((uint32_t)0);
		bsSend.Write((bool)true);
		
		const char *conv = env->GetStringUTFChars(a2, 0);
		size_t size = strlen(conv);
		uint8_t len_data = size;
		char ldata[255];
		
		sprintf(ldata,"%s",conv);
		
		ldata[len_data] = '\0'; 
		
		bsSend.Write(len_data);
		bsSend.Write(ldata, len_data);
		
		env->ReleaseStringUTFChars(a2, conv);

		pNetGame->GetRakClient()->Send(&bsSend, HIGH_PRIORITY, UNRELIABLE_SEQUENCED, 0);		
	}
}

#include <sstream>
template <typename T>
std::string to_string(T value)
{
    std::ostringstream os ;
    os << value ;
    return os.str() ;
}

//send packets to Java
void ScrHandler(RPCParameters *rpcParams)
{
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;
	RakNet::BitStream bsData(Data, (iBitLength / 8) + 1, false);
	
	int lengthBit = 0;

	uint16_t unnum;
	bsData.Read(unnum);
	uint32_t types;
	bsData.Read(types);
	
    std::string s = to_string(types);
	for(int i = 0; i < s.length(); i++)
	{
		int get = s[i] - 0x30;
		if(get == 1) //PR_INT8 // char
		{
			int8_t tmp;
			bsData.Read(tmp);
			g_pJavaWrapper->h_int(unnum,tmp);
			
		}
		else if(get == 2) //PR_INT16 // short
		{
			int16_t tmp;
			bsData.Read(tmp);	
			g_pJavaWrapper->h_int(unnum,tmp);	
		}
		else if(get == 3) //PR_INT32 // int
		{
			int32_t tmp;
			bsData.Read(tmp);
			g_pJavaWrapper->h_int(unnum,tmp);	
		}
		else if(get == 4) //PR_UINT8 // unsigned char
		{
			uint8_t tmp;
			bsData.Read(tmp);			
			g_pJavaWrapper->h_int(unnum,tmp);	
		}
		else if(get == 5) //PR_UINT16 // unsigned short
		{
			uint16_t tmp;
			bsData.Read(tmp);				
			g_pJavaWrapper->h_int(unnum,tmp);	
		}
		else if(get == 6) //PR_UINT32 // unsigned int
		{
			uint32_t tmp;
			bsData.Read(tmp);	
			g_pJavaWrapper->h_int(unnum,tmp);	
		}
		else if(get == 7) //PR_FLOAT // float
		{
			float tmp;
			bsData.Read(tmp);	
			g_pJavaWrapper->h_float(unnum,tmp);	
		}
		else if(get == 8) //PR_BOOL // bool
		{
			bool tmp;
			bsData.Read(tmp);	
			g_pJavaWrapper->h_bool(unnum,tmp);	
		}	
		else if(get == 9) //PR_STRING // char[]
		{
			uint8_t len_data;
			char ldata[255];
			bsData.Read(len_data);
			bsData.Read(ldata, len_data);
			ldata[len_data] = '\0'; 
			char tmp[255];
			cp1251_to_utf8(tmp, ldata);			
			g_pJavaWrapper->h_string(unnum,tmp);	
		}
	}
}

extern "C" JNIEXPORT void JNICALL Java_com_nvidia_dev_1one_NvEventQueueActivity_clickInterfaceId(JNIEnv *, jobject, jint clickid)
{
	if(pNetGame)
	{
		RakNet::BitStream bsSend;
		bsSend.Write((uint8_t)RPC_Hud);
		bsSend.Write((uint16_t)clickid);
		pNetGame->GetRakClient()->Send(&bsSend, HIGH_PRIORITY, UNRELIABLE_SEQUENCED, 0);		
	}
}


void ScrHUD(RPCParameters *rpcParams)
{
	unsigned char* Data = reinterpret_cast<unsigned char *>(rpcParams->input);
	int iBitLength = rpcParams->numberOfBitsOfData;
	RakNet::BitStream bsData(Data, (iBitLength / 8) + 1, false);

	uint8_t num;
	bsData.Read(num);
	
	if(num == 0)
	{
		bool tmp;
		bsData.Read(tmp);
		g_pJavaWrapper->SetInterfaceHud(tmp);
	}
	else if(num == 1)
	{
		int32_t date;
		uint16_t id;
		bool data;
		bsData.Read(date);
		bsData.Read(id);
		bsData.Read(data);		
		g_pJavaWrapper->SetInterfaceOnlineDate((int)date, (int)id, data);
	}
	else if(num == 2)
	{
		uint8_t hunger;
		bsData.Read(hunger);		
		g_pJavaWrapper->SetInterfaceHudHunger((int)hunger);
	}
	else if(num == 3)
	{
		uint16_t time;
		uint8_t len_data;
		char ldata[255];
		bsData.Read(time);
		bsData.Read(len_data);
		bsData.Read(ldata, len_data);
		ldata[len_data] = '\0'; 
		char tmp[255];
		cp1251_to_utf8(tmp, ldata);			
		g_pJavaWrapper->SetInterfaceHudPromo1((int)time,tmp);
	}
	else if(num == 4)
	{
		bool state;
		bsData.Read(state);
		pGame->ToggleRadar(state);
	}
	else if(num == 5)
	{
		uint8_t state;
		bsData.Read(state);
		g_pJavaWrapper->SetInterfaceHudZone(state);
	}
	else if(num == 6)
	{
		uint8_t type;
		uint16_t time;
		
		bsData.Read(type);
		bsData.Read(time);		
		
		uint8_t len_data;
		char ldata[255];
		bsData.Read(len_data);
		bsData.Read(ldata, len_data);
		ldata[len_data] = '\0'; 
		char tmp[255];
		cp1251_to_utf8(tmp, ldata);			
		
		g_pJavaWrapper->SetInterfaceHudNotifications((int)type,(int)time,tmp);
	}
	else if(num == 7)
	{
		bool state;
		bsData.Read(state);
		g_pJavaWrapper->SetInterafceVisibleUseBtn(state);		
	}
	else if(num == 8)
	{
		bool status;
		bsData.Read(status);
		g_pJavaWrapper->SetInterfaceNotification(status);
	}
	else if(num == 9)
	{
		bool state;
		bsData.Read(state);
		g_pJavaWrapper->ShowChat(state);
	}
	else if(num == 10)
	{
		bool state;
		bsData.Read(state);		
		g_pJavaWrapper->SetInterfaceHudCapt(state);
	}
	else if(num == 11)
	{
		uint8_t len_data;
		char ldata[255];
		bsData.Read(len_data);
		bsData.Read(ldata, len_data);
		ldata[len_data] = '\0'; 
		char tmp[255];
		cp1251_to_utf8(tmp, ldata);			
		
		g_pJavaWrapper->SetInterfaceHudCaptClock(tmp);
	}
	else if(num == 12)
	{
		int16_t i;
		bsData.Read(i);
		
		uint8_t len_data;
		char ldata[255];
		bsData.Read(len_data);
		bsData.Read(ldata, len_data);
		ldata[len_data] = '\0'; 
		char tmp[255];
		cp1251_to_utf8(tmp, ldata);			
		
		g_pJavaWrapper->SetInterfaceHudCaptScore(i, tmp);
	}
}

// Bird Ped
void WorldBirdAdd(RakNet::BitStream bsData)
{	
	Log("rpc: WorldBirdAdd");

	uint16_t BirdId;
	uint32_t iSkinId;
	uint16_t player; //PLAYERID
	bool pos; //lefr or right shoulder
	float fRotation;
	VECTOR vecPos; //offset
	
	bsData.Read(BirdId);
	bsData.Read(iSkinId);
	bsData.Read(player);
	bsData.Read(pos);
	bsData.Read(fRotation);
	bsData.Read(vecPos);	
	
	CBirdPool* pBirdPool = pNetGame->GetBirdPool();
	if (pBirdPool) 
	{
		Log("id %d %d %d %d %f",BirdId,iSkinId,player,pos,fRotation);
		pBirdPool->Spawn(BirdId,iSkinId,player,pos,vecPos,fRotation);
	}
	
}

void WorldBirdRemove(RPCParameters* rpcParams)
{
	Log("rpc: WorldBirdRemove");
	RakNet::BitStream bsData(rpcParams->input, (rpcParams->numberOfBitsOfData / 8) + 1, false);
	uint16_t BirdId;
	bsData.Read(BirdId);
	CBirdPool* pBirdPool = pNetGame->GetBirdPool();
	if (pBirdPool) 
	{
		pBirdPool->Delete(BirdId);
	}
}

void SetBirdAnimation(RPCParameters* rpcParams)
{
	RakNet::BitStream bsData(rpcParams->input, (rpcParams->numberOfBitsOfData / 8) + 1, false);
	PLAYERID BirdId;
	uint8_t byteAnimLibLen;
	uint8_t byteAnimNameLen;
	char szAnimLib[256];
	char szAnimName[256];
	float fS;
	bool opt1, opt2, opt3, opt4;
	int opt5;

	memset(szAnimLib, 0, 256);
	memset(szAnimName, 0, 256);

	bsData.Read(BirdId);
	bsData.Read(byteAnimLibLen);
	bsData.Read(szAnimLib, byteAnimLibLen);
	bsData.Read(byteAnimNameLen);
	bsData.Read(szAnimName, byteAnimNameLen);
	bsData.Read(fS);
	bsData.Read(opt1);
	bsData.Read(opt2);
	bsData.Read(opt3);
	bsData.Read(opt4);
	bsData.Read(opt5);

	szAnimLib[byteAnimLibLen] = '\0';
	szAnimName[byteAnimNameLen] = '\0';
	
	CBirdPool* pBirdPool = pNetGame->GetBirdPool();
	if (pBirdPool)
	{
		if (pBirdPool->GetAt(BirdId))
		{
			pBirdPool->GetAt(BirdId)->ApplyAnimation(szAnimName, szAnimLib, fS, (int)opt1, (int)opt2, (int)opt3, (int)opt4, opt5);
		}
	}
}

void ClearBirdAnimations(RPCParameters* rpcParams)
{
	RakNet::BitStream bsData(rpcParams->input, (rpcParams->numberOfBitsOfData / 8) + 1, false);
	uint16_t BirdId;
	float angle;
	bsData.Read(BirdId);
	CBirdPool* pBirdPool = pNetGame->GetBirdPool();
	if (pBirdPool)
	{
		if (pBirdPool->GetAt(BirdId))
		{
			MATRIX4X4 mat;
			pBirdPool->GetAt(BirdId)->GetMatrix(&mat);
			pBirdPool->GetAt(BirdId)->TeleportTo(mat.pos.X, mat.pos.Y, mat.pos.Z);
		}
	}
}


void RegisterScriptRPCs(RakClientInterface* pRakClient)
{
	Log("Registering ScriptRPC's..");
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrDisplayGameText, ScrDisplayGameText);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrSetGravity, ScrSetGravity);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrForceSpawnSelection,ScrForceSpawnSelection);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerPos, ScrSetPlayerPos);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrSetCameraPos, ScrSetCameraPos);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrSetCameraLookAt, ScrSetCameraLookAt);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerFacingAngle, ScrSetPlayerFacingAngle);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrSetFightingStyle, ScrSetFightingStyle);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerSkin, ScrSetPlayerSkin);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrApplyPlayerAnimation, ScrApplyPlayerAnimation);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrClearPlayerAnimations, ScrClearPlayerAnimations);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrSetSpawnInfo, ScrSetSpawnInfo);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrCreateExplosion, ScrCreateExplosion);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerHealth, ScrSetPlayerHealth);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerArmour, ScrSetPlayerArmour);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerColor, ScrSetPlayerColor);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerName, ScrSetPlayerName);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerPosFindZ, ScrSetPlayerPosFindZ);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrSetInterior, ScrSetPlayerInterior);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrSetMapIcon, ScrSetMapIcon);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrDisableMapIcon, ScrDisableMapIcon);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrSetCameraBehindPlayer, ScrSetCameraBehindPlayer);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrSetSpecialAction, ScrSetPlayerSpecialAction);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrTogglePlayerSpectating, ScrTogglePlayerSpectating);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerSpectating, ScrSetPlayerSpectating);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrPlayerSpectatePlayer, ScrPlayerSpectatePlayer);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrPlayerSpectateVehicle, ScrPlayerSpectateVehicle);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrPutPlayerInVehicle, ScrPutPlayerInVehicle);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrVehicleParams, ScrVehicleParams);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrVehicleParamsEx, ScrVehicleParamsEx);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrHaveSomeMoney, ScrHaveSomeMoney);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrResetMoney, ScrResetMoney);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrLinkVehicle, ScrLinkVehicle);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrRemovePlayerFromVehicle, ScrRemovePlayerFromVehicle);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrSetVehicleHealth, ScrSetVehicleHealth);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrSetVehiclePos, ScrSetVehiclePos);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrSetVehicleVelocity, ScrSetVehicleVelocity);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrNumberPlate, ScrNumberPlate);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrInterpolateCamera, ScrInterpolateCamera);

	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrAddGangZone,ScrAddGangZone);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrRemoveGangZone,ScrRemoveGangZone);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrFlashGangZone,ScrFlashGangZone);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrStopFlashGangZone,ScrStopFlashGangZone);

	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrCreateObject, ScrCreateObject);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrSetObjectPos, ScrSetObjectPos);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrDestroyObject, ScrDestroyObject);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrSetObjectRotation, ScrSetObjectRotation);

	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrPlaySound, ScrPlaySound);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerWantedLevel, ScrSetPlayerWantedLevel);

	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrTogglePlayerControllable, ScrTogglePlayerControllable);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrAttachObjectToPlayer, ScrAttachObjectToPlayer);
	
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ClientCheck, ScrClientCheck);
	
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrShowSpeed,ScrShowSpeed);
	
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrChatBubble,ScrChatBubble);
	
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrSendToLink,ScrSendToLink);
	
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ClickTextDraw, ScrSelectTextDraw);
	
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrShowTextDraw, ScrShowTextDraw);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrHideTextDraw, ScrHideTextDraw);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrEditTextDraw, ScrEditTextDraw);	
	
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrSetVehicleZAngle, ScrSetVehicleZAngle);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrRemoveComponent, ScrRemoveVehicleComponent);
	
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrSetWeaponAmmo, ScrSetPlayerAmmo);
	
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrResetPlayerWeapons, ScrResetPlayerWeapons);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerSkillLevel, ScrSetPlayerSkillLevel);
	
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrGivePlayerWeapon, ScrGivePlayerWeapon);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_SetArmedWeapon, ScrSetArmedWeapon);
	
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_PlayAudioStream, ScrPlayAudioStream);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_StopAudioStream, ScrStopAudioStream);	
	
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrRemoveBuilding,ScrRemoveBuilding);
	
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerAttachedObject, ScrSetPlayerAttachedObject);
	
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_GetFolder, ScrGetFolder);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_UseOffset, ScrUseOffset);
	
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerVelocity, ScrSetPlayerVelocity);
	
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrDeathMessage, ScrDeathMessage);
	
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrAttachTrailerToVehicle, ScrAttachTrailerToVehicle);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrDetachTrailerFromVehicle, ScrDetachTrailerFromVehicle);	
	
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_Interface, ScrInterface);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_Logo, ScrLogo);
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_Inv, ScrInv);
	
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_Handling, ScrHandling);
	
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrMoveObject, ScrMoveObject);
	
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_Other, ScrOther);
	
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_ScrSetPlayerDrunkLevel, ScrSetPlayerDrunkLevel);
	
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_Handler, ScrHandler);
	
	pRakClient->RegisterAsRemoteProcedureCall(&RPC_Hud, ScrHUD);
}

void UnRegisterScriptRPCs(RakClientInterface* pRakClient)
{
	Log("Unregistering ScriptRPC's..");
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrDisplayGameText);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrSetGravity);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrForceSpawnSelection);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrSetPlayerPos);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrSetCameraPos);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrSetCameraLookAt);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrSetPlayerFacingAngle);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrSetFightingStyle);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrSetPlayerSkin);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrApplyPlayerAnimation);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrClearPlayerAnimations);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrSetSpawnInfo);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrCreateExplosion);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrSetPlayerHealth);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrSetPlayerArmour);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrSetPlayerColor);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrSetPlayerName);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrSetPlayerPosFindZ);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrSetInterior);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrSetMapIcon);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrDisableMapIcon);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrSetCameraBehindPlayer);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrSetSpecialAction);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrTogglePlayerSpectating);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrSetPlayerSpectating);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrPlayerSpectatePlayer);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrPlayerSpectateVehicle);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrPutPlayerInVehicle);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrVehicleParams);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrVehicleParamsEx);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrHaveSomeMoney);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrResetMoney);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrLinkVehicle);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrRemovePlayerFromVehicle);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrSetVehicleHealth);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrSetVehiclePos);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrSetVehicleVelocity);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrNumberPlate);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrInterpolateCamera);
	
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrAddGangZone);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrRemoveGangZone);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrFlashGangZone);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrStopFlashGangZone);

	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrCreateObject);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrDestroyObject);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrSetObjectPos);

	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrPlaySound);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrSetPlayerWantedLevel);
	
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ClientCheck);
	
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrShowSpeed);
	
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrChatBubble);
	
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrSendToLink);
	
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ClickTextDraw);
	
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrShowTextDraw);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrHideTextDraw);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrEditTextDraw);
	
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrSetVehicleZAngle);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrRemoveComponent);
	
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrSetWeaponAmmo);
	
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrSetPlayerSkillLevel);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrResetPlayerWeapons);
	
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrGivePlayerWeapon);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_SetArmedWeapon);
	
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_PlayAudioStream);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_StopAudioStream);	
	
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrRemoveBuilding);
	
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrSetPlayerAttachedObject);
	
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_GetFolder);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_UseOffset);
	
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrSetPlayerVelocity);
	
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrDeathMessage);
	
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrAttachTrailerToVehicle);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrDetachTrailerFromVehicle);
	
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_Interface);
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_Logo);	
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_Inv);
	
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_Handling);
	
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrMoveObject);
	
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_Other);
	
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_ScrSetPlayerDrunkLevel);
	
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_Handler);
	
	pRakClient->UnregisterAsRemoteProcedureCall(&RPC_Hud);
}