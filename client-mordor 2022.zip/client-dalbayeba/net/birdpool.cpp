#include "../main.h"
#include "../game/game.h"
#include "netgame.h"

CBirdPool::CBirdPool() 
{
	
	for (uint16_t BirdId = 0; BirdId < MAX_BIRDS; BirdId++) 
	{
		m_bBirdSlotState[BirdId] = false;
		m_pBird[BirdId] = nullptr;
	}
}

CBirdPool::~CBirdPool() 
{
	
	for (uint16_t BirdId = 0; BirdId < MAX_BIRDS; BirdId++) 
	{
		Delete(BirdId);
	}
}

bool CBirdPool::Spawn(uint16_t BirdId, int iSkin, PLAYERID player, bool pos, VECTOR vecPos, float fRotation) 
{
	
	if (!IsValidBirdId(BirdId)) 
	{
		return false;
	}

	if (m_pBird[BirdId] != NULL) 
	{
		Delete(BirdId);
	}

	m_pBird[BirdId] = new CBirdPed((uint16_t)iSkin, player, pos, vecPos, fRotation);

	if (m_pBird[BirdId])
	{
		m_bBirdSlotState[BirdId] = true;
		return true;
	}

	return false;
}

bool CBirdPool::Delete(uint16_t BirdId) 
{
	
	if (!IsValidBirdId(BirdId)) 
	{
		return false;
	}

	m_bBirdSlotState[BirdId] = false;

	if (m_pBird[BirdId]) 
	{
		delete m_pBird[BirdId];
		m_pBird[BirdId] = nullptr;
	}

	return true;
}

void CBirdPool::Process()
{
	
}